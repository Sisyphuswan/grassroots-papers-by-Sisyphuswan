# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 2.5.5 —— 两种理论框架对照（中英双语）

from matplotlib.patches import Rectangle, FancyArrowPatch

L = {
    "zh": dict(
        t="图 2.5.5  两种框架：二维叙事 vs 一维解析",
        note="结论互相映照；本书另给出可代入 ODE 的显式函数",
        la="Acemoglu & Robinson（2019）", lb="本书",
        x="社会动员  →", y="国家能力  →",
        a1="专制利维坦", a2="缺席利维坦", a3="受缚的利维坦\n（窄廊）",
        b1="$\\theta \\to 0$\n过刚脆断", b2="$\\theta \\to 1$\n无能解体",
        b3="$\\theta \\approx \\theta^{*}_{\\mathrm{social}}$\n窄廊最优解",
        ax="$\\theta$ 轴",
    ),
    "en": dict(
        t="Figure 2.5.5  Two Frameworks: 2D Narrative vs 1D Analytical Form",
        note="The conclusions mirror each other; here we add an explicit function for the ODE",
        la="Acemoglu & Robinson (2019)", lb="This book",
        x="Society mobilisation  →", y="State capacity  →",
        a1="Despotic leviathan", a2="Absent leviathan", a3="Shackled leviathan\n(narrow corridor)",
        b1="$\\theta \\to 0$\nbrittle", b2="$\\theta \\to 1$\ndisorder",
        b3="$\\theta \\approx \\theta^{*}_{\\mathrm{social}}$\ncorridor optimum",
        ax="$\\theta$ axis",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.2, 5.8), dpi=200,
                                   gridspec_kw={"width_ratios": [1.0, 0.72]})
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.77, bottom=0.11, wspace=0.18)
    ax1.set_xlim(0, 1); ax1.set_ylim(0, 1); plain_axes(ax1)
    ax1.set_facecolor(P["light_bg"])
    ax1.add_patch(Rectangle((0.0, 0.62), 0.45, 0.38, facecolor=P["gap"], alpha=0.15))
    ax1.add_patch(Rectangle((0.62, 0.0), 0.38, 0.45, facecolor="#9AA7B4", alpha=0.18))
    ax1.add_patch(Rectangle((0.52, 0.52), 0.24, 0.24, facecolor=P["good"], alpha=0.22))
    ax1.text(0.22, 0.81, d["a1"], ha="center", fontsize=9.6, color=P["dead"])
    ax1.text(0.81, 0.22, d["a2"], ha="center", fontsize=9.6, color="#5C6773")
    ax1.text(0.64, 0.64, d["a3"], ha="center", va="center", fontsize=8.6, color=P["good"])
    ax1.set_xlabel(d["x"], fontsize=10.5); ax1.set_ylabel(d["y"], fontsize=10.5)
    ax1.set_xticks([]); ax1.set_yticks([])
    ax1.set_title(d["la"], fontsize=11)
    ax2.set_xlim(0, 1); ax2.set_ylim(0, 1); ax2.axis("off")
    ax2.add_patch(FancyArrowPatch((0.08, 0.5), (0.95, 0.5),
                  arrowstyle="-|>", mutation_scale=18, color=P["text"], lw=1.8))
    for x0, x1, c in ((0.08, 0.33, P["gap"]), (0.33, 0.70, P["good"]), (0.70, 0.95, "#9AA7B4")):
        ax2.add_patch(Rectangle((x0, 0.44), x1 - x0, 0.12, facecolor=c, alpha=0.30))
    ax2.text(0.205, 0.70, d["b1"], ha="center", va="center", fontsize=9.0, color=P["dead"])
    ax2.text(0.515, 0.70, d["b3"], ha="center", va="center", fontsize=9.0, color=P["good"])
    ax2.text(0.825, 0.70, d["b2"], ha="center", va="center", fontsize=9.0, color="#5C6773")
    ax2.text(0.95, 0.36, d["ax"], ha="right", fontsize=9.5, color="#7A828C")
    ax2.set_title(d["lb"], fontsize=11)
    fig.text(0.5, 0.965, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.900, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig2_5_5_two_frameworks")

for lg in ("zh", "en"):
    draw(lg)
