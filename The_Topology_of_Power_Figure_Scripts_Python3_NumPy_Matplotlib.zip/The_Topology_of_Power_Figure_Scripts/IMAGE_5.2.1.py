# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.2.1 —— 连续空间 Ω 与测度 Width：常态可行域 vs 单点态

from matplotlib.patches import Rectangle

L = {
    "zh": dict(
        t="图 5.2.1  连续空间 $\\Omega$ 与测度 $\\text{Width}$：常态可行域与单点态",
        note="Width 测量的是可行土地在高维空间中的真实体积，不是菜单上的条目数",
        x="行动维度 1（劳动强度）", y="行动维度 2（言论尺度）",
        om="社会行动全域  $\\Omega$",
        ai="常态可行域  $A_i$",
        ai2="具有正体积的区域\n$\\text{Width} = \\mu_{\\text{Lebesgue}}(A_i) > 0$",
        sp="单点态  $A_i = \\{a_{\\text{conform}}\\}$",
        sp2="流形坍缩为孤立点\n$\\dim(A_i) = 0$，$\\text{Width} = 0$",
        sp3="无邻域，无方向",
    ),
    "en": dict(
        t="Figure 5.2.1  The continuum $\\Omega$ and the measure $\\text{Width}$: normal domain vs singleton",
        note="Width measures the true volume of feasible ground, not the number of menu items",
        x="Action dimension 1 (labour intensity)",
        y="Action dimension 2 (speech latitude)",
        om="Universe of social action  $\\Omega$",
        ai="Normal domain  $A_i$",
        ai2="a region of positive volume\n$\\text{Width} = \\mu_{\\text{Lebesgue}}(A_i) > 0$",
        sp="Singleton  $A_i = \\{a_{\\text{conform}}\\}$",
        sp2="collapsed to an isolated point\n$\\dim(A_i) = 0$, $\\text{Width} = 0$",
        sp3="no neighbourhood, no direction",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(9.8, 6.4), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.85, bottom=0.10, left=0.08, right=0.98)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")

    ax.add_patch(Rectangle((0.30, 0.60), 9.4, 8.5, facecolor=P["omega"],
                           edgecolor="#C7CDD6", lw=1.5, zorder=1))
    ax.text(0.58, 8.72, d["om"], ha="left", va="center",
            fontsize=10.5, color="#6B7480", zorder=3)

    ax.add_patch(Rectangle((1.45, 2.55), 3.35, 3.30, facecolor=P["inc"],
                           alpha=0.34, edgecolor=P["inc"], lw=2.4, zorder=3))
    ax.text(3.12, 4.28, d["ai"], ha="center", va="center",
            fontsize=12.5, fontweight="bold", color="#1F5C40", zorder=4)
    ax.text(3.12, 3.58, d["ai2"], ha="center", va="center",
            fontsize=9.6, color=P["text"], zorder=4)

    ax.plot([7.55], [5.15], marker="o", ms=13, color=P["dead"], zorder=4)
    ax.text(7.55, 5.80, d["sp"], ha="center", va="bottom",
            fontsize=11.5, fontweight="bold", color=P["dead"], zorder=4)
    ax.text(7.55, 4.55, d["sp2"], ha="center", va="top",
            fontsize=9.6, color=P["text"], zorder=4)
    ax.text(7.55, 3.62, d["sp3"], ha="center", va="top",
            fontsize=9.2, color=P["dead"], style="italic", zorder=4)

    ax.annotate("", xy=(9.42, 0.82), xytext=(0.48, 0.82),
                arrowprops=dict(arrowstyle="->", color=P["text"], lw=1.6))
    ax.annotate("", xy=(0.48, 8.95), xytext=(0.48, 0.82),
                arrowprops=dict(arrowstyle="->", color=P["text"], lw=1.6))
    ax.text(9.30, 0.60, d["x"], ha="right", va="top", fontsize=10.6, color=P["text"])
    ax.text(0.36, 8.95, d["y"], ha="left", va="bottom", fontsize=10.6, color=P["text"])

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_2_1_space_measure")


for lg in ("zh", "en"):
    draw(lg)
