# *The Topology of Power* — Standalone Figure Replication Scripts
# 《权力拓扑学》全书插图独立复现脚本

- **Author / 作者**: Sisyphuswan
- **Zenodo DOI (English Edition)**: https://doi.org/10.5281/zenodo.24578117
- **Repository / 主仓库**: https://github.com/Sisyphuswan/grassroots-papers-by-Sisyphuswan

## Runtime Environment / 运行环境

All scripts require only **Python 3** with **NumPy** and **Matplotlib** (no external helper module required).

- **Tested environment / 实测通过环境**:
  - Python `3.14.7` (64-bit, compatible with Python 3.10+)
  - NumPy `2.5.2`
  - Matplotlib `3.11.1`

Install dependencies / 安装依赖：

```bash
pip install -r requirements.txt
```

## How to Run / 使用方法

Every `IMAGE_*.py` file is **100% standalone** and generates both the Chinese (`_zh.png`) and English (`_en.png`) versions of that figure.

- **Single figure (double-click or CLI) / 单图运行**：
  Double-click any `IMAGE_*.py` directly, or run:
  ```bash
  python IMAGE_2.2.2.py
  ```
  Output PNGs are automatically written next to the script under:
  - `./figures/zh/<figure_name>_zh.png`
  - `./figures/en/<figure_name>_en.png`

- **All figures at once / 一键生成全部插图**：
  ```bash
  python run_all_figures.py
  ```
