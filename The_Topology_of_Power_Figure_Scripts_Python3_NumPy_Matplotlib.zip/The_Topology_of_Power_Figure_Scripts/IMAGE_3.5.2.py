# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 3.5.2 —— κ 衰退的三条自我强化通道

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 3.5.2  κ 衰退的三条自我强化通道",
        note="三条通道相互强化：每一条都在替另外两条铺路",
        c1="通道一 · 财政收缩与基建维护赤字",
        c1s="统制扼杀市场、税基持续萎缩：Infra 折旧失修，SpatialDecay 恶化",
        c2="通道二 · 官僚逆向淘汰与信息黑洞",
        c2s="忠诚挂帅、劣币驱逐良币：负反馈信号归零，中枢最后一个知道真相",
        c3="通道三 · 社会原子化与自组织坏死",
        c3s="中间组织被连根拔起：社会失去减震器，冲击无衰减直撞中枢",
        core="中央承载能力 κ_State 断崖跌落",
        cores="最终在一次微小外生冲击下当众威慑祛魅",
    ),
    "en": dict(
        t="Figure 3.5.2  Three self-reinforcing channels of κ decay",
        note="The three channels reinforce one another: each paves the road for the others",
        c1="Channel 1 · Fiscal contraction & infrastructure deficit",
        c1s="Suppression kills markets and shrinks the tax base; Infra decays, SpatialDecay worsens",
        c2="Channel 2 · Adverse selection & information black hole",
        c2s="Loyalty beats competence: negative feedback goes silent, the centre reads its own propaganda",
        c3="Channel 3 · Social atomization & necrosis of self-organization",
        c3s="Intermediate groups uprooted — society loses its dampers, shocks hit the core undamped",
        core="State capacity κ_State falls off a cliff",
        cores="Finally disenchanted in public by a tiny exogenous shock",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(12.6, 6.8), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.85, bottom=0.03, left=0.02, right=0.98)
    ax.set_xlim(0, 12.6); ax.set_ylim(0, 10); ax.axis("off")
    rows = [(6.75, P["cost"], d["c1"], d["c1s"]),
            (4.15, P["claimed"], d["c2"], d["c2s"]),
            (1.55, P["gap"], d["c3"], d["c3s"])]
    for y, col, lab, sub in rows:
        ax.add_patch(FancyBboxPatch((0.30, y), 6.55, 1.85,
                     boxstyle="round,pad=0.10,rounding_size=0.12",
                     facecolor=col, alpha=0.14, edgecolor=col, lw=2.0))
        ax.text(3.58, y + 1.20, lab, ha="center", va="center",
                fontsize=11.5, fontweight="bold", color=col)
        ax.text(3.58, y + 0.55, sub, ha="center", va="center",
                fontsize=9.2, color=P["text"])
    ax.add_patch(FancyBboxPatch((8.15, 3.55), 4.15, 2.60,
                 boxstyle="round,pad=0.12,rounding_size=0.14",
                 facecolor=P["dead"], alpha=0.18, edgecolor=P["dead"], lw=2.4))
    ax.text(10.23, 5.48, d["core"], ha="center", va="center",
            fontsize=12.0, fontweight="bold", color=P["dead"])
    ax.text(10.23, 4.32, d["cores"], ha="center", va="center",
            fontsize=9.4, color=P["text"])
    for y in (7.67, 5.07, 2.47):
        ax.add_patch(FancyArrowPatch((6.92, y), (8.08, 4.86),
                     arrowstyle="-|>", mutation_scale=20,
                     color=P["dead"], lw=1.8,
                     connectionstyle="arc3,rad=0.10"))
    fig.text(0.5, 0.958, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.918, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig3_5_2_three_channels")

for lg in ("zh", "en"):
    draw(lg)
