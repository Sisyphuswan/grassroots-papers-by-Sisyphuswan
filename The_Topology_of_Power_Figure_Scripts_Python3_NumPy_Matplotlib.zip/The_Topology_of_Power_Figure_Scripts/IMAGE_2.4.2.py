# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 2.4.2 —— Inflex × Elastic 四象限（中英双语）

from matplotlib.patches import Rectangle

L = {
    "zh": dict(
        t="图 2.4.2  Inflex × Elastic 四象限：四种治理生态",
        note="同一种「死板」，落在不同象限中，对应四种不同的制度病症",
        x="Elastic 回撤弹性  →  高", y="Inflex 裁量压缩度  →  高",
        q1="健康韧性型（象限 IV）\n低 Inflex + 高 Elastic",
        q1c="罗马裁判官法：严法可缓冲",
        q2="前松后死型（象限 III）\n低 Inflex + 低 Elastic",
        q2c="血腥法典：陪审团降格，定谳即终局",
        q3="脆断绝望型（象限 II）\n高 Inflex + 低 Elastic",
        q3c="大泽乡：误期即死，绝无申诉",
        q4="僵硬科层型（象限 I）\n高 Inflex + 高 Elastic",
        q4c="普鲁士行政法院：照章办事，但可起诉",
    ),
    "en": dict(
        t="Figure 2.4.2  The Inflex × Elastic grid: four governance ecologies",
        note="The same word 'rigid' means four entirely different illnesses",
        x="Elastic  →  high", y="Inflex  →  high",
        q1="Resilient (Quadrant IV)\nlow Inflex + high Elastic",
        q1c="Roman praetorian law: harsh but softenable",
        q2="Lax then final (Quadrant III)\nlow Inflex + low Elastic",
        q2c="Bloody Code: jury mitigation, verdict final",
        q3="Brittle despair (Quadrant II)\nhigh Inflex + low Elastic",
        q3c="Daze Township: late means death, no way out",
        q4="Rigid bureaucracy (Quadrant I)\nhigh Inflex + high Elastic",
        q4c="Prussian administrative courts: rules, but appealable",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(10.6, 7.4), dpi=200)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); plain_axes(ax)
    ax.set_facecolor(P["light_bg"])
    ax.add_patch(Rectangle((0.5, 0.0), 0.5, 0.5, facecolor=P["good"], alpha=0.16))
    ax.add_patch(Rectangle((0.0, 0.5), 0.5, 0.5, facecolor=P["gap"], alpha=0.16))
    ax.add_patch(Rectangle((0.0, 0.0), 0.5, 0.5, facecolor="#BFB5A8", alpha=0.12))
    ax.add_patch(Rectangle((0.5, 0.5), 0.5, 0.5, facecolor="#BFB5A8", alpha=0.12))
    ax.axvline(0.5, color=P["text"], lw=1.2, alpha=0.55)
    ax.axhline(0.5, color=P["text"], lw=1.2, alpha=0.55)
    cells = [(0.75, 0.25, d["q1"], d["q1c"], P["good"], P["dead"]),
             (0.25, 0.25, d["q2"], d["q2c"], "#7A6A55", P["text"]),
             (0.25, 0.75, d["q3"], d["q3c"], P["dead"], P["dead"]),
             (0.75, 0.75, d["q4"], d["q4c"], "#7A6A55", P["text"])]
    for cx, cy, name, case, cname, ccase in cells:
        ax.text(cx, cy + 0.085, name, ha="center", va="center",
                fontsize=11.0, color=cname, fontweight="bold")
        ax.text(cx, cy - 0.055, case, ha="center", va="center",
                fontsize=8.8, color=ccase)
    ax.plot([0.86], [0.14], marker="o", ms=12, color=P["good"])
    ax.plot([0.09], [0.93], marker="X", ms=14, color=P["dead"])
    ax.set_xlabel(d["x"], fontsize=11.5); ax.set_ylabel(d["y"], fontsize=11.5)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["0", "1"])
    ax.set_yticks([0, 1]); ax.set_yticklabels(["0", "1"])
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig2_4_2_inflex_elastic")

for lg in ("zh", "en"):
    draw(lg)
