# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 4.3.1 —— 全域 Ω 内的三场交叠与 A_i 交集

from matplotlib.patches import FancyBboxPatch

L = {
    "zh": dict(
        t="图 4.3.1  全域 Ω 之内：三场交叠与它们的交集",
        note="三个区域各切一刀、彼此交叠，真正的生路是三者同时许可的那一小块",
        om="社会行动全域  Ω（所有物理可能的人类动作）",
        b1="激励场  Π_Incentive", d1="许可侧：当期收益加期后折算\n够得上存续底线 —— 活得下去",
        b2="恐惧场  Π_Fear", d2="许可侧：不在实态惩罚禁区内\n—— 不会被毁",
        b3="责任场  Π_Responsibility", d3="许可侧：三类硬边界未破、\n角色资格还在 —— 还站得住",
        ai="A_i", ai2="三场交集（真实生路）",
    ),
    "en": dict(
        t="Figure 4.3.1  Inside the universe Ω: three overlapping fields and their intersection",
        note="Each boundary cuts once; the real road is the patch all three permit",
        om="Social action universe  Ω (all physically possible human acts)",
        b1="Incentive field  Π_Incentive", d1="permissive side — payoff plus deferred\nshare clears the floor",
        b2="Fear field  Π_Fear", d2="permissive side — outside the\nactual penalty zone",
        b3="Responsibility field  Π_Responsibility", d3="permissive side — three hard limits\nunbroken, role status intact",
        ai="A_i", ai2="intersection of the three",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]

    def ring(x, y, w, h, col):
        ax.add_patch(FancyBboxPatch((x, y), w, h,
                     boxstyle="round,pad=0.05,rounding_size=0.16",
                     facecolor="none", edgecolor=col, lw=2.2))

    fig, ax = plt.subplots(figsize=(10.4, 7.6), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.89, bottom=0.02, left=0.02, right=0.98)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")

    ax.add_patch(FancyBboxPatch((0.35, 0.55), 9.30, 8.90,
                 boxstyle="round,pad=0.06,rounding_size=0.14",
                 facecolor=P["omega"], edgecolor="#C7CDD6", lw=1.6))
    ax.text(0.62, 9.16, d["om"], ha="left", va="center",
            fontsize=10.5, color="#6B7480")

    # 三块许可侧各切一刀、彼此部分交叠 —— 不是同心包含
    ring(0.90, 4.60, 5.40, 4.30, P["inc"])
    ring(3.70, 4.10, 5.40, 4.20, P["fear"])
    ring(2.30, 1.20, 5.40, 4.90, P["resp"])

    # 三者同时许可的重合区即 A_i，位置与三个矩形的交集严格一致
    ax.add_patch(FancyBboxPatch((3.70, 4.60), 2.60, 1.50,
                 boxstyle="round,pad=0.03,rounding_size=0.10",
                 facecolor=P["inc"], alpha=0.34, edgecolor=P["good"], lw=2.2))
    ax.text(5.00, 5.60, d["ai"], ha="center", va="center",
            fontsize=15, fontweight="bold", color="#1F5C40")
    ax.text(5.00, 5.02, d["ai2"], ha="center", va="center",
            fontsize=8.6, color=P["text"])

    for x0, y0, b, dd, col in ((1.10, 7.95, d["b1"], d["d1"], P["inc"]),
                               (6.45, 7.95, d["b2"], d["d2"], P["fear"]),
                               (2.55, 2.95, d["b3"], d["d3"], P["resp"])):
        ax.text(x0, y0, b, ha="left", va="center", fontsize=10.6,
                fontweight="bold", color=col)
        ax.text(x0, y0 - 0.50, dd, ha="left", va="top", fontsize=8.8,
                color=P["text"], linespacing=1.5)

    fig.text(0.5, 0.965, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.932, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig4_3_1_three_nested")


for lg in ("zh", "en"):
    draw(lg)
