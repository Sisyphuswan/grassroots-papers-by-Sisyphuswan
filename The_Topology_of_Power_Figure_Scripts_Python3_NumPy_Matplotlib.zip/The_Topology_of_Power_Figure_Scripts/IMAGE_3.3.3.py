# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 3.3.3 —— 威慑祛魅：主观威慑概率的断崖式坍塌

import numpy as np

L = {
    "zh": dict(
        t="图 3.3.3  威慑祛魅：主观威慑概率的断崖式坍塌",
        note="建立威慑要千日，摧毁威慑只要一次「未能到场惩戒」的物理事实",
        y="主观威慑概率  $\\mathrm{PerceivedProbability}_i(x)$",
        x="时间  t",
        hi="虚假威慑期：全民高估惩罚概率",
        lo="威慑祛魅之后：惩罚禁区瓦解，进入群体抗争",
        ev="破壁事件",
        cas="信息级联瀑布：\n瞬间看穿威慑空心化",
    ),
    "en": dict(
        t="Figure 3.3.3  Disenchantment of deterrence: the cliff-like collapse of subjective deterrence",
        note="Building deterrence takes a thousand days; destroying it takes one unpunished fact",
        y="Subjective probability  $\\mathrm{PerceivedProbability}_i(x)$",
        x="Time  t",
        hi="Illusory period: everyone over-estimates punishment",
        lo="After disenchantment: sanction zone collapses, contention begins",
        ev="Breaching event",
        cas="Information cascade:\nthe hollowing-out is seen through",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(11.0, 6.0), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.81, bottom=0.17, left=0.11, right=0.97)
    t = np.linspace(0, 10, 800)
    ts, k = 6.0, 6.0
    p = 0.93 / (1.0 + np.exp(k * (t - ts))) + 0.02
    ax.plot(t, p, color=P["fear"], lw=3.2)
    ax.fill_between(t, 0, p, color=P["fear"], alpha=0.13)
    ax.axhline(0.95, color=P["claimed"], lw=1.4, ls="--", alpha=0.85)
    ax.axvline(ts, color=P["dead"], lw=1.5, ls=":")
    ax.plot([ts], [0.485], marker="o", ms=8.5, color=P["dead"], zorder=5)
    ax.annotate(d["ev"], xy=(ts - 0.05, 0.50), xytext=(2.60, 0.66),
                fontsize=9.8, color=P["dead"],
                arrowprops=dict(arrowstyle="->", lw=1.3, color=P["dead"]))
    ax.annotate(d["cas"], xy=(6.45, 0.20), xytext=(6.60, 0.34),
                fontsize=9.8, color=P["dead"],
                arrowprops=dict(arrowstyle="->", lw=1.3, color=P["dead"]))
    ax.text(0.30, 1.00, d["hi"], ha="left", va="bottom",
            fontsize=9.8, color=P["claimed"])
    ax.text(9.80, 0.075, d["lo"], ha="right", va="bottom",
            fontsize=9.8, color=P["actual"])
    ax.set_xlim(0, 10); ax.set_ylim(0, 1.14)
    ax.set_xlabel(d["x"], fontsize=11); ax.set_ylabel(d["y"], fontsize=11)
    ax.set_xticks([]); ax.set_yticks([0.0, 0.5, 1.0])
    plain_axes(ax)
    fig.text(0.5, 0.950, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.908, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig3_3_3_exposure")

for lg in ("zh", "en"):
    draw(lg)
