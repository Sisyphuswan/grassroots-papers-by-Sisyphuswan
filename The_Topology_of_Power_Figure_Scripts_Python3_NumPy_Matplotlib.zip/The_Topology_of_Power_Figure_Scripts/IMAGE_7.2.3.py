# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 7.2.3 —— 授权悖论与三阶段相变相图

import numpy as np, matplotlib.pyplot as plt

def draw(lang):
    set_font(lang)
    fig, ax = plt.subplots(figsize=(10.8, 6.4), dpi=200)
    kappa = np.linspace(0.1, 1.0, 400)
    
    # Deleg_need is decreasing in kappa, Deleg_safe & Deleg* are increasing in kappa
    d_need = 0.75 - 0.45 * kappa
    d_safe = 0.15 + 0.65 * kappa
    d_star = 0.12 + 0.55 * kappa
    
    ax.plot(kappa, d_need, color=P["gap"], lw=2.8, label="Deleg_need (保底下界)" if lang=="zh" else "Deleg_need (Lower Bound)")
    ax.plot(kappa, d_safe, color=P["inc"], lw=2.8, label="Deleg_safe (安全上界)" if lang=="zh" else "Deleg_safe (Upper Bound)")
    ax.plot(kappa, d_star, color="#4A5568", lw=2.2, ls="--", label="Deleg* (无约束内点最优)" if lang=="zh" else "Deleg* (Unconstrained Optimum)")
    
    # Intersection point kappa_crit (d_need == d_safe) and kappa_bind (d_star == d_need)
    idx_crit = np.argmin(np.abs(d_need - d_safe))
    k_crit = kappa[idx_crit]
    d_crit = d_need[idx_crit]
    
    idx_bind = np.argmin(np.abs(d_need - d_star))
    k_bind = kappa[idx_bind]
    d_bind = d_need[idx_bind]
    
    ax.axvline(k_crit, color=P["dead"], ls="--", lw=1.8)
    ax.axvline(k_bind, color="#D97706", ls=":", lw=1.8)
    ax.scatter([k_crit, k_bind], [d_crit, d_bind], color=[P["dead"], "#D97706"], s=70, zorder=5)
    
    # Fill areas: dead zone, anxiety squeeze zone, healthy corridor
    ax.fill_between(kappa[:idx_crit+1], d_safe[:idx_crit+1], d_need[:idx_crit+1], color=P["dead"], alpha=0.18, label="死锁空集区 (FeasibleSet = $\\varnothing$)" if lang=="zh" else "Deadlock Zone (Empty Set)")
    ax.fill_between(kappa[idx_crit:idx_bind+1], d_need[idx_crit:idx_bind+1], d_safe[idx_crit:idx_bind+1], color="#F59E0B", alpha=0.22, label="焦虑挤压区 (下界约束激活)" if lang=="zh" else "Anxiety Squeeze Zone (Lower Bound Binds)")
    ax.fill_between(kappa[idx_bind:], d_need[idx_bind:], d_safe[idx_bind:], color=P["inc"], alpha=0.14, label="充裕稳态走廊" if lang=="zh" else "Healthy Interior Corridor")
    
    ax.text(k_crit - 0.015, 0.04, "kappa_Critical" if lang=="zh" else "kappa_Critical", ha="right", fontsize=9.2, color=P["dead"], fontweight="bold")
    ax.text(k_bind + 0.015, 0.04, "kappa_bind" if lang=="zh" else "kappa_bind", ha="left", fontsize=9.2, color="#B45309", fontweight="bold")
    ax.text(0.31, 0.50, "死锁空集区\nFeasibleSet = $\\varnothing$" if lang=="zh" else "Empty Feasible Set", ha="center", fontsize=9.8, color=P["dead"])
    ax.text(0.588, 0.78, "焦虑挤压区\nDeleg* < Deleg_need" if lang=="zh" else "Anxiety Squeeze", ha="center", fontsize=8.8, color="#B45309", fontweight="bold")
    ax.text(0.83, 0.56, "充裕稳态区\nDeleg_need < Deleg* < Deleg_safe" if lang=="zh" else "Healthy Corridor\nInterior Optimum", ha="center", fontsize=9.5, color=P["inc"])
    
    ax.set_xlim(0.1, 1.0); ax.set_ylim(0, 1.0)
    ax.set_xlabel("中央承载能力 kappa_State" if lang=="zh" else "State Capacity kappa_State", fontsize=11.0)
    ax.set_ylabel("授权度 Deleg" if lang=="zh" else "Delegation Degree Deleg", fontsize=11.0)
    ax.set_title("图 7.2.3  授权悖论：三阶段状态相变与可行授权域消解" if lang=="zh" else "Figure 7.2.3 Delegation Paradox: Three-Regime Transition and Collapse", fontsize=12.5, fontweight="bold")
    ax.legend(loc="upper left", frameon=False, fontsize=9.0)
    plain_axes(ax); ax.grid(True, ls=":", color=P["grid"], alpha=0.6)
    footer(fig, lang); save(fig, lang, "fig7_2_3_delegation_paradox")

for lg in ("zh", "en"):
    draw(lg)
