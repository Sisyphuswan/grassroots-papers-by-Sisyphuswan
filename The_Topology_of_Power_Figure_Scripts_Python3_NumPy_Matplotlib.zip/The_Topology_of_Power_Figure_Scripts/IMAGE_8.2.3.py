# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 8.2.3 —— 动态不一致性与抱权猜忌螺旋（中英双语）

import numpy as np

L = {
    "zh": dict(
        t="图 8.2.3  动态不一致性与抱权猜忌螺旋",
        note="缴械使 t1 承诺可信度归零；自保抱权被读为备战信号，双方在猜疑链中共同滑向终局奇点",
        pa="A 栏：缴械前后的主权承诺可信度落差", pb="B 栏：防御抱权与君主猜忌放大相图",
        x1="节点实体网络强度  $\\kappa_{\\mathrm{Network},i}$", y1="主权承诺可信度  $\\mathrm{Cred}(t)$",
        c_nom="名义免死誓约（宣称）",
        c0="阶段 $t_0$ 承诺可信度 $\\mathrm{Cred}(t_0)$（保有武装）",
        c1="阶段 $t_1$ 缴械后可信度 $\\mathrm{Cred}(t_1) \\to 0$",
        gap="动态不一致性违约缺口",
        anno1="缴械即失防御筹码\n承诺可信度断崖归零",
        x2="防御抱权信号增量  $\\Delta\\hat{\\kappa}_{\\mathrm{HoldPower}}$", y2="君主猜忌度  $\\mathrm{Susp} \\in [0, 1]$",
        traj="抱权—猜忌正反馈螺旋",
        anno2="终局清算奇点\n（和平退路耗竭）",
    ),
    "en": dict(
        t="Figure 8.2.3  Dynamic Inconsistency and the Holding-Power Suspicion Spiral",
        note="Disarmament collapses t1 credibility to zero; defensive holding is misread as coup preparation, locking in escalation",
        pa="Panel A: Credibility drop post-disarmament", pb="Panel B: Phase portrait of holding and suspicion",
        x1="Network strength  $\\kappa_{\\mathrm{Network},i}$", y1="Sovereign credibility  $\\mathrm{Cred}(t)$",
        c_nom="Nominal promise / iron warrant (claimed)",
        c0="Stage $t_0$ credibility $\\mathrm{Cred}(t_0)$ (armed)",
        c1="Stage $t_1$ credibility $\\mathrm{Cred}(t_1) \\to 0$ (disarmed)",
        gap="Dynamic inconsistency default gap",
        anno1="Disarming strips deterrence\nCredibility drops to zero",
        x2="Defensive holding increment  $\\Delta\\hat{\\kappa}_{\\mathrm{HoldPower}}$", y2="Monarch suspicion  $\\mathrm{Susp} \\in [0, 1]$",
        traj="Suspicion–holding amplification spiral",
        anno2="Terminal purge singularity\n(peaceful exit exhausted)",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.4, 6.0), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.80, bottom=0.14, wspace=0.22)

    knet = np.linspace(0.0, 1.0, 240)
    cred_t0 = 1.0 / (1.0 + np.exp(-8.5 * (knet - 0.32)))
    cred_t1 = 0.03 * np.ones_like(knet)
    ax1.plot(knet, np.ones_like(knet), color=P["claimed"], ls="--", lw=1.8, label=d["c_nom"])
    ax1.plot(knet, cred_t0, color=P["actual"], lw=2.8, label=d["c0"])
    ax1.plot(knet, cred_t1, color=P["fear"], lw=2.6, label=d["c1"])
    ax1.fill_between(knet[knet >= 0.32], cred_t1[knet >= 0.32], cred_t0[knet >= 0.32],
                     facecolor="#FBE9E7", edgecolor=P["gap"], hatch="///", alpha=0.28, label=d["gap"])
    ax1.axvline(0.32, color=P["claimed"], ls=":", lw=1.5)
    ax1.annotate(d["anno1"], xy=(0.56, 0.50), xytext=(0.04, 0.70),
                 fontsize=9.4, fontweight="bold", color=P["dead"],
                 arrowprops=dict(arrowstyle="->", color=P["dead"], lw=1.4),
                 bbox=dict(boxstyle="round,pad=0.3", fc="#FFF5F5", ec=P["fear"]))
    ax1.set_xlim(0.0, 1.0); ax1.set_ylim(0, 1.12)
    ax1.set_xlabel(d["x1"], fontsize=10.5); ax1.set_ylabel(d["y1"], fontsize=10.5)
    ax1.set_title(d["pa"], fontsize=11.5, fontweight="bold")
    ax1.legend(loc="center right", bbox_to_anchor=(0.99, 0.28), frameon=True, facecolor="white", edgecolor="none", framealpha=0.88, fontsize=8.4)
    plain_axes(ax1); ax1.grid(axis="y", color=P["grid"], lw=0.6)

    def _vf(hv, sv):
        return 0.55 * sv + 0.08 * hv, 0.48 * hv + 0.16 * sv

    hp, su = np.meshgrid(np.linspace(0.10, 0.90, 13), np.linspace(0.10, 0.90, 13))
    dhp, dsu = _vf(hp, su)
    ax2.quiver(hp, su, dhp, dsu, angles="xy", color=P["claimed"], alpha=0.75)
    h_cur, s_cur, dt_rk = 0.12, 0.10, 0.01
    ht_list, st_list = [h_cur], [s_cur]
    for _ in range(500):
        k1h, k1s = _vf(h_cur, s_cur)
        k2h, k2s = _vf(h_cur + 0.5 * dt_rk * k1h, s_cur + 0.5 * dt_rk * k1s)
        k3h, k3s = _vf(h_cur + 0.5 * dt_rk * k2h, s_cur + 0.5 * dt_rk * k2s)
        k4h, k4s = _vf(h_cur + dt_rk * k3h, s_cur + dt_rk * k3s)
        hn = h_cur + (dt_rk / 6.0) * (k1h + 2.0 * k2h + 2.0 * k3h + k4h)
        sn = s_cur + (dt_rk / 6.0) * (k1s + 2.0 * k2s + 2.0 * k3s + k4s)
        if hn > 0.88 or sn > 0.88:
            break
        h_cur, s_cur = hn, sn
        ht_list.append(h_cur); st_list.append(s_cur)
    ht, st = np.array(ht_list), np.array(st_list)
    ax2.plot(ht, st, color=P["fear"], lw=3.0, label=d["traj"])
    ax2.plot([ht[-1]], [st[-1]], marker="X", ms=12, color=P["dead"], zorder=5)
    ax2.annotate(d["anno2"], xy=(ht[-1], st[-1]), xytext=(0.18, 0.72),
                 fontsize=9.4, fontweight="bold", color=P["dead"],
                 arrowprops=dict(arrowstyle="->", color=P["dead"], lw=1.4),
                 bbox=dict(boxstyle="round,pad=0.3", fc="#FFF5F5", ec=P["dead"]))
    ax2.set_xlim(0.05, 0.96); ax2.set_ylim(0.05, 1.02)
    ax2.set_xlabel(d["x2"], fontsize=10.5); ax2.set_ylabel(d["y2"], fontsize=10.5)
    ax2.set_title(d["pb"], fontsize=11.5, fontweight="bold")
    ax2.legend(loc="upper left", frameon=False, fontsize=8.8)
    plain_axes(ax2); ax2.grid(axis="y", color=P["grid"], lw=0.6)

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.908, d["note"], ha="center", fontsize=9.4, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig8_2_3_holding_trap")

for lg in ("zh", "en"):
    draw(lg)
