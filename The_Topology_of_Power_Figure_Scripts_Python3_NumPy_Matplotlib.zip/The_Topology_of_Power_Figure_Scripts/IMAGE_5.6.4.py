# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.6.4 —— 红绿灯反例的跨期拓扑解

from matplotlib.patches import FancyBboxPatch

L = {
    "zh": dict(
        t="图 5.6.4  红绿灯反例的跨期拓扑解：瞬时被切一格，跨期暴涨",
        note="同一道禁令，两种时间口径给出方向相反的读数",
        h1="瞬时微观视角（$t = 0$）",
        s1="禁止闯红灯",
        s2="删除了「闯红灯」这一片动作",
        s3="瞬时 $\\text{Width}_i$ 发生微小微缩（$\\Delta \\text{Width} < 0$）",
        h2="跨期物理视角（$t \\in [0, \\infty)$）",
        s4="所有人都不闯红灯",
        s5="致命车祸的客观危险率骤降，$\\text{SurvivalFunction}_i(t)$ 抬升",
        s6="未来数十年内拥有成千上万个饱满的 $\\text{Width}_i(t)$",
        s7="终身宽度实现大幅放大：$\\Delta \\text{LifetimeWidth}_i \\gg 0$",
    ),
    "en": dict(
        t="Figure 5.6.4  The traffic-light counterexample solved intertemporally",
        note="One prohibition, two time horizons, opposite readings",
        h1="Instantaneous view ($t = 0$)",
        s1="Running the red light is banned",
        s2="the block of actions called 'jaywalking' is deleted",
        s3="instantaneous $\\text{Width}_i$ shrinks slightly ($\\Delta \\text{Width} < 0$)",
        h2="Intertemporal view ($t \\in [0, \\infty)$)",
        s4="nobody runs the red light",
        s5="the hazard of a fatal crash collapses, $\\text{SurvivalFunction}_i(t)$ rises",
        s6="thousands of full $\\text{Width}_i(t)$ over the coming decades",
        s7="the intertemporal integral expands sharply: $\\Delta \\text{LifetimeWidth}_i \\gg 0$",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(11.2, 7.2), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.86, bottom=0.05, left=0.03, right=0.97)
    ax.set_xlim(0, 12); ax.set_ylim(0, 10); ax.axis("off")

    for y0, hh, hy, kh, col, keys, rows, h in (
            (5.55, 3.40, 9.45, "h1", P["fear"], ("s1", "s2", "s3"),
             (8.15, 7.15, 6.15), 0.72),
            (0.55, 3.70, 4.85, "h2", P["inc"], ("s4", "s5", "s6", "s7"),
             (3.55, 2.75, 1.95, 1.15), 0.62)):
        ax.text(6.00, hy, d[kh], ha="center", va="center",
                fontsize=12.5, fontweight="bold", color=col)
        ax.add_patch(FancyBboxPatch((0.45, y0), 11.10, hh,
                     boxstyle="round,pad=0.05,rounding_size=0.14",
                     facecolor=col, alpha=0.07, edgecolor=col, lw=2.0))
        for i, (y, k) in enumerate(zip(rows, keys)):
            ax.add_patch(FancyBboxPatch((0.85, y - h / 2), 10.30, h,
                         boxstyle="round,pad=0.04,rounding_size=0.10",
                         facecolor=col, alpha=0.15, edgecolor=col, lw=1.6))
            ax.text(6.00, y, d[k], ha="center", va="center",
                    fontsize=10.2, color=P["text"])
            if i:
                ax.annotate("", xy=(6.00, y + h / 2 + 0.03),
                            xytext=(6.00, rows[i - 1] - h / 2 - 0.03),
                            arrowprops=dict(arrowstyle="-|>", color=col, lw=1.8))

    fig.text(0.5, 0.965, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.932, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_6_4_traffic_intertemporal")


for lg in ("zh", "en"):
    draw(lg)
