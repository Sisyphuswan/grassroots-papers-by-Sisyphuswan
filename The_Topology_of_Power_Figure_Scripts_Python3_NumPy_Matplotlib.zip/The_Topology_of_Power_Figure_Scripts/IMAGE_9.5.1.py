# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 9.5.1 —— 局域切平面平坦假象与伦理阻尼极性翻转（中英双语）

import numpy as np

L = {
    "zh": dict(
        t="图 9.5.1  局域切平面平坦假象与伦理阻尼 $\\mathrm{Damp}_{\\mathrm{ethical}}$ 极性翻转",
        note="左栏：每步局部切片均平直合规，全局却加速坠崖；右栏：单点态蒸发正向阻尼，并在责任场翻转后平滑滑入负阻尼共振区",
        pa="A 栏：高曲率全局流形上的局域平坦假象",
        pb="B 栏：伦理阻尼的短板蒸发与极性翻转",
        x1="科层工序步序（微元分工链）", y1="全局系统生存轨迹",
        x2="常识恻隐约束  $\\mathcal{C}_{\\mathrm{empathy}}$（正＝不伤害底线，负＝道德许可翻转）",
        y2="伦理阻尼  $\\mathrm{Damp}_{\\mathrm{ethical}}$",
        glob="全局高曲率坠崖轨道",
        loc="局域平坦切段  $O((\\delta_i/\\mathrm{CurvRadius})^2)\\to 0$",
        gate="守门人开关敏感点（切换引发宏观跳变）",
        elastic="弹性社会（$\\mathrm{Width}>0$）：正向减震生效",
        utopia="单点乌托邦（$\\mathrm{Width}=0$）：正向蒸发，负向共振",
        res="负阻尼正反馈共振区",
    ),
    "en": dict(
        t="Figure 9.5.1  Local Metric Flatness Illusion and Polarity Reversal of $\\mathrm{Damp}_{\\mathrm{ethical}}$",
        note="Left: locally flat compliant micro-steps sum to a global cliff; Right: singleton lock evaporates positive damping and flips smoothly into resonance",
        pa="Panel A: Local flatness illusion on a curved manifold",
        pb="Panel B: Complementarity evaporation & polarity reversal",
        x1="Bureaucratic division steps (micro-task chain)", y1="Global systemic trajectory",
        x2="Common-sense empathy  $\\mathcal{C}_{\\mathrm{empathy}}$ (>0: do-no-harm, <0: moral licensing)",
        y2="Ethical damping  $\\mathrm{Damp}_{\\mathrm{ethical}}$",
        glob="Global high-curvature collapse trajectory",
        loc="Local flat tangent steps  $O((\\delta_i/\\mathrm{CurvRadius})^2)\\to 0$",
        gate="Gatekeeper toggle point (triggers macro jump)",
        elastic="Elastic regime ($\\mathrm{Width}>0$): positive damping active",
        utopia="Singleton utopia ($\\mathrm{Width}=0$): evaporated & inverted",
        res="Negative-damping resonance zone",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.6, 6.1), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.80, bottom=0.15, wspace=0.22)

    s = np.linspace(0, 10, 400)
    g = 1.0 - 0.0085 * (s ** 2.15)
    ax1.plot(s, g, color=P["dead"], lw=2.8, label=d["glob"])
    for k, s0 in enumerate([1.2, 3.0, 4.8, 6.6, 8.4]):
        g0 = 1.0 - 0.0085 * (s0 ** 2.15)
        slope = -0.0085 * 2.15 * (s0 ** 1.15)
        ds = 0.55
        ax1.plot([s0 - ds, s0 + ds], [g0 - slope * ds, g0 + slope * ds],
                 color=P["actual"], lw=3.0, label=d["loc"] if k == 0 else None)
    sg = 6.0; gg = 1.0 - 0.0085 * (sg ** 2.15)
    ax1.scatter([sg], [gg], marker="D", s=95, color=P["fear"], zorder=6, label=d["gate"])
    ax1.set_xlim(0, 10.2); ax1.set_ylim(-0.25, 1.08)
    ax1.set_xlabel(d["x1"], fontsize=10.2); ax1.set_ylabel(d["y1"], fontsize=10.2)
    ax1.set_title(d["pa"], fontsize=11.3, fontweight="bold")
    ax1.legend(loc="lower left", frameon=False, fontsize=8.4)
    plain_axes(ax1); ax1.grid(axis="y", color=P["grid"], lw=0.6)

    c_emp = np.linspace(-1.0, 1.0, 500)
    zeal = 0.85; el_emp = 1.1
    pos_mask = c_emp > 0
    neg_mask = c_emp < 0
    damp_elastic = np.where(pos_mask, 0.72 * (np.maximum(c_emp, 0.0) ** el_emp),
                            -zeal * (np.abs(np.minimum(c_emp, 0.0)) ** el_emp))
    damp_utopia = np.where(pos_mask, 0.0,
                           -zeal * (np.abs(np.minimum(c_emp, 0.0)) ** el_emp))
    ax2.axhspan(-1.0, 0.0, facecolor=P["dead"], alpha=0.10, label=d["res"])
    ax2.axhline(0, color=P["text"], lw=0.9)
    ax2.axvline(0, color=P["claimed"], ls=":", lw=1.4)
    ax2.plot(c_emp, damp_elastic, color=P["good"], lw=2.8, label=d["elastic"])
    ax2.plot(c_emp, damp_utopia, color=P["dead"], ls="--", lw=2.6, label=d["utopia"])
    ax2.scatter([0.0], [0.0], color=P["text"], s=45, zorder=6)
    ax2.set_xlim(-1.02, 1.02); ax2.set_ylim(-0.98, 0.85)
    ax2.set_xlabel(d["x2"], fontsize=9.8); ax2.set_ylabel(d["y2"], fontsize=10.2)
    ax2.set_title(d["pb"], fontsize=11.3, fontweight="bold")
    ax2.legend(loc="upper left", frameon=False, fontsize=8.3)
    plain_axes(ax2); ax2.grid(axis="y", color=P["grid"], lw=0.6)

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.2, fontweight="bold")
    fig.text(0.5, 0.905, d["note"], ha="center", fontsize=9.1, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig9_5_1_ethical_damping")

for lg in ("zh", "en"):
    draw(lg)
