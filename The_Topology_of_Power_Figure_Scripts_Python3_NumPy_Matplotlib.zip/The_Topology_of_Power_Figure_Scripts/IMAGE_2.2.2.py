# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 2.2.2 —— 五维雷达（中英双语）

import numpy as np

L = {
    "zh": dict(
        t="图 2.2.2  θ 的五维雷达：同分不同形",
        note="两条曲线的总分可以接近，但形状完全相反——看形状，不要看总分",
        axes=["广度\nBreadth", "深度\nDepth", "裁量压缩\nInflex",
              "身份敏感\nStatus", "不可撤回\n(1−Elastic)"],
        a="传统家产制：广度高、身份敏感", b="算法治理：广度窄、深度极高",
    ),
    "en": dict(
        t="Figure 2.2.2  Five-axis radar of θ: same score, different shape",
        note="Two profiles may score alike yet have opposite shapes — read the shape, not the score",
        axes=["Breadth", "Depth", "Inflex", "Status", "1−Elastic"],
        a="Classic despotism: broad, identity-bound",
        b="Algorithmic rule: narrow, deep",
    ),
}

A = [0.85, 0.35, 0.70, 0.95, 0.90]
B = [0.20, 0.95, 0.65, 0.25, 0.75]

def draw(lang):
    set_font(lang); d = L[lang]
    fig = plt.figure(figsize=(10.0, 7.0), dpi=200)
    ax = plt.subplot(111, polar=True)
    N = len(d["axes"])
    ang = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist(); ang += ang[:1]
    for vals, col, name in ((A, P["resp"], d["a"]), (B, P["actual"], d["b"])):
        v = vals + vals[:1]
        ax.plot(ang, v, color=col, lw=2.4, label=name)
        ax.fill(ang, v, color=col, alpha=0.18)
    ax.set_xticks(ang[:-1]); ax.set_xticklabels(d["axes"], fontsize=11)
    ax.set_ylim(0, 1); ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["0.25", "0.50", "0.75", "1.00"], fontsize=8, color="#9AA7B4")
    ax.grid(color=P["grid"], lw=0.8); ax.spines["polar"].set_color(P["grid"])
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, -0.22), frameon=False,
              fontsize=10.5, ncol=2)
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig2_2_2_radar_theta")

for lg in ("zh", "en"):
    draw(lg)
