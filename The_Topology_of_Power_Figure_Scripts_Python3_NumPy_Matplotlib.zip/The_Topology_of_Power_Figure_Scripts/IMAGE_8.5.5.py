# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 8.5.5 —— 政治清算五型的结构分化与制度路径（中英双语）

from matplotlib.patches import FancyBboxPatch

L = {
    "zh": dict(
        t="图 8.5.5  政治清算五型的结构分化与制度路径",
        note="合法性缺口闭合方式、节点权力基底与是否拆解组织设备，决定五类历史清算的演化终点",
        root="主权安全威胁与猜忌触发点\n实权越界 ($\\mathrm{RelativeNetworkRatio}_i > \\mathrm{ToleranceCeiling}$)  或  声望／自主猜忌 ($\\mathrm{Inflex} \\to 1,\\; \\mathrm{Susp} \\to 1$)",
        l1a="拆卸制度设备\n（解耦权力载体）",
        l1b="对节点施加肉体与身份清除\n（直接物理清算或原子化肃清）",
        l2a="自上而下清算（君主／中枢清除臣僚）",
        l2b="逆向替代清算\n（权臣行凶后灭口）",
        t5="第五型：结构拆解型\n宋太祖：和平赎买解耦\n（内稳而战力跌破底线）\n朱元璋：屠戮兼废相拆府",
        t1="第一型：废立型\n大功真实、构陷谋反\n案例：汉宣帝诛霍氏全族\n机制：将拥立大功转为\n蓄谋大逆后彻底灭族",
        t2="第二型：复位型\n否定前绩、双重清偿\n案例：明英宗杀于谦及\n夺门功臣（含神龙五王）\n机制：杀无辜立名后收权",
        t4="第四型：先发刈除型\n无实兵而触自主红线\n案例：1937–38 苏联肃反\n机制：罗织罪名与投名状\n互咬实现原子化清场",
        t3="第三型：弑君型\n灭除工具、庇护首脑\n案例：司马昭夷成济三族\n机制：清洗深度与核心\n距离成反比，永未结案",
        bot="共同结构约束：主权领域无法长期容纳独立自主源；缺少第三方中立仲裁时，博弈趋于极化清算或机构拆解。",
    ),
    "en": dict(
        t="Figure 8.5.5  Five-Type Structural Typology and Paths of Elite Purges",
        note="Legitimacy closure mode, node network base, and institutional dismantling split purges into five archetypes",
        root="Sovereign Threat & Suspicion Trigger\nNetwork Breach ($\\mathrm{RelativeNetworkRatio}_i > \\mathrm{ToleranceCeiling}$)  or  Autonomy Suspicion ($\\mathrm{Inflex} \\to 1,\\; \\mathrm{Susp} \\to 1$)",
        l1a="Dismantle Institutional\nDevice (Decouple Nodes)",
        l1b="Physical & Identity Liquidation\n(Direct Elimination or Atomized Purge)",
        l2a="Downward Purge (Monarch / Center -> Officials)",
        l2b="Reversed Purge\n(Kill Tool to Shield Core)",
        t5="Type 5: Structural Dismantling\nSong Taizu: peaceful buyout\n(stable yet weak defense)\nZhu Yuanzhang: purge+abolish",
        t1="Type 1: Deposition Type\nMerit real, treason framed\nCase: Emperor Xuan vs. Huo\nLogic: Recast kingmaking\nas conspiracy, wipe out",
        t2="Type 2: Restoration Type\nMerit denied, double purge\nCase: Yingzong kills Yu Qian\nLogic: Scapegoat hero first,\nthen purge kingmakers",
        t4="Type 4: Pre-emptive Atomization\nNo private army, high Status\nCase: 1937-38 Soviet Terror\nLogic: Fabricate ideology\nguilt & mutual denunciation",
        t3="Type 3: Regicide Type\nKill executor, shield boss\nCase: Sima Zhao vs. Cheng Ji\nLogic: Purge depth inverse\nto distance from core",
        bot="Common structural constraint: Sovereign domain tolerates no autonomous rival; absent third-party arbitration, equilibrium polarizes.",
    ),
}

def _box(ax, cx, cy, w, h, text, fc, ec, tc=None, fs=8.5, bold=False, lw=1.8):
    patch = FancyBboxPatch((cx - w / 2.0, cy - h / 2.0), w, h,
                           boxstyle="round,pad=0.35,rounding_size=1.3",
                           facecolor=fc, edgecolor=ec, lw=lw, zorder=3)
    ax.add_patch(patch)
    ax.text(cx, cy, text, ha="center", va="center",
            fontsize=fs, fontweight=("bold" if bold else "normal"),
            color=(tc if tc else P["text"]), zorder=4, linespacing=1.32)

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(14.4, 8.4), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.88, bottom=0.05, left=0.02, right=0.98)
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")

    arr = dict(arrowstyle="-|>", mutation_scale=13, lw=1.6, color=P["text"], zorder=2)
    _box(ax, 50, 88, 66, 10.5, d["root"], P["actual"], P["actual"], tc="white", fs=10.0, bold=True)

    # Split level 1
    ax.annotate("", xy=(10.5, 73.2), xytext=(32, 82.4), arrowprops=arr)
    ax.annotate("", xy=(60.0, 73.2), xytext=(56, 82.4), arrowprops=arr)
    _box(ax, 10.5, 67, 18.2, 11.0, d["l1a"], P["light_bg"], P["good"], tc=P["good"], fs=8.6, bold=True)
    _box(ax, 60.0, 67, 46.0, 11.0, d["l1b"], P["light_bg"], P["fear"], tc=P["fear"], fs=8.8, bold=True)

    # Type 5 direct child on the left
    ax.annotate("", xy=(10.5, 45.2), xytext=(10.5, 61.0), arrowprops=arr)
    _box(ax, 10.5, 31.0, 17.8, 27.0, d["t5"], "#EDF7F1", P["good"], tc=P["text"], fs=8.0, lw=2.0)

    # Level 2 under physical elimination
    ax.annotate("", xy=(50.0, 56.2), xytext=(55.0, 61.0), arrowprops=arr)
    ax.annotate("", xy=(89.5, 56.2), xytext=(72.0, 61.0), arrowprops=arr)
    _box(ax, 50.0, 52.0, 44.0, 7.5, d["l2a"], P["omega"], P["fear"], tc=P["fear"], fs=8.6, bold=True)
    _box(ax, 89.5, 52.0, 18.2, 7.5, d["l2b"], P["omega"], P["dead"], tc=P["dead"], fs=8.2, bold=True)

    # Leaves Type 1, 2, 4, 3
    ax.annotate("", xy=(30.2, 45.2), xytext=(40.0, 48.0), arrowprops=arr)
    ax.annotate("", xy=(50.0, 45.2), xytext=(50.0, 48.0), arrowprops=arr)
    ax.annotate("", xy=(69.8, 45.2), xytext=(60.0, 48.0), arrowprops=arr)
    ax.annotate("", xy=(89.5, 45.2), xytext=(89.5, 48.0), arrowprops=arr)

    _box(ax, 30.2, 31.0, 17.8, 27.0, d["t1"], "#FDF2F1", P["fear"], tc=P["text"], fs=8.0, lw=2.0)
    _box(ax, 50.0, 31.0, 17.8, 27.0, d["t2"], "#FDF2F1", P["fear"], tc=P["text"], fs=8.0, lw=2.0)
    _box(ax, 69.8, 31.0, 17.8, 27.0, d["t4"], "#FEF3C7", "#D97706", tc=P["text"], fs=8.0, lw=2.0)
    _box(ax, 89.5, 31.0, 17.8, 27.0, d["t3"], "#FBE9E7", P["dead"], tc=P["text"], fs=8.0, lw=2.0)

    _box(ax, 50, 8.0, 96, 8.2, d["bot"], P["light_bg"], P["claimed"], tc=P["text"], fs=9.0, lw=1.2)

    fig.text(0.5, 0.96, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.918, d["note"], ha="center", fontsize=9.2, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig8_5_5_purge_five_types")

for lg in ("zh", "en"):
    draw(lg)
