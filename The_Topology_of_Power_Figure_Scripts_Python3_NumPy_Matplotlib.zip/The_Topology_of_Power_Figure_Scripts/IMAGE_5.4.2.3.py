# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.4.2.3 —— 雷达二：公开剧本与隐藏剧本的背离度

from matplotlib.patches import FancyBboxPatch

L = {
    "zh": dict(
        t="图 5.4.2.3  雷达二（公开剧本与隐藏剧本的背离度）",
        note="把观察面从台上移到关上门之后",
        test="关上门后的言行",
        a="与台上讲话背离\n压缩型：偏好与行为分离",
        b="与台上讲话高度一致\n内化型：偏好与行为统一（已完成同化）",
    ),
    "en": dict(
        t="Figure 5.4.2.3  Radar two (the gap between public and hidden scripts)",
        note="Move the observation surface from the podium to behind the door",
        test="Words behind closed doors",
        a="diverges from the podium speech\ncompressed: preference split from conduct",
        b="consistent with the podium speech\ninternalised: preference aligned with conduct",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(10.6, 4.4), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.80, bottom=0.05, left=0.03, right=0.97)
    ax.set_xlim(0, 12); ax.set_ylim(1.20, 8.90); ax.axis("off")

    ax.add_patch(FancyBboxPatch((0.35, 3.40), 3.10, 3.20,
                 boxstyle="round,pad=0.05,rounding_size=0.14",
                 facecolor="#EDEFF2", edgecolor="#9AA7B4", lw=2.0))
    ax.text(1.90, 5.00, d["test"], ha="center", va="center",
            fontsize=12.5, fontweight="bold", color=P["text"])

    for y, k, col in ((6.55, "a", P["inc"]), (1.85, "b", P["fear"])):
        ax.annotate("", xy=(5.10, y + 0.85), xytext=(3.55, 5.00),
                    arrowprops=dict(arrowstyle="->", color=col, lw=2.2))
        ax.add_patch(FancyBboxPatch((5.15, y - 0.30), 6.50, 2.30,
                     boxstyle="round,pad=0.05,rounding_size=0.14",
                     facecolor=col, alpha=0.15, edgecolor=col, lw=2.2))
        ax.text(8.40, y + 0.85, d[k], ha="center", va="center",
                fontsize=11.2, fontweight="bold", color=col)

    fig.text(0.5, 0.945, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.885, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_4_2_3_radar2_scripts")


for lg in ("zh", "en"):
    draw(lg)
