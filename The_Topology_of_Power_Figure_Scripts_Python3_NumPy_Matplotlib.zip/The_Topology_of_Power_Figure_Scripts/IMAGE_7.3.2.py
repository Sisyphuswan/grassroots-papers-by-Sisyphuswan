# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 7.3.2 —— 卸责行为的阶跃函数画像

import numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

def draw(lang):
    set_font(lang)
    fig, ax = plt.subplots(figsize=(10.8, 6.0), dpi=200)
    t = np.linspace(0, 10, 500)
    t_cmd = 5.0
    
    # Work line: proactive baseline, then meets order requirement
    y_work = np.where(t < t_cmd, 0.45, 1.05)
    
    # Shirk line: flat zero before command, vertical step and overshoots after command
    y_shirk = np.where(t < t_cmd, 0.05, 1.55)
    
    ax.plot(t, y_work, color=P["inc"], lw=3.0, label="实干策略 (主动适度作为)" if lang=="zh" else "Real Work (Proactive)")
    ax.plot(t, y_shirk, color=P["dead"], lw=3.2, label="卸责策略 (无指令贴零，有指令过冲)" if lang=="zh" else "Shirking Strategy (Step Function)")
    
    ax.axhline(1.0, color=P["claimed"], ls="--", lw=1.8, label="上级指令要求基准线" if lang=="zh" else "Baseline Order Requirement")
    ax.axvline(t_cmd, color=P["grid"], ls=":", lw=2.0)
    
    # Annotations
    ax.text(t_cmd + 0.15, 0.20, "指令下达时刻" if lang=="zh" else "Order Issued", fontsize=9.5, color="#5C6773", fontweight="bold")
    ax.text(2.5, 0.15, "无指令期：贴零不动（规避风险）" if lang=="zh" else "Pre-order: Zero action (Risk avoidance)", ha="center", fontsize=9.5, color=P["dead"])
    ax.text(7.5, 1.62, "有指令期：层层加码、过度执行（程序免责）" if lang=="zh" else "Post-order: Overshooting (Legal defense)", ha="center", fontsize=9.5, color=P["dead"])
    
    ax.add_patch(FancyArrowPatch((7.5, 1.05), (7.5, 1.52), arrowstyle="<|-|>", mutation_scale=14, color=P["dead"], lw=1.8))
    ax.text(7.65, 1.28, "过冲加码截面" if lang=="zh" else "Overshoot Margin", fontsize=9.0, color=P["dead"])
    
    ax.set_xlim(0, 10); ax.set_ylim(0, 1.9)
    ax.set_xlabel("时间进程" if lang=="zh" else "Time", fontsize=11.0)
    ax.set_ylabel("行动烈度与执行负荷" if lang=="zh" else "Enforcement Volume", fontsize=11.0)
    ax.set_title("图 7.3.2  「卸责」的行为形态是一条阶跃线，而非平直零线" if lang=="zh" else "Figure 7.3.2 Shirking is a Step Function, Not a Flat Zero Line", fontsize=12.5, fontweight="bold")
    ax.legend(loc="upper left", frameon=False, fontsize=9.5)
    plain_axes(ax); ax.grid(True, ls=":", color=P["grid"], alpha=0.6)
    footer(fig, lang); save(fig, lang, "fig7_3_2_shirking_step")

for lg in ("zh", "en"):
    draw(lg)
