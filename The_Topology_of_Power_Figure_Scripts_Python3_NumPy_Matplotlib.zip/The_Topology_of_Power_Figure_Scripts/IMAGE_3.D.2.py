# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 3.D.2 —— 外生微观试探的事件研究法

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 3.D.2  外生微观试探的事件研究法",
        note="不问它说了什么，只问它做没做——一次没到场，就是一次难以伪造的破壁事实",
        a="外生偶然事件冲击\n（某地发生微小聚集）",
        q="体制的暴力机器在标准响应时限 Deadline* 内\n是否物理现身惩戒？",
        y1="迅速抓捕平息\n证实 κ 依然在线",
        n1="未能现身 / 毫无反应\n证实已跌入截断区：Support(κ_State) 失守",
        z="引发周围人群的试探级联\n同类言论与聚集指数呈非连续性暴涨",
        yes="是", no="否",
    ),
    "en": dict(
        t="Figure 3.D.2  Probing event study: measuring κ from the outside",
        note="Ask not what it says, but what it does — one no-show is a hard-to-fake fact",
        a="Exogenous shock\n(a small gathering somewhere)",
        q="Does the coercive apparatus physically\nshow up within Deadline*?",
        y1="Swift arrest and dispersal\nκ is still online",
        n1="No appearance / no response\nTruncation zone breached: Support(κ_State) lost",
        z="Cascade of local probing\nDissident speech and gatherings spike discontinuously",
        yes="Yes", no="No",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(11.0, 8.2), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.87, bottom=0.03, left=0.03, right=0.97)
    ax.set_xlim(0, 11); ax.set_ylim(0, 11); ax.axis("off")

    def box(x, y, w, h, col, txt, fs=10.2, bold=False, alpha=0.14):
        ax.add_patch(FancyBboxPatch((x, y), w, h,
                     boxstyle="round,pad=0.10,rounding_size=0.12",
                     facecolor=col, alpha=alpha, edgecolor=col, lw=1.9))
        ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center",
                fontsize=fs, color=col if bold else P["text"],
                fontweight="bold" if bold else "normal")

    box(3.10, 9.05, 4.80, 1.10, P["claimed"], d["a"], 11.0, True)
    ax.add_patch(FancyArrowPatch((5.50, 9.00), (5.50, 8.42),
                 arrowstyle="-|>", mutation_scale=18, color=P["text"], lw=1.7))
    box(2.60, 7.00, 5.80, 1.40, P["actual"], d["q"], 11.0, True)
    ax.plot([5.50, 5.50], [6.95, 6.45], color=P["text"], lw=1.7)
    ax.plot([2.55, 8.45], [6.45, 6.45], color=P["text"], lw=1.7)
    ax.add_patch(FancyArrowPatch((2.55, 6.45), (2.55, 5.82),
                 arrowstyle="-|>", mutation_scale=18, color=P["good"], lw=1.7))
    ax.add_patch(FancyArrowPatch((8.45, 6.45), (8.45, 5.82),
                 arrowstyle="-|>", mutation_scale=18, color=P["dead"], lw=1.7))
    ax.text(2.30, 6.13, d["yes"], ha="right", va="center", fontsize=10.0, color=P["good"])
    ax.text(8.70, 6.13, d["no"], ha="left", va="center", fontsize=10.0, color=P["dead"])
    box(0.55, 4.10, 4.00, 1.72, P["good"], d["y1"], 10.2)
    box(6.45, 4.10, 4.00, 1.72, P["dead"], d["n1"], 10.2)
    ax.add_patch(FancyArrowPatch((8.45, 4.05), (8.45, 3.42),
                 arrowstyle="-|>", mutation_scale=18, color=P["dead"], lw=1.7))
    box(4.90, 1.70, 5.20, 1.72, P["gap"], d["z"], 10.2)
    fig.text(0.5, 0.962, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.925, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig3_d_2_probing")

for lg in ("zh", "en"):
    draw(lg)
