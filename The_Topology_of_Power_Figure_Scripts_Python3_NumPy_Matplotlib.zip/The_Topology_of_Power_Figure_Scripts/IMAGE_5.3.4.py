# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.3.4 —— 单点态的脆断机理

from matplotlib.patches import FancyBboxPatch

L = {
    "zh": dict(
        t="图 5.3.4  单点态的脆断机理：从超稳假象到非连续相变",
        note="稳定性寄生在威慑乘数之上，边界挪动一微米即全局重张",
        s1="宏观表象：钢板一块，人人顺从，秩序井然（超稳假象）",
        s2="微观实质：每个个体的可行行动域被强行压成单点（内部积聚应力）",
        s3="微小外部扰动：$\\kappa$ 跌破阈值，恐惧场红线后撤一毫米",
        s4="瞬间为所有人释放出一个非零邻域",
        s5="全社会爆发非连续的拓扑相变（Topological Burst）",
        s5b="昨天还是万岁欢呼，今天就土崩瓦解",
    ),
    "en": dict(
        t="Figure 5.3.4  The brittle rupture of the singleton state: from false stability to a jump",
        note="Stability rests on the deterrence multiplier; shift a boundary by a hair and all reopen",
        s1="Surface: a single steel plate — everyone compliant, order intact",
        s2="Substance: every action domain flattened to a point (stress accumulates)",
        s3="Tiny shock: $\\kappa$ breaks the threshold, the red line retreats a millimetre",
        s4="Instantly a non-zero neighbourhood opens for everyone at once",
        s5="Society undergoes a discontinuous topological transition (burst)",
        s5b="cheering yesterday, rubble today",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(10.6, 8.2), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.90, bottom=0.03, left=0.05, right=0.95)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")

    rows = [("s1", 8.75, "#EDEFF2", "#9AA7B4", P["text"], 1.05),
            ("s2", 7.05, P["cost"], P["cost"], P["text"], 1.05),
            ("s3", 5.35, P["actual"], P["actual"], P["text"], 1.05),
            ("s4", 3.95, P["fear"], P["fear"], P["dead"], 0.80),
            ("s5", 2.05, P["dead"], P["dead"], P["dead"], 1.35)]
    for k, y, fc, ec, tc, h in rows:
        ax.add_patch(FancyBboxPatch((0.45, y - h / 2), 9.10, h,
                     boxstyle="round,pad=0.05,rounding_size=0.14",
                     facecolor=fc, alpha=0.16 if k != "s1" else 1.0,
                     edgecolor=ec, lw=2.2))
        ax.text(5.00, y, d[k], ha="center", va="center",
                fontsize=11.4, fontweight="bold" if k in ("s1", "s5") else "normal",
                color=tc)
    ax.text(5.00, 1.28, d["s5b"], ha="center", va="center",
            fontsize=9.6, color="#7A828C", style="italic")

    for y0, y1 in ((8.22, 7.60), (6.52, 5.90), (4.82, 4.37), (3.55, 2.75)):
        ax.annotate("", xy=(5.00, y1), xytext=(5.00, y0),
                    arrowprops=dict(arrowstyle="-|>", color="#5C6773", lw=2.2))

    fig.text(0.5, 0.965, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.932, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_3_4_single_point_rupture")


for lg in ("zh", "en"):
    draw(lg)
