# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 9.2.1 —— 去边界投影算子 P_strip 与琴生不等式双重折损（中英双语）

import numpy as np

L = {
    "zh": dict(
        t="图 9.2.1  去边界投影算子 $\\mathcal{P}_{\\mathrm{strip}}$ 与琴生不等式双重折损",
        note="试验极值本身符合真科学，但剥离理想条件外推为全局指标后，必然叠加坡度偏误与方差折损",
        x="正向边界条件水平 $C$（水肥、管护与生态缓冲）",
        y="单位耕地物理产出  $\\mathrm{ProdFunc}(\\mathrm{InputScale}, C)$",
        curve="真实凹性生产函数  $\\mathrm{ProdFunc}(\\cdot, C)$",
        claimed="去边界外推宣称定额  $\\Pi_{\\mathrm{claimed}}$",
        chord="异质大田期望弦线",
        p_ideal="理想试验站\n$C_{\\mathrm{ideal}}$",
        p_mean="现实均值产出\n$\\mathrm{ProdFunc}(\\mathbb{E}[C_\\omega])$",
        p_exp="真实期望产出\n$\\mathbb{E}_\\omega[\\mathrm{ProdFunc}(C_\\omega)]$",
        gap_bias="均值偏误落差\n（理想 vs 平均大田）",
        gap_jensen="琴生方差折损\n（空间异质性凹性惩罚）",
    ),
    "en": dict(
        t="Figure 9.2.1  Boundary-Stripping Projection $\\mathcal{P}_{\\mathrm{strip}}$ and Dual Jensen Loss",
        note="Lab yield is scientifically valid under ideal conditions, yet stripping boundaries produces dual mean and variance losses",
        x="Favorable boundary condition vector $C$ (water, soil, care)",
        y="Physical yield  $\\mathrm{ProdFunc}(\\mathrm{InputScale}, C)$",
        curve="True concave production function  $\\mathrm{ProdFunc}(\\cdot, C)$",
        claimed="Stripped claimed quota  $\\Pi_{\\mathrm{claimed}}$",
        chord="Chord over heterogeneous fields",
        p_ideal="Ideal lab station\n$C_{\\mathrm{ideal}}$",
        p_mean="Yield at mean condition\n$\\mathrm{ProdFunc}(\\mathbb{E}[C_\\omega])$",
        p_exp="True expected yield\n$\\mathbb{E}_\\omega[\\mathrm{ProdFunc}(C_\\omega)]$",
        gap_bias="Mean-bias gap\n(ideal vs. field mean)",
        gap_jensen="Jensen variance loss\n(concavity penalty)",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(10.2, 6.2), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.82, bottom=0.14, left=0.10, right=0.95)

    c = np.linspace(0.5, 10.5, 400)
    f = lambda x: 1.0 - np.exp(-0.34 * x)
    y = f(c)

    c1, c2 = 1.6, 5.4
    c_mean = 0.5 * (c1 + c2)
    c_ideal = 9.2
    y1, y2 = f(c1), f(c2)
    y_mean = f(c_mean)
    y_exp = 0.5 * (y1 + y2)
    y_ideal = f(c_ideal)

    ax.plot(c, y, color=P["actual"], lw=2.8, label=d["curve"])
    ax.hlines(y_ideal, 0.5, c_ideal, colors=P["claimed"], linestyles="--", lw=2.2, label=d["claimed"])
    ax.plot([c1, c2], [y1, y2], color=P["cost"], ls="-.", lw=2.2, label=d["chord"])
    ax.scatter([c1, c2], [y1, y2], color=P["cost"], s=48, zorder=5)
    ax.scatter([c_ideal], [y_ideal], color=P["claimed"], s=70, zorder=6)
    ax.scatter([c_mean], [y_mean], color=P["actual"], s=68, zorder=6)
    ax.scatter([c_mean], [y_exp], color=P["dead"], s=68, zorder=6)

    ax.vlines(c_ideal, 0, y_ideal, colors=P["claimed"], linestyles=":", lw=1.4)
    ax.vlines(c_mean, 0, y_ideal, colors=P["grid"], linestyles=":", lw=1.4)
    ax.fill_between([c_mean - 0.14, c_mean + 0.14], y_mean, y_ideal,
                    facecolor="#FBE9E7", edgecolor=P["gap"], hatch="///", alpha=0.45)
    ax.fill_between([c_mean - 0.14, c_mean + 0.14], y_exp, y_mean,
                    facecolor="#FFF3E0", edgecolor=P["cost"], hatch="///", alpha=0.55)

    ax.annotate(d["p_ideal"], xy=(c_ideal, y_ideal), xytext=(c_ideal - 0.9, y_ideal - 0.16),
                fontsize=9.2, fontweight="bold", color=P["text"],
                arrowprops=dict(arrowstyle="->", color=P["claimed"], lw=1.3))
    ax.annotate(d["p_mean"], xy=(c_mean, y_mean), xytext=(0.75, 0.72),
                fontsize=9.0, color=P["actual"], fontweight="bold",
                arrowprops=dict(arrowstyle="->", color=P["actual"], lw=1.3))
    ax.annotate(d["p_exp"], xy=(c_mean, y_exp), xytext=(c_mean + 0.9, y_exp - 0.17),
                fontsize=9.0, color=P["dead"], fontweight="bold",
                arrowprops=dict(arrowstyle="->", color=P["dead"], lw=1.3))
    ax.annotate(d["gap_bias"], xy=(c_mean - 0.16, 0.5 * (y_mean + y_ideal)), xytext=(0.75, 0.87),
                fontsize=9.0, color=P["gap"], fontweight="bold",
                arrowprops=dict(arrowstyle="->", color=P["gap"], lw=1.3))
    ax.annotate(d["gap_jensen"], xy=(c_mean + 0.16, 0.5 * (y_exp + y_mean)), xytext=(c_mean + 1.5, 0.62),
                fontsize=9.0, color=P["cost"], fontweight="bold",
                arrowprops=dict(arrowstyle="->", color=P["cost"], lw=1.3))

    ax.set_xlim(0.5, 10.6); ax.set_ylim(0.25, 1.08)
    ax.set_xlabel(d["x"], fontsize=10.5); ax.set_ylabel(d["y"], fontsize=10.5)
    ax.legend(loc="lower right", frameon=False, fontsize=9.0)
    plain_axes(ax); ax.grid(axis="y", color=P["grid"], lw=0.6)
    fig.text(0.5, 0.945, d["t"], ha="center", fontsize=13.2, fontweight="bold")
    fig.text(0.5, 0.895, d["note"], ha="center", fontsize=9.3, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig9_2_1_jensen_projection")

for lg in ("zh", "en"):
    draw(lg)
