# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 2.2.4.1 —— 穿透成本结构对比（中英双语）

import numpy as np
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 2.2.4.1  穿透成本结构：传统科层 vs 算法治理",
        note="算法没有改变统治的意图，它改变的是成本方程",
        steps=["收集信息", "层层上报", "人工审批", "下达批复"],
        lag=["天/月", "天/月", "天", "天"],
        x="穿透深度（Depth）", y="边际监管成本",
        c1="传统纸质与科层", c2="现代算法与平台",
        tag1="指数级攀升", tag2="维持平坦低位",
    ),
    "en": dict(
        t="Figure 2.2.4.1  Cost structure of penetration: bureaucracy vs algorithms",
        note="Algorithms did not change the intent to rule — they changed the cost equation",
        steps=["Collect", "Report up", "Review", "Order down"],
        lag=["days/mos", "days/mos", "days", "days"],
        x="Depth of penetration", y="Marginal cost of oversight",
        c1="Paper bureaucracy", c2="Algorithmic platform",
        tag1="exponential rise", tag2="near-flat low level",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.2, 5.2), dpi=200,
                                   gridspec_kw={"width_ratios": [1.15, 1.0]})
    fig.patch.set_facecolor("white")
    ax1.set_xlim(0, 10); ax1.set_ylim(0, 10); ax1.axis("off")
    ys = [8.2, 6.1, 4.0, 1.9]
    for y, s, g in zip(ys, d["steps"], d["lag"]):
        ax1.add_patch(FancyBboxPatch((1.0, y), 6.2, 1.15,
                      boxstyle="round,pad=0.06,rounding_size=0.10",
                      facecolor="#EDEFF2", edgecolor=P["claimed"], lw=1.2))
        ax1.text(4.1, y + 0.58, s, ha="center", va="center", fontsize=11)
        ax1.text(8.0, y + 0.58, g, ha="center", va="center",
                 fontsize=9, color="#7A828C")
    for y in ys[:-1]:
        ax1.add_patch(FancyArrowPatch((4.1, y), (4.1, y - 0.95),
                     arrowstyle="-|>", mutation_scale=15, color=P["text"], lw=1.6))
    ax1.text(5.0, 9.6, d["c1"], ha="center", fontsize=11.5, color=P["text"])
    ax2.set_xlim(0, 1); ax2.set_ylim(0, 1); plain_axes(ax2)
    x = np.linspace(0, 1, 300)
    ax2.plot(x, np.clip(0.06 * np.exp(4.6 * x), 0, 1), color=P["cost"], lw=3.0)
    ax2.plot(x, 0.12 + 0.05 * x, color=P["actual"], lw=3.0)
    ax2.text(0.80, 0.86, d["c1"], ha="center", fontsize=10.5, color=P["cost"])
    ax2.text(0.80, 0.52, d["tag1"], ha="center", fontsize=9, color=P["cost"])
    ax2.text(0.30, 0.30, d["c2"], ha="center", fontsize=10.5, color=P["actual"])
    ax2.text(0.30, 0.22, d["tag2"], ha="center", fontsize=9, color=P["actual"])
    ax2.set_xlabel(d["x"], fontsize=11); ax2.set_ylabel(d["y"], fontsize=11)
    ax2.grid(axis="y", color=P["grid"], lw=0.6)
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.912, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig2_2_4_1_penetration_cost")

for lg in ("zh", "en"):
    draw(lg)
