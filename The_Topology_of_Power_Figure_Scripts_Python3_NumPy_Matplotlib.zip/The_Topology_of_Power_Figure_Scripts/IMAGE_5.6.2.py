# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.6.2 —— 因果影响 vs 拓扑构成

from matplotlib.patches import FancyBboxPatch, Circle, Ellipse

L = {
    "zh": dict(
        t="图 5.6.2  因果影响与拓扑构成：可以移动那面墙，不能替他跨出那一步",
        note="$i \\neq j$ 时，$\\text{ChosenAction}_i$ 在类型上永远进不了 $A_j$",
        aj="主体 $j$ 的可行行动域  $A_j$",
        aj2="$A_j \\equiv \\Pi_{\\text{Incentive}} \\cap \\Pi_{\\text{Fear}} \\cap \\Pi_{\\text{Responsibility}}$\n（全部来自 $j$ 自身的可能动作）",
        ai="主体 $i$ 的可行行动域  $A_i$",
        el="元素  $\\text{ChosenAction}_i \\in A_i$",
        c1="因果影响（Causation）· 外生",
        c1d="颁布禁令、提供施舍，剧烈移动 $j$ 身边的三场边界",
        c2="拓扑构成（Constitution）· 内生",
        c2d="一个动作若须依赖 $i$ 的特许豁免，它从未进入 $A_j$",
    ),
    "en": dict(
        t="Figure 5.6.2  Causal influence vs topological constitution",
        note="When $i \\neq j$, $\\text{ChosenAction}_i$ can never be an element of $A_j$",
        aj="Action domain of agent $j$  $A_j$",
        aj2="$A_j \\equiv \\Pi_{\\text{Incentive}} \\cap \\Pi_{\\text{Fear}} \\cap \\Pi_{\\text{Responsibility}}$\n(all from $j$'s own possible acts)",
        ai="Action domain of agent $i$  $A_i$",
        el="element  $\\text{ChosenAction}_i \\in A_i$",
        c1="Causation · exogenous",
        c1d="issue bans, give alms, shift the three boundaries around $j$",
        c2="Constitution · endogenous",
        c2d="an act needing $i$'s licence never entered $A_j$ at all",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(11.0, 6.6), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.85, bottom=0.08, left=0.03, right=0.97)
    ax.set_xlim(0, 12); ax.set_ylim(0, 10); ax.axis("off")

    ax.add_patch(FancyBboxPatch((0.45, 4.65), 4.60, 4.10,
                 boxstyle="round,pad=0.05,rounding_size=0.16",
                 facecolor=P["actual"], alpha=0.10, edgecolor=P["actual"], lw=2.4))
    ax.text(2.75, 8.30, d["aj"], ha="center", va="center",
            fontsize=12.5, fontweight="bold", color=P["actual"])
    ax.text(2.75, 6.90, d["aj2"], ha="center", va="center",
            fontsize=9.8, color=P["text"])

    ax.add_patch(FancyBboxPatch((6.95, 4.65), 4.60, 4.10,
                 boxstyle="round,pad=0.05,rounding_size=0.16",
                 facecolor=P["inc"], alpha=0.16, edgecolor=P["inc"], lw=2.4))
    ax.text(9.25, 8.30, d["ai"], ha="center", va="center",
            fontsize=12.5, fontweight="bold", color="#1F5C40")
    ax.add_patch(Ellipse((9.25, 6.35), 2.55, 0.66, facecolor=P["inc"], alpha=0.85,
                         edgecolor="white", lw=1.6))
    ax.text(9.25, 6.35, "$\\text{ChosenAction}_i$", ha="center", va="center", color="white",
            fontsize=8.6, fontweight="bold")
    ax.text(9.25, 5.40, d["el"], ha="center", va="center",
            fontsize=9.8, color=P["text"])

    ax.annotate("", xy=(5.20, 7.60), xytext=(6.80, 7.60),
                arrowprops=dict(arrowstyle="-|>", color=P["fear"], lw=2.6, ls="--"))
    ax.plot([5.86, 6.14], [7.42, 7.78], color=P["dead"], lw=2.8, zorder=6)
    ax.plot([5.86, 6.14], [7.78, 7.42], color=P["dead"], lw=2.8, zorder=6)
    ax.text(6.00, 7.98, "$i \\neq j$\n$\\text{ChosenAction}_i \\notin A_j$", ha="center", va="bottom",
            fontsize=8.6, color=P["dead"], fontweight="bold")

    ax.add_patch(FancyBboxPatch((0.45, 0.60), 5.30, 2.85,
                 boxstyle="round,pad=0.05,rounding_size=0.14",
                 facecolor=P["fear"], alpha=0.12, edgecolor=P["fear"], lw=2.0))
    ax.text(3.10, 2.90, d["c1"], ha="center", va="center",
            fontsize=11.5, fontweight="bold", color=P["dead"])
    ax.text(3.10, 1.95, d["c1d"], ha="center", va="center",
            fontsize=9.8, color=P["text"])

    ax.add_patch(FancyBboxPatch((6.25, 0.60), 5.30, 2.85,
                 boxstyle="round,pad=0.05,rounding_size=0.14",
                 facecolor="#5C6773", alpha=0.12, edgecolor="#5C6773", lw=2.0))
    ax.text(8.90, 2.90, d["c2"], ha="center", va="center",
            fontsize=11.5, fontweight="bold", color="#3A424C")
    ax.text(8.90, 1.95, d["c2d"], ha="center", va="center",
            fontsize=9.8, color=P["text"])

    ax.annotate("", xy=(3.10, 3.60), xytext=(3.10, 4.55),
                arrowprops=dict(arrowstyle="-|>", color=P["fear"], lw=2.2))
    ax.annotate("", xy=(8.90, 3.60), xytext=(8.90, 4.55),
                arrowprops=dict(arrowstyle="-|>", color="#5C6773", lw=2.2,
                                ls="dashed"))

    fig.text(0.5, 0.965, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.932, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_6_2_cause_vs_constitute")


for lg in ("zh", "en"):
    draw(lg)
