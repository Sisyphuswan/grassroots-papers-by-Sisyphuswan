# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 6.4.1 —— 选择广度（Width）的非单调响应（中英双语）

import numpy as np, matplotlib.pyplot as plt

L = {
    "zh": dict(t="图 6.4.1  $\\text{Width}$ 对 $\\kappa_{\\text{State}}$ 的非单调响应：规制放松引发行为爆发",
               x="兑现力 $\\kappa_{\\text{State}}$（向右＝衰退）", y="选择广度 $\\text{Width}$",
               lock="1 锁死：恐惧场约束可信，$\\text{Width}$ 极小",
               slow="2 缓升：连续平滑通道，$\\text{Width}$ 渐进扩张",
               burst="3 爆裂：威慑祛魅事件\n→ 不连续拓扑张开",
               disc="不连续跳变截面",
               note="连续微分方程仅能刻画通道 2；通道 3 依赖微观主体共同观察到的离散公共事件。"),
    "en": dict(t="Figure 6.4.1  The non-monotone response of $\\text{Width}$ to $\\kappa_{\\text{State}}$: why relaxation brings eruption",
               x="Capacity $\\kappa_{\\text{State}}$ (rightward = decline)", y="Width of freedom $\\text{Width}$",
               lock="(i) Locked: fear is credible, $\\text{Width}$ is small",
               slow="(ii) Gradual rise: the continuous channel",
               burst="(iii) Burst: deterrence disenchantment\n→ discontinuous opening",
               disc="Discontinuous jump",
               note="Continuous equations yield only (ii); (iii) requires a publicly observed discrete event."),
}

def draw(lang):
    set_font(lang); d = L[lang]
    k = np.linspace(0, 1, 500)
    k_burst = 0.22
    disc_inc = 0.30 + 0.65 * k
    disc_fear_perceived = np.minimum(0.95, 0.30 + 0.65 * k)
    W_pre = 1.6 * disc_inc * (1.0 - disc_fear_perceived)
    W_post = 1.6 * disc_inc  # 祛魅后恐惧压制因素坍缩，仅余公共品与激励底座随 k -> 0 萎缩
    Wc_pre = float(np.interp(k_burst, k, W_pre))
    Wc_post = float(np.interp(k_burst, k, W_post))
    fig, ax = plt.subplots(figsize=(11.0, 6.4), dpi=200)
    ax.plot(k[k >= k_burst], W_pre[k >= k_burst], color=P["actual"], lw=3.0)
    ax.plot(k[k <= k_burst], W_post[k <= k_burst], color=P["inc"], lw=3.0)
    ax.axvline(k_burst, color=P["gap"], lw=1.6, ls=":")
    ax.plot([k_burst, k_burst], [Wc_pre, Wc_post], color=P["dead"], lw=3.2, ls="--")
    ax.annotate(d["disc"], xy=(k_burst, 0.5 * (Wc_pre + Wc_post)), xytext=(0.46, 0.64),
                fontsize=11, color=P["dead"], fontweight="bold",
                arrowprops=dict(arrowstyle="->", color=P["dead"], lw=1.5))
    ax.text(0.97, 0.04, d["lock"], fontsize=10.5, color=P["actual"], ha="left", va="bottom")
    ax.text(0.54, 0.25, d["slow"], fontsize=10.5, color=P["actual"], ha="center", va="bottom")
    ax.text(0.11, 0.78, d["burst"], fontsize=10.2, color=P["inc"],
            fontweight="bold", ha="center", va="bottom")
    ax.set_xlim(1, 0); ax.set_ylim(0, 1.02)
    ax.set_xlabel(d["x"], fontsize=11.5); ax.set_ylabel(d["y"], fontsize=11.5)
    plain_axes(ax); ax.grid(axis="y", color=P["grid"], lw=0.6)
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig6_4_1_Width_nonmonotone")

for lg in ("zh", "en"):
    draw(lg)
