# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 2.5.2 —— 资源分流剪刀差 + 倒 U 曲线（中英双语）

import numpy as np

L = {
    "zh": dict(
        t="图 2.5.2  资源分流剪刀差与承载力天花板",
        note="两端皆失稳：左端被合规与监管成本耗尽，右端被失序损耗吞噬",
        c_enf="监管执行成本  EnforcementCost", c_def="合规防御耗散  ComplianceCost",
        c_ord="失序损耗  DisorderLoss", pp="社会总生产产出（净生产）  Output(θ)",
        y1="资源份额", y2="承载力天花板  κ_Ceiling(θ)", xt="θ  →  0  …  1",
        desp="专制利维坦陷阱", abs_="缺席利维坦", corr="窄廊最优",
        lvl="实际水位  κ_State（后续章节）",
    ),
    "en": dict(
        t="Figure 2.5.2  The scissors of resource diversion and the capacity ceiling",
        note="Both ends die: the left is eaten by compliance and enforcement, the right by disorder",
        c_enf="Enforcement cost  EnforcementCost", c_def="Compliance defence  ComplianceCost",
        c_ord="Disorder loss  DisorderLoss", pp="Net product  Output(θ)",
        y1="Share of resources", y2="Capacity ceiling  κ_Ceiling(θ)", xt="θ  →  0  …  1",
        desp="Despotic trap", abs_="Absent leviathan", corr="Narrow corridor",
        lvl="Actual level  κ_State (later chapters)",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    th = np.linspace(0, 1, 400)
    C_enf = 0.53 * (1 - th) ** 2.0
    C_def = 0.47 * (1 - th) ** 2.6
    C_disorder = 1.00 * th ** 3.37
    Pr = np.clip(1 - (C_enf + C_def + C_disorder), 0, None)
    kap = np.exp(-((th - 0.55) / 0.32) ** 2)
    lvl = 0.72 * kap * (1 - 0.28 * th)
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10.0, 8.4), dpi=200)
    fig.patch.set_facecolor("white")
    ax1.plot(th, C_enf, color=P["cost"], lw=2.6, label=d["c_enf"])
    ax1.plot(th, C_def, color=P["gap"], lw=2.6, ls="--", label=d["c_def"])
    ax1.plot(th, C_disorder, color="#BFB5A8", lw=2.2, ls=":", label=d["c_ord"])
    ax1.plot(th, Pr, color=P["inc"], lw=3.0, label=d["pp"])
    ax1.fill_between(th, 0, Pr, color=P["inc"], alpha=0.12)
    ax1.set_ylim(0, 1.05); ax1.set_xlim(0, 1); ax1.set_ylabel(d["y1"], fontsize=11)
    ax1.legend(frameon=False, fontsize=10, ncol=2, loc="upper center")
    plain_axes(ax1); ax1.grid(axis="y", color=P["grid"], lw=0.6)
    ax2.plot(th, kap, color=P["actual"], lw=3.2, label=d["y2"])
    ax2.fill_between(th, 0, kap, color=P["actual"], alpha=0.14)
    ax2.plot(th, lvl, color=P["dead"], lw=2.0, ls="--", label=d["lvl"])
    ax2.axvspan(0.0, 0.24, color=P["gap"], alpha=0.13)
    ax2.axvspan(0.83, 1.0, color="#9AA7B4", alpha=0.16)
    ax2.axvspan(0.42, 0.68, color=P["good"], alpha=0.16)
    ax2.text(0.12, 0.80, d["desp"], ha="center", fontsize=10, color=P["dead"])
    ax2.text(0.915, 0.80, d["abs_"], ha="center", fontsize=10, color="#5C6773")
    ax2.text(0.55, 1.02, d["corr"], ha="center", fontsize=10.5, color=P["good"],
             fontweight="bold")
    ax2.axvline(0.55, color=P["good"], lw=1.2, ls="--", alpha=0.9)
    ax2.set_ylim(0, 1.12); ax2.set_xlim(0, 1)
    ax2.set_xlabel(d["xt"], fontsize=11.5); ax2.set_ylabel(d["y2"], fontsize=10.5)
    ax2.legend(frameon=False, fontsize=9.5, loc="upper left")
    plain_axes(ax2); ax2.grid(axis="y", color=P["grid"], lw=0.6)
    ax2.annotate(r"$\theta^{*}_{\text{social}}=0.55,\ \text{Spread}=0.32,\ \kappa_{\max}=1.0$",
                 xy=(0.55, 0.98), xytext=(0.62, 0.60), fontsize=9.5, color=P["text"],
                 arrowprops=dict(arrowstyle="->", lw=1.2, color=P["text"]))
    fig.text(0.5, 0.965, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.936, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig2_5_2_inverted_u")

for lg in ("zh", "en"):
    draw(lg)
