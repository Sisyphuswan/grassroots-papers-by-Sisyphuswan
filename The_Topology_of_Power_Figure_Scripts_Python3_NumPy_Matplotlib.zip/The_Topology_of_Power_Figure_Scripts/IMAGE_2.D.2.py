# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 2.D.2 —— 隐变量方差法（中英双语）

import numpy as np

L = {
    "zh": dict(
        t="图 2.D.2  隐变量方差法：不观关系，只测判决离散度",
        note="案情事实完全相同，判决却天差地别——这个方差本身就是 Status 的读数",
        x="案件编号（案情事实已穷尽控制）", y="惩治严厉度  Severity",
        a="情境 A：规则中立（Status → 0）", av="残差方差 ≈ 0",
        b="情境 B：特权与关系（Status → 1）", bv="残差方差 极度发散",
    ),
    "en": dict(
        t="Figure 2.D.2  Latent Residual Variance: Ignore Patronage, Measure the Spread",
        note="Identical facts, wildly different outcomes — that variance itself is the reading of Status",
        x="Case index (facts fully controlled)", y="Severity of punishment",
        a="Case A: impersonal rule (Status → 0)", av="residual variance ≈ 0",
        b="Case B: privilege & patronage (Status → 1)", bv="residual variance explodes",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    rng = np.random.default_rng(7)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.2, 5.6), dpi=200, sharey=True)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.77, bottom=0.12, wspace=0.10)
    n = 34; x = np.arange(n)
    y1 = 0.5 + rng.normal(0, 0.028, n)
    n_priv = 10
    y2_priv = 0.16 + rng.normal(0, 0.045, n_priv)
    y2_unpriv = 0.68 + rng.normal(0, 0.055, n - n_priv)
    y2 = np.concatenate([y2_priv, y2_unpriv])
    rng.shuffle(y2)
    for ax, y, name, vtxt, col in ((ax1, y1, d["a"], d["av"], P["good"]),
                                   (ax2, y2, d["b"], d["bv"], P["gap"])):
        ax.scatter(x, np.clip(y, 0, 1), s=34, color=col, alpha=0.85, zorder=3)
        ax.axhline(0.5, color=P["text"], lw=1.0, ls="--", alpha=0.6)
        ax.set_ylim(0, 1); ax.set_xlim(-1, n)
        plain_axes(ax); ax.grid(axis="y", color=P["grid"], lw=0.6)
        ax.set_xlabel(d["x"], fontsize=10.5); ax.set_title(name, fontsize=11)
        ax.text(n / 2, 0.06, vtxt, ha="center", fontsize=10.5, color=col,
                fontweight="bold")
    ax1.set_ylabel(d["y"], fontsize=11)
    fig.text(0.5, 0.965, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.900, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig2_d_2_latent_variance")

for lg in ("zh", "en"):
    draw(lg)
