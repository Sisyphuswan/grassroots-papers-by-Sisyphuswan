# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 8.2.1 —— 网络替代定理与清洗可行窗口（中英双语）

import numpy as np

L = {
    "zh": dict(
        t="图 8.2.1  网络替代定理与清洗可行窗口",
        note="替代网络容量未跨过核心载荷阈值前，清洗属于系统崩溃禁区；跨过阈值后代价离散跌回有限区间",
        xt="隐蔽替代工程周期 $t$（年）",
        y1="组织功能承载容量", y2="清洗系统代价  $\\mathrm{PurgeCost}_i$",
        pa="A 栏：替代网络容量的逻辑斯蒂累积", pb="B 栏：清洗系统代价的离散跃降",
        alt="替代网络成熟度  $\\mathrm{AltNet}(t)$",
        req="必要功能载荷  $\\mathrm{Load}_{\\mathrm{Network},i}^*$",
        gap="不可替代缺口",
        win="可行清洗窗口",
        thr="阈值跨越点  $\\mathrm{PurgeTime}^* = %.1f$" ,
        rup="系统崩溃禁区（不可行，无有限代价解）",
        fin="有限可控清洗代价  $\\mathrm{PurgeCost}_i$",
        open_lbl="跨过 $\\mathrm{PurgeTime}^*$：可行窗口开启\n系统代价跌回有限域",
    ),
    "en": dict(
        t="Figure 8.2.1  The Network Replacement Theorem and Feasible Purge Window",
        note="Before alternative capacity exceeds the critical load, purging triggers systemic collapse; past PurgeTime*, purge cost drops into the finite domain",
        xt="Covert institutional buildup time $t$ (years)",
        y1="Organizational functional capacity", y2="Purge vulnerability cost  $\\mathrm{PurgeCost}_i$",
        pa="Panel A: Logistic accumulation of alternative network", pb="Panel B: Discrete drop in purge cost",
        alt="Alternative network capacity  $\\mathrm{AltNet}(t)$",
        req="Required functional load  $\\mathrm{Load}_{\\mathrm{Network},i}^*$",
        gap="Irreplaceable capacity gap",
        win="Feasible purge window",
        thr="Threshold crossed\n$\\mathrm{PurgeTime}^* = %.1f$",
        rup="Systemic collapse zone (infeasible)",
        fin="Finite-cost purge curve  $\\mathrm{PurgeCost}_i$",
        open_lbl="Past $\\mathrm{PurgeTime}^*$: feasible window opens\npurge cost drops to finite domain",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.4, 6.0), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.80, bottom=0.14, wspace=0.22)

    t = np.linspace(0, 20, 500)
    K_alt = 100.0; r = 0.35; t_mid = 10.0; kappa_star = 65.0
    AltNet = K_alt / (1.0 + np.exp(-r * (t - t_mid)))
    idx = int(np.where(AltNet >= kappa_star)[0][0])
    t_star = float(t[idx])

    ax1.plot(t, AltNet, color=P["actual"], lw=2.8, label=d["alt"])
    ax1.axhline(kappa_star, color=P["fear"], ls="--", lw=2.0, label=d["req"])
    ax1.fill_between(t[:idx + 1], AltNet[:idx + 1], kappa_star,
                     facecolor="#FBE9E7", edgecolor=P["gap"], hatch="///", alpha=0.35, label=d["gap"])
    ax1.fill_between(t[idx:], kappa_star, AltNet[idx:],
                     color=P["good"], alpha=0.22, label=d["win"])
    ax1.axvline(t_star, color=P["claimed"], ls=":", lw=1.6)
    ax1.plot([t_star], [kappa_star], marker="o", ms=8, color=P["good"], zorder=5)
    ax1.annotate(d["thr"] % t_star, xy=(t_star, kappa_star), xytext=(t_star + 1.0, 34),
                 fontsize=9.6, fontweight="bold", color=P["text"],
                 arrowprops=dict(arrowstyle="->", color=P["text"], lw=1.4),
                 bbox=dict(boxstyle="round,pad=0.3", fc=P["light_bg"], ec=P["claimed"]))
    ax1.set_xlim(0, 20); ax1.set_ylim(0, 112)
    ax1.set_xlabel(d["xt"], fontsize=10.5); ax1.set_ylabel(d["y1"], fontsize=10.5)
    ax1.set_title(d["pa"], fontsize=11.5, fontweight="bold")
    ax1.legend(loc="upper left", frameon=False, fontsize=8.8)
    plain_axes(ax1); ax1.grid(axis="y", color=P["grid"], lw=0.6)

    cost_fin = 22.0 + 0.72 * (K_alt - AltNet[idx:])
    ax2.axhspan(98, 128, facecolor=P["dead"], alpha=0.14, label=d["rup"])
    ax2.hlines(112, 0, t_star, colors=P["dead"], linestyles="--", lw=2.6)
    ax2.plot([t_star], [112], marker="X", ms=12, color=P["dead"], zorder=5)
    ax2.plot(t[idx:], cost_fin, color=P["cost"], lw=3.0, label=d["fin"])
    ax2.fill_between(t[idx:], 0, cost_fin, color=P["good"], alpha=0.10)
    ax2.axvline(t_star, color=P["claimed"], ls=":", lw=1.6)
    ax2.plot([t_star, t_star], [cost_fin[0], 112], color=P["claimed"], ls=":", lw=1.2)
    ax2.annotate(d["open_lbl"], xy=(t_star + 0.2, cost_fin[0]), xytext=(t_star + 1.8, 72),
                 fontsize=9.6, fontweight="bold", color=P["good"],
                 arrowprops=dict(arrowstyle="->", color=P["good"], lw=1.4),
                 bbox=dict(boxstyle="round,pad=0.3", fc="#F0FFF4", ec=P["good"]))
    ax2.set_xlim(0, 20); ax2.set_ylim(0, 130)
    ax2.set_xlabel(d["xt"], fontsize=10.5); ax2.set_ylabel(d["y2"], fontsize=10.5)
    ax2.set_title(d["pb"], fontsize=11.5, fontweight="bold")
    ax2.legend(loc="center left", bbox_to_anchor=(0.01, 0.25), frameon=False, fontsize=8.8)
    plain_axes(ax2); ax2.grid(axis="y", color=P["grid"], lw=0.6)

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.908, d["note"], ha="center", fontsize=9.4, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig8_2_1_network_replacement")

for lg in ("zh", "en"):
    draw(lg)
