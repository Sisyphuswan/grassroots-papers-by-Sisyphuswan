# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.3.3 —— 似然函数的死寂平直

import numpy as np

L = {
    "zh": dict(
        t="图 5.3.3  似然函数的死寂平直：偏好参数完全不可识别",
        note="三种内心截然相反的人，观测似然落在同一条水平线上",
        x="偏好参数  $\\text{Type}$（极度仇恨 → 中间冷漠 → 狂热拥护）",
        y="似然度  $\\mathcal{L}(\\text{Type})$",
        m1="刻骨仇恨者\n（行动 = 顺从）",
        m2="苟且偷生者\n（行动 = 顺从）",
        m3="狂热信奉者\n（行动 = 顺从）",
        flat="$\\mathcal{L}(\\text{Type}) \\equiv 1$：偏好完全不可识别",
    ),
    "en": dict(
        t="Figure 5.3.3  The likelihood goes dead flat: preferences become unidentifiable",
        note="Three opposite inner states, one and the same likelihood level",
        x="Preference parameter  $\\text{Type}$ (hatred → indifference → zeal)",
        y="Likelihood  $\\mathcal{L}(\\text{Type})$",
        m1="Bitter hater\n(action = comply)",
        m2="Survivor\n(action = comply)",
        m3="Devout believer\n(action = comply)",
        flat="$\\mathcal{L}(\\text{Type}) \\equiv 1$: preferences unidentifiable",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(10.6, 6.2), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.84, bottom=0.16, left=0.11, right=0.97)

    ax.axhline(1.0, color=P["dead"], lw=3.0, zorder=3)
    ax.fill_between([0, 1], 0, 1.0, color=P["dead"], alpha=0.07, zorder=1)

    for x, km, ha in ((0.06, "m1", "left"), (0.50, "m2", "center"),
                      (0.94, "m3", "right")):
        ax.plot([x], [1.0], marker="o", ms=11, color=P["dead"], zorder=4)
        ax.text(x, 1.07, d[km], ha=ha, va="bottom", fontsize=10.0,
                color=P["text"], zorder=4)

    ax.annotate(d["flat"], xy=(0.50, 0.99), xytext=(0.50, 0.58),
                ha="center", va="top", fontsize=11.5, color=P["dead"],
                fontweight="bold",
                arrowprops=dict(arrowstyle="->", color=P["dead"], lw=1.6))

    ax.set_xlim(0, 1); ax.set_ylim(0, 1.42)
    ax.set_xlabel(d["x"], fontsize=11.0)
    ax.set_ylabel(d["y"], fontsize=11.0)
    ax.set_xticks([0.0, 0.5, 1.0]); ax.tick_params(labelbottom=False)
    ax.set_yticks([0.0, 0.5, 1.0]); ax.set_yticklabels(["0.0", "0.5", "1.0"])
    plain_axes(ax)
    ax.grid(axis="y", color=P["grid"], lw=0.6)

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_3_3_likelihood_flat")


for lg in ("zh", "en"):
    draw(lg)
