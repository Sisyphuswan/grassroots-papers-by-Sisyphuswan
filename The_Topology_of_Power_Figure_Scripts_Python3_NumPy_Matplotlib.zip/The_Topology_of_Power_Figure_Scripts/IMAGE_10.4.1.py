# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 10.4.1 —— 独立第三方仲裁破解动态不一致性与安全走廊解耦（中英双语）

import numpy as np

L = {
    "zh": dict(
        t="图 10.4.1  独立第三方仲裁对承诺可信度与安全走廊的拓扑修复",
        note="给定多中心网络已越过防 SmashArbiter 门槛，仲裁威慑跨越违约门槛后均衡发生 $0\\to 1$ 阶跃并重启走廊",
        pa="A 栏：仲裁威慑力与主权承诺可信度跃迁", pb="B 栏：天花板解耦与安全走廊重开",
        x1="仲裁期望总威慑  $\\mathrm{ArbiterProb}\\cdot(\\mathrm{BreachPenalty} + \\mathrm{ConfiscationRate}\\cdot\\mathrm{Spoil}_{\\mathrm{purged}}) \\leq \\mathrm{NetworkPenalty}$",
        y1="阶段 $t_1$ 承诺可信度  $\\mathrm{Cred}(t_1)$",
        c_no="无第三方仲裁基准（$\\mathrm{Cred}(t_1) = 0$）",
        c_yes="引入独立第三方仲裁后纯策略可信度",
        thr="程序门槛\n$\\mathrm{ConfiscationRate}\\cdot\\mathrm{Spoil}_{\\mathrm{purged}} + \\mathrm{Pension}$",
        eq1="抱权—清洗死局\n$(\\mathrm{HoldPower},\\,\\mathrm{Purge}_{\\mathrm{under\\_law}}$\n$/\\,\\mathrm{SmashArbiter})$",
        eq2="体面退场均衡\n$(\\mathrm{Exit},\\,\\mathrm{Honor})$",
        x2="危机与清洗压力指数  $\\mathrm{Escal}$", y2="能力与安全边界",
        ceil_old="无制衡天花板（下沉闭合）", ceil_new="分权仲裁下容忍上限（解耦上移）",
        flr="履职底线能力  $\\mathrm{FunctionalFloor}$",
        corr="修复后的正向安全走廊",
    ),
    "en": dict(
        t="Figure 10.4.1  Restoring Credibility and the Safe Corridor via Independent Arbitration",
        note="Given network deterrence clears the anti-SmashArbiter threshold, clearing the default threshold induces a 0-1 step flip and reopens the corridor",
        pa="Panel A: Arbitration penalty vs. stage-t1 credibility", pb="Panel B: Decoupling ToleranceCeiling and reopening corridor",
        x1="Expected deterrence  $\\mathrm{ArbiterProb}\\cdot(\\mathrm{BreachPenalty} + \\mathrm{ConfiscationRate}\\cdot\\mathrm{Spoil}_{\\mathrm{purged}}) \\leq \\mathrm{NetworkPenalty}$",
        y1="Stage-$t_1$ credibility  $\\mathrm{Cred}(t_1)$",
        c_no="No-arbiter baseline ($\\mathrm{Cred}(t_1) = 0$)",
        c_yes="Pure-strategy credibility with independent arbiter",
        thr="Threshold\n$\\mathrm{ConfiscationRate}\\cdot\\mathrm{Spoil}_{\\mathrm{purged}} + \\mathrm{Pension}$",
        eq1="Deadlock\n$(\\mathrm{HoldPower},\\,\\mathrm{Purge}_{\\mathrm{under\\_law}}$\n$/\\,\\mathrm{SmashArbiter})$",
        eq2="Peaceful exit\n$(\\mathrm{Exit},\\,\\mathrm{Honor})$",
        x2="Crisis pressure index  $\\mathrm{Escal}$", y2="Capacity & tolerance bounds",
        ceil_old="Unchecked ceiling (collapsing)", ceil_new="Constitutional ceiling (decoupled)",
        flr="Minimum functional floor  $\\mathrm{FunctionalFloor}$",
        corr="Restored positive safe corridor",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.6, 6.1), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.80, bottom=0.14, wspace=0.22)

    thr_val = 50.0
    # Deterministic subgame equilibrium steps discontinuously from 0 to 1 at thr_val
    ax1.axhline(0.0, color=P["dead"], ls="--", lw=3.2, label=d["c_no"], zorder=3)
    ax1.plot([0.0, thr_val], [0.0, 0.0], color=P["good"], ls="-", lw=1.8, zorder=4)
    ax1.plot([thr_val, thr_val], [0.0, 1.0], color=P["good"], ls=":", lw=1.8, zorder=4)
    ax1.plot([thr_val, 100.0], [1.0, 1.0], color=P["good"], ls="-", lw=3.2, label=d["c_yes"], zorder=5)
    ax1.scatter([thr_val], [0.0], s=55, facecolors="white", edgecolors=P["good"], linewidths=1.8, zorder=6)
    ax1.scatter([thr_val], [1.0], s=55, color=P["good"], zorder=6)

    ax1.axvline(thr_val, color=P["claimed"], ls=":", lw=1.6)
    ax1.axvspan(0, thr_val, color=P["dead"], alpha=0.08)
    ax1.axvspan(thr_val, 100, color=P["good"], alpha=0.10)
    ax1.text(24.5, 0.50, d["eq1"], ha="center", va="center", fontsize=9.2, fontweight="bold", color=P["dead"])
    ax1.text(75.5, 0.50, d["eq2"], ha="center", va="center", fontsize=9.6, fontweight="bold", color=P["good"])
    ax1.text(thr_val + 2.0, 0.10, d["thr"], fontsize=8.4, color=P["text"], fontweight="bold")
    ax1.set_xlim(0, 100); ax1.set_ylim(-0.08, 1.18)
    ax1.set_xlabel(d["x1"], fontsize=8.5); ax1.set_ylabel(d["y1"], fontsize=10.2)
    ax1.set_title(d["pa"], fontsize=11.4, fontweight="bold")
    ax1.legend(loc="upper left", frameon=False, fontsize=8.4)
    plain_axes(ax1); ax1.grid(axis="y", color=P["grid"], lw=0.6)

    esc = np.linspace(1.0, 2.5, 400)
    s = (esc - 1.0) / 1.5
    flr = 0.25 + 0.50 * (s ** 1.15)
    ceil_old = 0.90 - 0.58 * (s ** 1.15)
    ceil_new = 0.92 - 0.06 * s
    ax2.plot(esc, ceil_old, color=P["dead"], ls="--", lw=2.2, label=d["ceil_old"])
    ax2.plot(esc, ceil_new, color=P["good"], lw=2.8, label=d["ceil_new"])
    ax2.plot(esc, flr, color=P["actual"], lw=2.8, label=d["flr"])
    ax2.fill_between(esc, flr, ceil_new, color=P["good"], alpha=0.18, label=d["corr"])
    ax2.set_xlim(1.0, 2.5); ax2.set_ylim(0.0, 1.15)
    ax2.set_xlabel(d["x2"], fontsize=10.2); ax2.set_ylabel(d["y2"], fontsize=10.2)
    ax2.set_title(d["pb"], fontsize=11.4, fontweight="bold")
    ax2.legend(loc="lower left", frameon=True, facecolor="white", edgecolor="none", framealpha=0.88, fontsize=8.2)
    plain_axes(ax2); ax2.grid(axis="y", color=P["grid"], lw=0.6)

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.2, fontweight="bold")
    fig.text(0.5, 0.908, d["note"], ha="center", fontsize=8.9, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig10_4_1_arbiter_corridor")

for lg in ("zh", "en"):
    draw(lg)
