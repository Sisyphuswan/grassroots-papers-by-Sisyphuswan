# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.3.5.2 —— 骑手案的微观拓扑场：守法子集湮灭，可行域收缩为极窄带

from matplotlib.patches import FancyBboxPatch, Rectangle

L = {
    "zh": dict(
        t="图 5.3.5.2  骑手在算法派单系统下的微观拓扑场",
        note="守法子集为空，可行域却不是空集 —— 它是一片「违法但能活」的窄带",
        rows=[
            ("实态激励场  Π_Incentive（生存可维系侧）", P["inc"], [
                "房租、生活开销与电池租赁费锁死了刚性生存底线 Gain_min。",
                "午高峰必须连续完成 12–15 笔订单才能跨过这条底线；",
                "规范骑行、等满每一个 90 秒红灯，单量将直接跌破底线。"]),
            ("实态恐惧场  Π_Fear（算法惩治侧：高 Inflex ＋ 零 Elastic）", P["fear"], [
                "毫秒级监控下，订单超时 1 秒即自动扣款；差评导致派单权重断崖下跌。",
                "恐惧场把「合规等待」本身定义为即刻遭受经济制裁的毁灭区。"]),
            ("实态责任场  Π_Responsibility（双向挤压）", P["resp"], [
                "家庭抚养的生存刚性，与站点考核指标、顾客催单同向施压。",
                "垂直链条上没有一处可以卸力。"]),
        ],
        c="守法子集与 A_i 不相交   （守法与活下去，两个约束不再相交）",
        c2="A_i ≈ { 闯黄灯、切内道超速、边骑边抢单，以及其间的一切连续变体 }",
        c3="极窄带：Width 极小但严格大于 0（趋近单点态，但不是单点态）",
    ),
    "en": dict(
        t="Figure 5.3.5.2  The rider's micro-topological field under algorithmic dispatch",
        note="The lawful subset is empty, yet the domain is not — it is a narrow illegal-but-survivable band",
        rows=[
            ("Actual incentive field  Π_Incentive (survival side)", P["inc"], [
                "Rent, living costs and battery rental pin the survival floor Gain_min.",
                "Only 12-15 orders in the lunch peak clear that floor;",
                "riding lawfully through every 90-second red light drops below it."]),
            ("Actual fear field  Π_Fear (algorithmic punishment: high Inflex, zero Elastic)", P["fear"], [
                "Under millisecond monitoring, a one-second delay auto-triggers a deduction;",
                "a bad rating sends dispatch priority off a cliff. Waiting lawfully is itself the destroyed zone."]),
            ("Actual responsibility field  Π_Responsibility (squeezed both ways)", P["resp"], [
                "Family support duty and station quotas push in the same direction.",
                "Nowhere along the vertical chain can the load be shed."]),
        ],
        c="The lawful subset and A_i are disjoint (obeying the law and surviving no longer intersect)",
        c2="A_i ≈ { running yellows, cutting lanes, grabbing orders while riding, and every variant between }",
        c3="A narrow band: Width is tiny but strictly > 0 (near a single point, not one)",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(10.8, 8.6), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.90, bottom=0.02, left=0.02, right=0.98)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")

    ax.add_patch(FancyBboxPatch((0.30, 0.35), 9.40, 9.10,
                 boxstyle="round,pad=0.06,rounding_size=0.14",
                 facecolor=P["light_bg"], edgecolor="#C7CDD6", lw=1.6))

    ys = (7.00, 4.75, 2.85)
    for (title, col, lines), y in zip(d["rows"], ys):
        h = 2.05
        ax.add_patch(FancyBboxPatch((0.65, y), 8.70, h,
                     boxstyle="round,pad=0.06,rounding_size=0.10",
                     facecolor="white", edgecolor="#DDE1E7", lw=1.2))
        ax.add_patch(Rectangle((0.65, y), 0.15, h, facecolor=col,
                     edgecolor="none"))
        ax.text(1.05, y + h - 0.42, title, ha="left", va="center",
                fontsize=10.4, fontweight="bold", color=col)
        for k, ln in enumerate(lines):
            ax.text(1.05, y + h - 0.92 - 0.36 * k, ln, ha="left", va="center",
                    fontsize=9.1, color=P["text"])

    ax.add_patch(FancyBboxPatch((0.65, 0.62), 8.70, 1.95,
                 boxstyle="round,pad=0.06,rounding_size=0.10",
                 facecolor=P["cost"], alpha=0.14, edgecolor=P["cost"], lw=2.0))
    ax.text(1.05, 2.26, d["c"], ha="left", va="center", fontsize=10.0,
            fontweight="bold", color=P["dead"])
    ax.text(1.05, 1.72, d["c2"], ha="left", va="center", fontsize=9.2,
            color=P["text"])
    ax.text(1.05, 1.16, d["c3"], ha="left", va="center", fontsize=9.2,
            fontweight="bold", color="#A9620F")

    fig.text(0.5, 0.968, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.938, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_3_5_2_rider")


for lg in ("zh", "en"):
    draw(lg)
