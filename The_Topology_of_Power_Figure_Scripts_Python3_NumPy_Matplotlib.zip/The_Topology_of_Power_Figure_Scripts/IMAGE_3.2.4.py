# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 3.2.4 —— 威慑空心化的现实形态：威慑效率截断后的真空

import numpy as np

L = {
    "zh": dict(
        t="图 3.2.4  威慑空心化的现实形态：威慑效率截断之后的真空",
        note="宣称的威慑铺满全表；实态威慑只覆盖得起性价比最高的那一段",
        y="威慑呈现度",
        x="威慑效率比  Threat / Cost_enf   （高 → 低）",
        claimed="宣称的威慑  Deterrence^claimed（声势浩大、法网严密）",
        actual="实态威慑  Deterrence^actual（经 κ 折算）",
        low="高性价比区\n（叛乱杀人等：\n成本低而必惩）",
        high="威慑空心化暴露区\n（低性价比管控真空：\n试探无风险）",
        cut="效率门槛  Efficiency*",
    ),
    "en": dict(
        t="Figure 3.2.4  The actual form of deterrence hollowing-out: the deterrence vacuum after efficiency truncation",
        note="The claimed threat covers the whole menu; the actual one only the most cost-effective slice",
        y="Deterrence presented",
        x="Deterrence efficiency  Threat / Cost_enf   (high → low)",
        claimed="Claimed threat  Deterrence^claimed (sweeping, airtight on paper)",
        actual="Actual threat  Deterrence^actual (discounted by κ)",
        low="High-efficiency zone\n(riot, murder: low cost\nand must be policed)",
        high="Deterrence-hollowing-out exposure zone\n(low-efficiency: total vacuum,\nprobing is risk-free)",
        cut="Efficiency threshold  Efficiency*",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(11.0, 6.6), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.83, bottom=0.17, left=0.09, right=0.97)
    x = np.linspace(0, 1, 600)
    xc = 0.42
    claimed = np.ones_like(x)
    actual = np.where(x <= xc, 0.62, 0.0)
    ax.fill_between(x, 0, claimed, color=P["claimed"], alpha=0.16)
    ax.plot(x, claimed, color=P["claimed"], lw=2.6, ls="--", label=d["claimed"])
    ax.fill_between(x, 0, actual, color=P["actual"], alpha=0.22)
    ax.plot(x, actual, color=P["actual"], lw=3.0, label=d["actual"])
    ax.axvspan(xc, 1.0, color=P["gap"], alpha=0.13)
    ax.axvline(xc, color=P["dead"], lw=1.6, ls=":")
    ax.text(0.21, 0.36, d["low"], ha="center", va="center",
            fontsize=9.8, color=P["actual"])
    ax.text(0.71, 0.50, d["high"], ha="center", va="center",
            fontsize=9.8, color=P["dead"])
    ax.text(xc + 0.012, 1.045, d["cut"], ha="left", va="bottom",
            fontsize=9.4, color=P["dead"])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.18)
    ax.set_xlabel(d["x"], fontsize=11); ax.set_ylabel(d["y"], fontsize=11)
    ax.set_xticks([]); ax.set_yticks([0.0, 0.5, 1.0])
    plain_axes(ax)
    fig.text(0.5, 0.952, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.910, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig3_2_4_hollowing_out")

for lg in ("zh", "en"):
    draw(lg)
