# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 6.7.1 —— 迟滞回线（中英双语）

import numpy as np, matplotlib.pyplot as plt

L = {
    "zh": dict(t="图 6.7.1  迟滞回线：松绑不等于恢复",
               x="刚柔度 $\\theta$（← 刚　　柔 →）", y="兑现力 $\\kappa_{\\text{State}}$",
               down="下滑路径：信任缺失引致收紧，收紧加速 $\\kappa_{\\text{State}}$ 损耗",
               up="回升路径：$\\kappa_{\\text{State}}$ 仰赖外生输血，$\\theta$ 恢复显著滞后",
               area="迟滞面积 $\\text{HysteresisArea}>0$：系统不可逆损耗",
               back="未回到原点",
               note="两条路径并不重合，所夹面积即表征迟滞效应。政策松绑仅为回升的必要初始条件。"),
    "en": dict(t="Figure 6.7.1  Hysteresis loop: relaxation is not recovery",
               x="Rigidity index $\\theta$ (rigid ← → elastic)", y="Capacity $\\kappa_{\\text{State}}$",
               down="Downward path: less trust → tighter grip → $\\kappa_{\\text{State}}$ erodes",
               up="Upward path: $\\kappa_{\\text{State}}$ restored exogenously, $\\theta$ falls back only slowly",
               area="Hysteresis area $\\text{HysteresisArea}>0$: the part not recovered",
               back="Does not return to the origin",
               note="The two paths do not coincide; the wedge between them is $\\text{HysteresisArea}$."),
}

def draw(lang):
    set_font(lang); d = L[lang]
    k_low, k_high = 0.28, 0.85
    kd = np.linspace(k_low, k_high, 300)
    sd = (kd - k_low) / (k_high - k_low)
    th_d = 0.32 + 0.44 * sd ** 1.30
    ku = np.linspace(k_low, k_high, 300)
    su = (ku - k_low) / (k_high - k_low)
    th_u = 0.32 + 0.26 * su ** 2.40
    th_d_u = np.interp(ku, kd, th_d)

    fig, ax = plt.subplots(figsize=(10.8, 6.6), dpi=200)
    ax.fill_betweenx(ku, th_u, th_d_u, color=P["cost"], alpha=0.22)
    ax.plot(th_d, kd, color=P["gap"], lw=3.0, label=d["down"])
    ax.plot(th_u, ku, color=P["actual"], lw=3.0, ls="--", label=d["up"])
    ax.scatter([th_d[-1]], [kd[-1]], s=70, facecolor="white",
               edgecolor=P["gap"], lw=2.2, zorder=6)
    ax.scatter([th_u[-1]], [ku[-1]], s=70, facecolor="white",
               edgecolor=P["actual"], lw=2.2, zorder=6)
    ax.axvspan(0.0, 0.30, color=P["dead"], alpha=0.07, zorder=0)
    ax.axvline(0.30, color=P["dead"], lw=1.2, ls=":", alpha=0.65)
    ax.annotate(d["back"], xy=(th_u[-1], ku[-1]), xytext=(0.20, 0.76),
                fontsize=10.5, color=P["dead"], fontweight="bold",
                arrowprops=dict(arrowstyle="->", color=P["dead"], lw=1.5))
    ax.annotate("", xy=(th_d[10], kd[10]), xytext=(th_d[40], kd[40]),
                arrowprops=dict(arrowstyle="-|>", color=P["gap"], lw=2.0))
    ax.annotate("", xy=(th_u[260], ku[260]), xytext=(th_u[200], ku[200]),
                arrowprops=dict(arrowstyle="-|>", color=P["actual"], lw=2.0))
    ax.text(0.40, 0.44, d["area"], fontsize=11, color="#8A5A12",
            fontweight="bold", ha="center")
    ax.set_xlim(0, 1.0); ax.set_ylim(0.08, 1.0)
    ax.set_xlabel(d["x"], fontsize=11.5); ax.set_ylabel(d["y"], fontsize=11.5)
    ax.legend(frameon=False, fontsize=10, loc="upper right")
    plain_axes(ax); ax.grid(alpha=0.25, ls=":", color=P["grid"])
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig6_7_1_hysteresis")

for lg in ("zh", "en"):
    draw(lg)
