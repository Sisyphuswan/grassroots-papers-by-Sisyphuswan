# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.3.2 —— 三条退出通道全面湮灭

from matplotlib.patches import FancyBboxPatch

L = {
    "zh": dict(
        t="图 5.3.2  三条退出通道在单点态下的全面湮灭",
        note="退出、发声、不表态同时归零，可行行动域被唯一钉死",
        h1="退出通道（Exit）", m1="离开此地的子集测度归零", r1="我走不了",
        h2="发声通道（Voice）", m2="表达异议的子集测度归零", r2="我不敢说",
        h3="不表态通道（Silence）", m3="沉默与敷衍被逐出许可侧", r3="我连不说都不行",
        fin="可行行动域被唯一钉死在  $A_i = \\{a_{\\text{conform}}\\}$",
    ),
    "en": dict(
        t="Figure 5.3.2  Three exit channels annihilated in the singleton state",
        note="Exit, voice and silence all collapse to zero",
        h1="Exit", m1="measure of the leave-this-place subset is zero", r1="I cannot go",
        h2="Voice", m2="measure of the dissent subset is zero", r2="I dare not speak",
        h3="Silence", m3="silence and evasive compliance are driven out of the permitted side",
        r3="I cannot even stay silent",
        fin="the action domain is pinned at  $A_i = \\{a_{\\text{conform}}\\}$",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(11.0, 5.6), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.84, bottom=0.06, left=0.03, right=0.97)
    ax.set_xlim(0, 12); ax.set_ylim(0.30, 8.75); ax.axis("off")

    ys = [7.85, 5.70, 3.55]
    for y, kh, km, kr in zip(ys, ("h1", "h2", "h3"), ("m1", "m2", "m3"),
                             ("r1", "r2", "r3")):
        ax.add_patch(FancyBboxPatch((0.35, y - 0.62), 2.60, 1.24,
                     boxstyle="round,pad=0.04,rounding_size=0.12",
                     facecolor="#EDEFF2", edgecolor="#9AA7B4", lw=1.8))
        ax.text(1.65, y, d[kh], ha="center", va="center",
                fontsize=11.0, fontweight="bold", color=P["text"])

        ax.annotate("", xy=(3.55, y), xytext=(3.05, y),
                    arrowprops=dict(arrowstyle="->", color=P["fear"], lw=1.8))
        ax.add_patch(FancyBboxPatch((3.60, y - 0.62), 4.05, 1.24,
                     boxstyle="round,pad=0.04,rounding_size=0.12",
                     facecolor=P["fear"], alpha=0.14, edgecolor=P["fear"], lw=1.8))
        ax.text(5.62, y, d[km], ha="center", va="center",
                fontsize=10.4, color=P["dead"])

        ax.annotate("", xy=(9.05, y), xytext=(7.72, y),
                    arrowprops=dict(arrowstyle="->", color=P["fear"], lw=1.8))
        ax.text(9.20, y, d[kr], ha="left", va="center",
                fontsize=12.0, fontweight="bold", color=P["dead"])

    for x in (1.65, 5.62, 9.85):
        ax.annotate("", xy=(6.00, 1.90), xytext=(x, 2.92),
                    arrowprops=dict(arrowstyle="->", color="#8E2420", lw=1.6,
                                    alpha=0.55))

    ax.add_patch(FancyBboxPatch((2.35, 0.55), 7.30, 1.35,
                 boxstyle="round,pad=0.05,rounding_size=0.14",
                 facecolor=P["dead"], alpha=0.16, edgecolor=P["dead"], lw=2.4))
    ax.text(6.00, 1.22, d["fin"], ha="center", va="center",
            fontsize=12.5, fontweight="bold", color=P["dead"])

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_3_2_hirschman")


for lg in ("zh", "en"):
    draw(lg)
