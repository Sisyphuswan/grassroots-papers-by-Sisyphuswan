# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 4.C.2 —— 边界微小后撤引起的拓扑爆裂：效用峰与边界约束凹谷双栏对照

import numpy as np
from matplotlib.patches import FancyArrowPatch

L = {
    "zh": dict(
        t="图 4.C.2  边界微小后撤引起的拓扑爆裂",
        note="缰绳只松一毫米，被压抑数十年的高收益解就落进了民间可行域——它不在边界外侧，而在禁区深处的一座孤岛上",
        xl="行动空间  a",
        yl="效用  U(a)",
        yl2="边界约束  RegConstraint(a)",
        al="局部最优  a_local",
        ag="全局最优  a_global（原本被禁）",
        b0="原有边界  a = 5.00",
        isl="禁区中的孤岛",
        a0="原有可行域  A_0",
        aj="最优解跳跃",
        c0="原有阈值  Ctrl",
        c1="微松后阈值  Ctrl + ΔCtrl",
        dc="微松  ΔCtrl",
        tr="约束凹谷（孤岛解禁）",
    ),
    "en": dict(
        t="Figure 4.C.2  Topological burst caused by a tiny retreat of the boundary",
        note="Loosen the rein by a millimetre and a long-suppressed high-payoff option lands inside — not beyond the edge, but on an island deep inside the forbidden band",
        xl="Action space  a",
        yl="Utility  U(a)",
        yl2="Boundary constraint  RegConstraint(a)",
        al="Local optimum  a_local",
        ag="Global optimum  a_global (formerly banned)",
        b0="original boundary  a = 5.00",
        isl="island inside the forbidden band",
        a0="original domain  A_0",
        aj="the optimum jumps",
        c0="original threshold  Ctrl",
        c1="relaxed threshold  Ctrl + ΔCtrl",
        dc="relaxation  ΔCtrl",
        tr="constraint trough (island unlocked)",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, (ax, ax2) = plt.subplots(
        2, 1, sharex=True, figsize=(10.4, 8.6), dpi=200,
        gridspec_kw={"height_ratios": [1.32, 1.0], "hspace": 0.14},
    )
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.86, bottom=0.10, left=0.09, right=0.98)

    a = np.linspace(0.0, 9.0, 1200)
    U = (2.0 * np.exp(-((a - 2.0) / 1.3) ** 2)
         + 3.4 * np.exp(-((a - 5.35) / 0.42) ** 2))
    Reg = (1.00 + 0.85 * np.tanh(14.0 * (a - 5.00))
           - 0.68 * np.exp(-((a - 5.35) / 0.15) ** 2))
    ctrl = 1.00
    ctrl_new = 1.60

    mask_unlocked = Reg <= ctrl_new
    edges = np.where(np.diff(mask_unlocked.astype(int)) != 0)[0]
    bounds = [0.0] + [float(0.5 * (a[i] + a[i + 1])) for i in edges] + [9.0]
    a_main_0 = 5.00
    isl_l, isl_r = bounds[2], bounds[3]

    for panel in (ax, ax2):
        panel.axvspan(0.0, a_main_0, color=P["inc"], alpha=0.10, zorder=0)
        for lo_b, hi_b in zip(bounds[:-1], bounds[1:]):
            mid = 0.5 * (lo_b + hi_b)
            is_in = bool(np.interp(mid, a, Reg) <= ctrl_new)
            if hi_b <= a_main_0 + 1e-6:
                continue
            if lo_b < a_main_0:
                lo_b = a_main_0
            if is_in:
                alp = 0.28 if lo_b >= isl_l - 0.05 else 0.16
                panel.axvspan(lo_b, hi_b, color=P["inc"], alpha=alp, zorder=0)
            else:
                panel.axvspan(lo_b, hi_b, color=P["cost"], alpha=0.22, zorder=0)
        panel.axvline(a_main_0, color=P["fear"], lw=1.6, ls="--", zorder=2)
        panel.axvline(isl_l, color="#A9620F", lw=1.2, ls="--", zorder=2)
        panel.axvline(isl_r, color="#A9620F", lw=1.2, ls=":", zorder=2)
        panel.set_xticks([]); panel.set_yticks([])
        for s in ("top", "right"):
            panel.spines[s].set_visible(False)

    ax.plot(a, U, color=P["text"], lw=2.5, zorder=3)
    u_local = 2.0 * np.exp(0.0) + 3.4 * np.exp(-((2.0 - 5.35) / 0.42) ** 2)
    u_glob = 3.4 + 2.0 * np.exp(-((5.35 - 2.0) / 1.3) ** 2)
    ax.plot([2.0], [u_local], "o", color=P["inc"], ms=9, zorder=5)
    ax.plot([5.35], [u_glob], "o", color=P["dead"], ms=9, zorder=5)

    ax.set_xlim(0, 9.0); ax.set_ylim(-0.65, 4.45)
    ax.set_ylabel(d["yl"], fontsize=10.5)

    ax.text(2.00, u_local + 0.25, d["al"], ha="center", va="bottom",
            fontsize=9.6, color=P["inc"], fontweight="bold")
    ax.text(5.58, u_glob + 0.02, d["ag"], ha="left", va="bottom",
            fontsize=9.6, color=P["dead"], fontweight="bold")
    ax.text(4.86, 0.30, d["b0"], ha="right", va="center", fontsize=8.8,
            color=P["fear"])
    ax.text(5.35, -0.34, d["isl"], ha="center", va="center", fontsize=8.8,
            color="#A9620F", fontweight="bold")
    ax.text(2.30, 0.30, d["a0"], ha="center", va="center", fontsize=9.4,
            color="#1F5C40")
    ax.text(7.75, 1.35, d["aj"], ha="center", va="center", fontsize=9.6,
            color=P["dead"], fontweight="bold")
    ax.add_patch(FancyArrowPatch((2.05, u_local + 0.05), (5.28, u_glob - 0.05),
                 arrowstyle="-|>", mutation_scale=20, color=P["dead"], lw=2.0,
                 connectionstyle="arc3,rad=-0.28", zorder=6))

    ax2.plot(a, Reg, color=P["text"], lw=2.3, zorder=3)
    ax2.axhline(ctrl, color=P["fear"], lw=1.6, ls="--", zorder=2)
    ax2.axhline(ctrl_new, color="#A9620F", lw=1.6, ls="-.", zorder=2)
    ax2.plot([5.35], [1.17], "o", color="#A9620F", ms=7, zorder=5)
    ax2.set_ylim(0.0, 2.25)
    ax2.set_xlabel(d["xl"], fontsize=10.5)
    ax2.set_ylabel(d["yl2"], fontsize=10.5)

    ax2.text(0.25, ctrl + 0.05, d["c0"], ha="left", va="bottom",
             fontsize=8.8, color=P["fear"], fontweight="bold")
    ax2.text(0.25, ctrl_new + 0.05, d["c1"], ha="left", va="bottom",
             fontsize=8.8, color="#A9620F", fontweight="bold")
    ax2.annotate("", xy=(3.40, ctrl_new), xytext=(3.40, ctrl),
                 arrowprops=dict(arrowstyle="<->", color="#A9620F", lw=1.6))
    ax2.text(3.52, 0.5 * (ctrl + ctrl_new), d["dc"], ha="left", va="center",
             fontsize=8.6, color="#A9620F", fontweight="bold")
    ax2.annotate(d["tr"], xy=(5.38, 1.19), xytext=(6.05, 0.68),
                 arrowprops=dict(arrowstyle="->", color="#A9620F", lw=1.2),
                 ha="left", va="center", fontsize=8.8, color="#A9620F",
                 fontweight="bold")

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.918, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig4_c_2_topological_burst")


for lg in ("zh", "en"):
    draw(lg)
