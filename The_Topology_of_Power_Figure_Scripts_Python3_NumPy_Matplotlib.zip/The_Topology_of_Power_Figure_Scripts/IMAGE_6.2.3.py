# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 6.2.3 —— 三条反馈回路（中英双语）

import numpy as np, matplotlib.pyplot as plt

L = {
    "zh": dict(t="图 6.2.3  两条回路的累积量：全区间积分强度比较",
               x="时间 $t$", y="回路强度",
               s="自噬回路 $\\text{LoopIntensity}_{\\text{SelfDestruction}}=(1-\\theta)(1-\\kappa_{\\text{State}})$",
               w="自稳回路 $\\text{LoopIntensity}_{\\text{Stabilizing}}=\\theta\\kappa_{\\text{State}}$",
               sh="断血冲击（外生）",
               note="系统演化判据取决于曲线下方的时间积分累积面积，而非瞬时读数高低。"),
    "en": dict(t="Figure 6.2.3  Cumulated loop strength: who wins over the whole stretch",
               x="Time $t$", y="Loop strength",
               s="Autophagy loop $\\text{LoopIntensity}_{\\text{SelfDestruction}}=(1-\\theta)(1-\\kappa_{\\text{State}})$",
               w="Stabilising loop $\\text{LoopIntensity}_{\\text{Stabilizing}}=\\theta\\kappa_{\\text{State}}$",
               sh="Exsanguination shock (exogenous)",
               note="The test is not who is higher at an instant, but whose area is larger."),
}

def draw(lang):
    set_font(lang); d = L[lang]
    t = np.linspace(0, 60, 600)
    th = 0.34 - 0.20 * (1 - np.exp(-t / 26.0))
    kap = 0.62 * np.exp(-t / 34.0) + 0.06
    kap = np.where(t < 34, kap, 0.35 * kap)
    Ls = (1 - th) * (1 - kap); Lw = th * kap

    fig, ax = plt.subplots(figsize=(11.0, 6.2), dpi=200)
    ax.fill_between(t, 0, Ls, color=P["gap"], alpha=0.18)
    ax.fill_between(t, 0, Lw, color=P["good"], alpha=0.18)
    ax.plot(t, Ls, color=P["gap"], lw=3.0, label=d["s"])
    ax.plot(t, Lw, color=P["good"], lw=3.0, label=d["w"])
    ax.axvline(34, color=P["dead"], lw=1.6, ls="--")
    ax.text(34.8, 0.84, d["sh"], fontsize=10.5, color=P["dead"])
    ax.set_xlim(0, 60); ax.set_ylim(0, 1.05)
    ax.set_xlabel(d["x"], fontsize=11.5); ax.set_ylabel(d["y"], fontsize=11.5)
    ax.legend(frameon=False, fontsize=10.5, loc="upper right")
    plain_axes(ax); ax.grid(axis="y", color=P["grid"], lw=0.6)
    A_s = float(np.trapezoid(Ls, t)); A_w = float(np.trapezoid(Lw, t))
    ax.text(0.015, 0.06, f"$\\int \\text{{LoopIntensity}}_{{\\text{{SelfDestruction}}}}={A_s:.2f}$   $\\int \\text{{LoopIntensity}}_{{\\text{{Stabilizing}}}}={A_w:.2f}$",
            transform=ax.transAxes, fontsize=11, color=P["dead"], fontweight="bold")
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig6_2_3_loops")

for lg in ("zh", "en"):
    draw(lg)
