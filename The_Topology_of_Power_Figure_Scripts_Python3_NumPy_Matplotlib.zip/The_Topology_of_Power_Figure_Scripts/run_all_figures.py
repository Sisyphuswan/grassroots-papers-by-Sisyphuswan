# -*- coding: utf-8 -*-
"""Run all standalone IMAGE_*.py figure scripts in this folder."""
import glob
import os
import subprocess
import sys


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    scripts = sorted(glob.glob(os.path.join(here, "IMAGE_*.py")))
    print(f"Found {len(scripts)} standalone figure scripts.")
    failed = []
    for i, script in enumerate(scripts, 1):
        name = os.path.basename(script)
        print(f"[{i}/{len(scripts)}] Running {name} ...")
        res = subprocess.run([sys.executable, script], cwd=here)
        if res.returncode != 0:
            failed.append(name)
    if failed:
        print("FAILED:", failed)
        sys.exit(1)
    print(f"All {len(scripts)} scripts completed successfully.")


if __name__ == "__main__":
    main()
