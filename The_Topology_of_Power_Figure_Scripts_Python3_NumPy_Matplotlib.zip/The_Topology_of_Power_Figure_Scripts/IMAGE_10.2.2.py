# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 10.2.2 —— 责任—目标匹配度 μ_i 的两个极端形态（中英双语）

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 10.2.2  责任—目标匹配度 $\\mu_i$ 的两个极端形态",
        note="以空间测度交集甄别外溢指向：精确瞄准责任源头与无差别伤害无关第三方",
        lh="精准指向形态", rh="无差别外溢形态",
        ro="责任客体域  $\\mathrm{TargetDomain}$", vi="行动影响域  $\\mathrm{ImpactDomain}_i$",
        vd="行动影响域几乎全部收敛于此",
        gp="交集为空集",
        mu1="$\\mu_i \\to 1$", mu1d="瞄准制度责任源，避免波及无辜",
        mu2="$\\mu_i \\to 0$", mu2d="向更弱小的无关第三方倾泻伤害",
    ),
    "en": dict(
        t="Figure 10.2.2  Two Extreme Forms of Responsibility–Target Fit $\\mu_i$",
        note="Distinguishing spillover targeting via Lebesgue intersection: targeting the responsible source vs. harming innocent bystanders",
        lh="Targeted Form", rh="Indiscriminate Spillover Form",
        ro="Responsibility Target Domain  $\\mathrm{TargetDomain}$", vi="Action Impact Domain  $\\mathrm{ImpactDomain}_i$",
        vd="Impact domain lies almost entirely inside",
        gp="Empty intersection",
        mu1="$\\mu_i \\to 1$", mu1d="Target the source of coercion, spare bystanders",
        mu2="$\\mu_i \\to 0$", mu2d="Shift harm onto weaker unrelated third parties",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(10.8, 6.2), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.84, bottom=0.04, left=0.02, right=0.98)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")

    ax.plot([5.05, 5.05], [1.60, 9.00], ls="--", lw=1.2, color=P["grid"])

    ax.text(2.55, 9.35, d["lh"], ha="center", va="center", fontsize=12.4, fontweight="bold", color=P["inc"])
    ax.add_patch(FancyBboxPatch((0.65, 5.15), 3.80, 3.35,
                 boxstyle="round,pad=0.06,rounding_size=0.12",
                 facecolor=P["resp"], alpha=0.10, edgecolor=P["resp"], lw=2.0))
    ax.text(0.75, 8.80, d["ro"], ha="left", va="center", fontsize=9.6, color=P["resp"], fontweight="bold")
    ax.add_patch(FancyBboxPatch((0.95, 5.45), 3.20, 2.75,
                 boxstyle="round,pad=0.06,rounding_size=0.10",
                 facecolor=P["inc"], alpha=0.30, edgecolor=P["inc"], lw=2.2))
    ax.text(2.55, 7.20, d["vi"], ha="center", va="center", fontsize=10.2, fontweight="bold", color="#1F5C40")
    ax.text(2.55, 6.30, d["vd"], ha="center", va="center", fontsize=8.8, color=P["text"])
    ax.text(2.55, 4.45, d["mu1"], ha="center", va="center", fontsize=16.5, fontweight="bold", color=P["inc"])
    ax.text(2.55, 3.70, d["mu1d"], ha="center", va="center", fontsize=9.2, color=P["text"])

    ax.text(7.45, 9.35, d["rh"], ha="center", va="center", fontsize=12.4, fontweight="bold", color=P["dead"])
    ax.add_patch(FancyBboxPatch((5.55, 6.90), 3.80, 1.60,
                 boxstyle="round,pad=0.06,rounding_size=0.12",
                 facecolor=P["resp"], alpha=0.10, edgecolor=P["resp"], lw=2.0))
    ax.text(5.65, 8.80, d["ro"], ha="left", va="center", fontsize=9.6, color=P["resp"], fontweight="bold")
    ax.add_patch(FancyBboxPatch((5.55, 3.80), 3.80, 1.90,
                 boxstyle="round,pad=0.06,rounding_size=0.12",
                 facecolor=P["inc"], alpha=0.30, edgecolor=P["inc"], lw=2.2))
    ax.text(7.45, 4.75, d["vi"], ha="center", va="center", fontsize=10.2, fontweight="bold", color="#1F5C40")

    ax.add_patch(FancyArrowPatch((7.45, 5.76), (7.45, 6.84),
                 arrowstyle="<|-|>", mutation_scale=15, color=P["dead"], lw=2.0))
    ax.text(7.62, 6.30, d["gp"], ha="left", va="center", fontsize=9.2, color=P["dead"], fontweight="bold")
    ax.text(7.45, 3.05, d["mu2"], ha="center", va="center", fontsize=16.5, fontweight="bold", color=P["dead"])
    ax.text(7.45, 2.30, d["mu2d"], ha="center", va="center", fontsize=9.2, color=P["text"])

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.2, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.2, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig10_2_2_mu_two_forms")

for lg in ("zh", "en"):
    draw(lg)
