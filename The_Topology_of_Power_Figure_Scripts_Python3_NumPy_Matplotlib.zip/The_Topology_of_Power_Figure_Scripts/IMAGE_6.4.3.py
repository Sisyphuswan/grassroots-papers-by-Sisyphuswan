# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 6.4.3 —— 棘轮闭锁与阈值（中英双语）

import numpy as np, matplotlib.pyplot as plt

L = {
    "zh": dict(t="图 6.4.3  棘轮闭锁：放松通道的阈值",
               x="刚柔度 $\\theta$（← 刚　　柔 →）",
               y="政策速度 $\\dot\\theta$",
               tight="收紧分支：$-\\text{Tight}(\\theta-\\theta_{\\text{target}})$",
               rise="缓升（$\\text{Relax}>0$，斜率极小）",
               would="本应存在的放松分支（虚线）",
               ratchet="棘轮区：$\\dot\\theta\\leq 0$",
               sub="（$\\text{Relax}=0$，$\\theta$ 不可回升）",
               closed="通道关闭：$\\text{Relax}=0$",
               tgt="锚点 $\\theta_{\\text{target}}(\\kappa_{\\text{State}})$",
               crit="阈值 $\\theta_{\\text{Critical}}$",
               note="阈值以下放松通道关闭，$\\dot\\theta$ 归零：$\\theta$ 一旦跌破阈值，连续通道再不能把它抬回来。"),
    "en": dict(t="Figure 6.4.3  Ratchet lock: the threshold of the loosening channel",
               x="Rigidity index $\\theta$ (rigid ← → elastic)",
               y="Policy velocity $\\dot\\theta$",
               tight="Tightening branch: $-\\text{Tight}(\\theta-\\theta_{\\text{target}})$",
               rise="Slow loosening ($\\text{Relax}>0$, very small slope)",
               would="The loosening branch that should exist (dashed)",
               ratchet="Ratchet region: $\\dot\\theta\\leq 0$",
               sub="($\\text{Relax}=0$; $\\theta$ can never rise again)",
               closed="Channel closed: $\\text{Relax}=0$",
               tgt="Anchor $\\theta_{\\text{target}}(\\kappa_{\\text{State}})$",
               crit="Threshold $\\theta_{\\text{Critical}}$",
               note="Below the threshold the loosening channel is shut and $\\dot\\theta$ falls to zero: once $\\theta$ drops under it, the continuous channel can never lift it back."),
}

TH_CRIT, TH_TGT = 0.30, 0.55
TIGHT, RELAX = 1.60, 0.24   # 比值 6.67:1，与附 6.C 的 0.010:0.0015 一致；绝对量级仅为归一化展示

def draw(lang):
    set_font(lang); d = L[lang]
    th = np.linspace(0.0, 1.0, 1600)
    tight = -TIGHT * np.maximum(0.0, th - TH_TGT)
    loose = RELAX * np.maximum(0.0, TH_TGT - th)
    act = tight + np.where(th >= TH_CRIT, loose, 0.0)

    fig, ax = plt.subplots(figsize=(11.0, 6.4), dpi=200)
    ax.axvspan(0.0, TH_CRIT, color=P["dead"], alpha=0.13, zorder=0)
    ax.axhline(0.0, color=P["text"], lw=1.0, zorder=2)

    m = th < TH_CRIT
    ax.plot(th[m], loose[m], color=P["claimed"], lw=2.2, ls="--", zorder=3)
    ax.plot(th[th <= TH_TGT], act[th <= TH_TGT], color=P["actual"], lw=3.2, zorder=4)
    ax.plot(th[th >= TH_TGT], act[th >= TH_TGT], color=P["gap"], lw=3.2, zorder=4)

    ax.axvline(TH_CRIT, color=P["dead"], lw=1.6, ls=":", zorder=3)
    ax.axvline(TH_TGT, color=P["text"], lw=1.3, ls="--", zorder=3)

    ax.plot([0.175], [RELAX * (TH_TGT - 0.175)], marker="x", ms=12, mew=2.8,
            color=P["gap"], zorder=6)
    ax.annotate("", xy=(0.245, RELAX * (TH_TGT - 0.245)), xytext=(0.245, 0.0),
                arrowprops=dict(arrowstyle="->", color=P["gap"], lw=1.6), zorder=5)

    box = dict(facecolor="#EFE0E0", edgecolor="none", pad=1.6)
    ax.text(0.015, 0.315, d["ratchet"], fontsize=11, color=P["dead"],
            fontweight="bold", ha="left", va="top", bbox=box, zorder=7)
    ax.text(0.015, 0.272, d["sub"], fontsize=9.5, color=P["dead"],
            ha="left", va="top", bbox=box, zorder=7)
    ax.text(0.015, 0.055, d["would"], fontsize=9.5, color=P["claimed"],
            ha="left", va="top", bbox=box, zorder=7)
    ax.text(0.015, -0.135, d["closed"], fontsize=10.5, color=P["gap"],
            fontweight="bold", ha="left", va="top", bbox=box, zorder=7)
    ax.text(0.335, 0.038, d["rise"], fontsize=9.5, color=P["actual"],
            ha="left", va="bottom", zorder=7)
    ax.text(0.985, -0.30, d["tight"], fontsize=10.5, color=P["gap"],
            ha="right", va="center", zorder=7)
    ax.text(TH_CRIT - 0.012, -0.66, d["crit"], fontsize=10.5, color=P["dead"], ha="right")
    ax.text(TH_TGT - 0.010, -0.66, d["tgt"], fontsize=10.5, color=P["text"], ha="right")

    ax.set_xlim(0.0, 1.0); ax.set_ylim(-0.78, 0.34)
    ax.set_yticks([-0.6, -0.4, -0.2, 0.0, 0.2])
    ax.set_xlabel(d["x"], fontsize=11.5); ax.set_ylabel(d["y"], fontsize=11.5)
    plain_axes(ax); ax.grid(axis="y", color=P["grid"], lw=0.6)
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.912, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig6_4_3_ratchet_lock")

for lg in ("zh", "en"):
    draw(lg)
