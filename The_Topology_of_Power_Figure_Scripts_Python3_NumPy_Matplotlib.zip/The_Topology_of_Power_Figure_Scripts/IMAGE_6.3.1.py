# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 6.3.1 —— 相图与滑行区（中英双语）

from matplotlib.patches import FancyArrowPatch
import numpy as np, matplotlib.pyplot as plt

L = {
    "zh": dict(t="图 6.3.1  相图：三条轨迹与亚健康滑行区",
               x="刚柔度 $\\theta$（← 刚　　柔 →）", y="兑现力 $\\kappa_{\\text{State}}$",
               ceil="承载力天花板 $\\kappa_{\\text{Ceiling}}(\\theta)$",
               a="自稳轨迹", b="自毁轨迹", c="滑行轨迹",
               band="亚健康滑行区\n（$\\kappa_{\\text{State}}$ 低，但 $d\\kappa_{\\text{State}}/dt\\approx 0$）",
               sh="断血冲击",
               proj="本图是三维轨线在慢流形上的投影：图上相交不等于轨迹相遇；轨迹在 $0.448<\\theta<0.759$ 之外的部分不在慢流形上。",
               note="低水位 ≠ 正在下沉。危险的判据是 $\\text{Stress}>\\text{Hold}\\,\\kappa_{\\text{State}}$，不是 $\\kappa_{\\text{State}}$ 小。"),
    "en": dict(t="Figure 6.3.1  Phase portrait: three trajectories and the sub-health gliding zone",
               x="Rigidity index $\\theta$ (rigid ← → elastic)", y="Capacity $\\kappa_{\\text{State}}$",
               ceil="Capacity ceiling $\\kappa_{\\text{Ceiling}}(\\theta)$",
               a="Stabilising path", b="Self-destructive path", c="Gliding path",
               band="Sub-health gliding zone\n(low $\\kappa_{\\text{State}}$, yet $d\\kappa_{\\text{State}}/dt\\approx 0$)",
               sh="Shock",
               proj="Projection of the 3-D trajectory onto the slow manifold: crossings here are not encounters; segments outside $0.448<\\theta<0.759$ leave the slow manifold.",
               note="A low level is not the same as sinking. The test is $\\text{Stress}>\\text{Hold}\\,\\kappa_{\\text{State}}$, not low $\\kappa_{\\text{State}}$."),
}

def head(ax, x, y, color):
    i = len(x) // 2
    ax.add_patch(FancyArrowPatch((x[i - 4], y[i - 4]), (x[i + 4], y[i + 4]),
                                 arrowstyle="-|>", mutation_scale=20, lw=2.0,
                                 color=color, shrinkA=0, shrinkB=0, zorder=6))

def draw(lang):
    set_font(lang); d = L[lang]
    th = np.linspace(0.02, 1.0, 400)
    kap_ceil = np.exp(-((th - 0.55) / 0.32) ** 2)
    fig, ax = plt.subplots(figsize=(10.6, 7.0), dpi=200)
    ax.plot(th, kap_ceil, color=P["good"], lw=2.6)
    ax.fill_between(th, 0, kap_ceil, color=P["good"], alpha=0.07)
    ax.text(0.72, 0.95, d["ceil"], fontsize=10.5, color=P["good"])
    ax.axhspan(0.16, 0.30, color=P["cost"], alpha=0.16)
    ax.text(0.22, 0.225, d["band"], ha="center", fontsize=10, color="#8A5A12")

    # 三条轨迹均受天花板约束，满足 κ_State(t) ≤ κ_Ceiling(θ(t)) 的理论边界
    t1 = np.linspace(0.46, 0.55, 200)
    k1 = 0.80 * np.exp(-((t1 - 0.55) / 0.32) ** 2)
    t2 = np.linspace(0.55, 0.42, 200)
    k2 = 0.92 * np.exp(-((t2 - 0.55) / 0.17) ** 2)
    t3 = np.linspace(0.60, 0.48, 200)
    k3 = 0.235 + 0.02 * (t3 - 0.48)

    ax.plot(t1, k1, color=P["actual"], lw=2.4, label=d["a"])
    ax.plot(t2, k2, color=P["gap"], lw=2.4, label=d["b"])
    ax.plot(t3, k3, color=P["cost"], lw=3.2, ls="--", label=d["c"])
    head(ax, t1, k1, P["actual"])
    head(ax, t2, k2, P["gap"])
    head(ax, t3, k3, P["cost"])

    k_sh = 0.92 * np.exp(-((0.44 - 0.55) / 0.17) ** 2)
    ax.plot([0.44], [k_sh], marker="o", ms=7, color=P["gap"], zorder=6)
    ax.annotate("", xy=(0.44, 0.42), xytext=(0.44, k_sh),
                arrowprops=dict(arrowstyle="-|>", color=P["dead"], lw=1.8, ls="--"))
    ax.annotate(d["sh"], xy=(0.44, 0.51), xytext=(0.47, 0.55), fontsize=10,
                color=P["dead"], arrowprops=dict(arrowstyle="->", color=P["dead"], lw=1.4))

    ax.set_xlim(0, 1.02); ax.set_ylim(0, 1.12)
    ax.set_xlabel(d["x"], fontsize=11.5); ax.set_ylabel(d["y"], fontsize=11.5)
    ax.legend(frameon=False, fontsize=10.5, loc="upper left")
    plain_axes(ax); ax.grid(alpha=0.25, ls=":", color=P["grid"])
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    fig.text(0.5, 0.882, d["proj"], ha="center", fontsize=9.0, color="#9AA7B4")
    footer(fig, lang); save(fig, lang, "fig6_3_1_phase_portrait")

for lg in ("zh", "en"):
    draw(lg)
