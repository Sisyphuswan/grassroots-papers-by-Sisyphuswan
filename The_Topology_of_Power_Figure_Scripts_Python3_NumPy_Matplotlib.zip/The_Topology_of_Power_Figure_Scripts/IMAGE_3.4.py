# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 3.4 —— 节点权力的三维解构

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 3.4  节点权力的三维解构：一个官员手里到底有几种权力",
        note="三种来源的「抗更迭性」天差地别——这决定了他的威慑是空心化的，还是一个真军阀",
        root="节点 i 的表观权力构成（三维解构）",
        c1="契约授权", s1="κ_Contract", d1="制度印章 / 头衔 / 编制",
        c2="实体网络", s2="κ_Network", d2="派系 / 私人武装 / 地方财权",
        c3="寄生依附", s3="κ_Parasitic", d3="特定统治者的私人宠信",
        k1="随一纸免职令\n瞬间归零", k2="衰减极慢\n长在骨头里", k3="随君主死亡\n当天归零",
    ),
    "en": dict(
        t="Figure 3.4  Decomposing a node's power: three physically distinct sources",
        note="Their resistance to regime change differs wildly — deterrence hollowing-out or warlord?",
        root="Apparent power decomposition of node i",
        c1="Contract", s1="κ_Contract", d1="Seals / titles / establishment",
        c2="Network", s2="κ_Network", d2="Faction / private force / local finance",
        c3="Parasitic", s3="κ_Parasitic", d3="Personal favour of the ruler",
        k1="Zeroed by a single\ndismissal order", k2="Decays very slowly\n— grown into the bone",
        k3="Zeroed the day\nthe ruler dies",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(11.6, 7.2), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.87, bottom=0.03, left=0.02, right=0.98)
    ax.set_xlim(0, 12); ax.set_ylim(0, 10); ax.axis("off")
    ax.add_patch(FancyBboxPatch((3.60, 8.55), 4.80, 0.95,
                 boxstyle="round,pad=0.10,rounding_size=0.14",
                 facecolor=P["actual"], alpha=0.15, edgecolor=P["actual"], lw=2.0))
    ax.text(6.00, 9.02, d["root"], ha="center", va="center",
            fontsize=12.5, fontweight="bold", color=P["actual"])
    xs = [1.95, 6.00, 10.05]
    cols = [P["claimed"], P["inc"], P["gap"]]
    kids = [(d["c1"], d["s1"], d["d1"], d["k1"]),
            (d["c2"], d["s2"], d["d2"], d["k2"]),
            (d["c3"], d["s3"], d["d3"], d["k3"])]
    ax.plot([6.00, 6.00], [8.50, 7.95], color=P["text"], lw=1.8)
    ax.plot([xs[0], xs[2]], [7.95, 7.95], color=P["text"], lw=1.8)
    for x, col, (c, s, dd, k) in zip(xs, cols, kids):
        ax.add_patch(FancyArrowPatch((x, 7.95), (x, 7.35),
                     arrowstyle="-|>", mutation_scale=18, color=P["text"], lw=1.6))
        ax.add_patch(FancyBboxPatch((x - 1.72, 5.55), 3.44, 1.78,
                     boxstyle="round,pad=0.10,rounding_size=0.12",
                     facecolor=col, alpha=0.14, edgecolor=col, lw=2.0))
        ax.text(x, 6.92, c, ha="center", va="center", fontsize=12.0,
                fontweight="bold", color=col)
        ax.text(x, 6.36, s, ha="center", va="center", fontsize=11.0, color=P["text"])
        ax.text(x, 5.90, dd, ha="center", va="center", fontsize=9.0, color="#5C6773")
        ax.add_patch(FancyArrowPatch((x, 5.50), (x, 4.72),
                     arrowstyle="-|>", mutation_scale=16, color=col, lw=1.6))
        ax.add_patch(FancyBboxPatch((x - 1.72, 3.12), 3.44, 1.55,
                     boxstyle="round,pad=0.08,rounding_size=0.10",
                     facecolor="white", edgecolor=col, lw=1.6, ls="--"))
        ax.text(x, 3.89, k, ha="center", va="center", fontsize=9.8, color=col)
    ax.text(6.00, 2.25, d["note"], ha="center", va="center",
            fontsize=10.0, color="#5C6773")
    fig.text(0.5, 0.962, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    footer(fig, lang); save(fig, lang, "fig3_4_node_three")

for lg in ("zh", "en"):
    draw(lg)
