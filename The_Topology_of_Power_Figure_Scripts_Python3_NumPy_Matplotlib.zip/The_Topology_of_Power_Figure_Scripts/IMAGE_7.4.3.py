# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 7.4.3 —— 双委托人剪刀差与结构性激励赤字

import numpy as np, matplotlib.pyplot as plt

def draw(lang):
    set_font(lang)
    fig, ax = plt.subplots(figsize=(10.5, 6.2), dpi=200)
    cull = np.linspace(0.1, 1.0, 200)
    
    # MeritPay baseline, FactionDebt increases in Cull, LoyaltyCap decreases in Cull
    merit = np.full_like(cull, 0.42)
    debt = 0.15 + 0.35 * cull
    total_req = merit + debt
    cap = 0.85 - 0.55 * cull
    
    ax.plot(cull, merit, color=P["claimed"], lw=2.0, ls=":", label="事功应得对价 MeritPay" if lang=="zh" else "Merit Pay (Baseline)")
    ax.plot(cull, debt, color="#D97706", lw=2.2, ls="--", label="派系索取债务 FactionDebt(Cull)" if lang=="zh" else "Faction Debt FactionDebt(Cull)")
    ax.plot(cull, total_req, color=P["dead"], lw=2.8, label="总需求门槛 MeritPay + FactionDebt(Cull)" if lang=="zh" else "Total Demand (MeritPay + FactionDebt)")
    ax.plot(cull, cap, color=P["inc"], lw=3.0, label="中枢忠诚出价上限 LoyaltyCap(Cull)" if lang=="zh" else "Central Price Ceiling LoyaltyCap(Cull)")
    
    # Shading Total Incentive Gap: MeritPay + FactionDebt(Cull) - LoyaltyCap(Cull)
    ax.fill_between(cull, cap, total_req, where=(total_req > cap), color=P["dead"], alpha=0.18, label="结构性总激励赤字 IncentiveGap_total" if lang=="zh" else "Total Incentive Gap")
    
    ax.text(0.68, 0.62, "双委托人剪刀差\nIncentiveGap_total > 0" if lang=="zh" else "Dual-Principal Scissors\nIncentiveGap_total > 0", ha="center", fontsize=9.8, color=P["dead"], fontweight="bold")
    ax.text(0.84, 0.21, "中枢买不起忠诚\nLoyaltyCap 随 Cull 暴跌" if lang=="zh" else "Central Price Collapses", ha="center", fontsize=9.0, color=P["inc"])
    
    ax.set_xlim(0.1, 1.0); ax.set_ylim(0.1, 1.0)
    ax.set_xlabel("清洗整肃强度 Cull" if lang=="zh" else "Purge Intensity Cull", fontsize=11.0)
    ax.set_ylabel("价格与支付额度" if lang=="zh" else "Price & Payoff Level", fontsize=11.0)
    ax.set_title("图 7.4.3  双委托人剪刀差：中枢限价与派系索取撕裂微观激励" if lang=="zh" else "Figure 7.4.3 Dual-Principal Scissors: Price Ceiling vs Faction Demand", fontsize=12.5, fontweight="bold")
    ax.legend(loc="upper left", frameon=False, fontsize=8.8)
    plain_axes(ax); ax.grid(True, ls=":", color=P["grid"], alpha=0.6)
    footer(fig, lang); save(fig, lang, "fig7_4_3_dual_principal_gap")

for lg in ("zh", "en"):
    draw(lg)
