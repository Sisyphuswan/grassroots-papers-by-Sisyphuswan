# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 2.2.4.2 —— 两种 Status 的对照（中英双语）

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 2.2.4.2  两种 Status：终点相同，中间隔了一道黑箱",
        note="判据从「人身依附」转向「统计归类」——不可抗辩性反而更强",
        row1="传统家产制 Status", s1=["血缘派系\n人身依附", "直接决定\n司法豁免或定罪"],
        tag1="显性 · 可求情 · 留有缝隙",
        row2="算法重构的 Status", s2=["行为数据\n地域标签\n设备指纹", "特征工程聚类", "隐性分类歧视"],
        tag2="隐蔽 · 不可申辩 · 黑箱",
    ),
    "en": dict(
        t="Figure 2.2.4.2  Two kinds of Status: same destination, a black box in between",
        note="The criterion shifts from 'whose man are you' to 'which cluster are you in'",
        row1="Traditional patrimonial Status", s1=["Kinship\n& patronage", "Directly decides\nimmunity or guilt"],
        tag1="Explicit · appealable · has cracks",
        row2="Algorithmic Status", s2=["Behaviour data\nGeo tags\nDevice ID", "Feature-engineering\nclustering", "Latent classification"],
        tag2="Opaque · non-appealable · black box",
    ),
}

def chain(ax, y, boxes, tag, col):
    n = len(boxes); w = 2.05; gap = 1.15
    total = n * w + (n - 1) * gap; x0 = (13.2 - total) / 2
    for i, b in enumerate(boxes):
        x = x0 + i * (w + gap)
        ax.add_patch(FancyBboxPatch((x, y), w, 1.5,
                     boxstyle="round,pad=0.06,rounding_size=0.10",
                     facecolor=col, edgecolor="white", lw=1.5, alpha=0.30))
        ax.text(x + w / 2, y + 0.75, b, ha="center", va="center", fontsize=9.6)
        if i < n - 1:
            ax.add_patch(FancyArrowPatch((x + w + 0.06, y + 0.75),
                         (x + w + gap - 0.06, y + 0.75),
                         arrowstyle="-|>", mutation_scale=15,
                         color=P["text"], lw=1.6))
    ax.text(x0 + total / 2, y + 2.0, tag, ha="center", fontsize=9.6, color="#7A828C")

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(13.2, 5.4), dpi=200)
    ax.set_xlim(0, 13.2); ax.set_ylim(0, 5.4); ax.axis("off")
    chain(ax, 2.7, d["s1"], d["tag1"], P["resp"])
    chain(ax, 0.5, d["s2"], d["tag2"], P["actual"])
    ax.text(0.35, 3.45, d["row1"], ha="left", va="center", fontsize=10.5,
            color=P["resp"], fontweight="bold")
    ax.text(0.35, 1.25, d["row2"], ha="left", va="center", fontsize=10.5,
            color=P["actual"], fontweight="bold")
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig2_2_4_2_two_status")

for lg in ("zh", "en"):
    draw(lg)
