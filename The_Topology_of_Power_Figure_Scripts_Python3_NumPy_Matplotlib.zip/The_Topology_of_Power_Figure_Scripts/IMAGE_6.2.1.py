# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 6.2.1 —— 前向因果链（中英双语）

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 6.2.1  前向因果链：$\\theta\\to\\kappa_{\\text{State}}\\to\\Pi\\to A_i\\to \\text{Width}$",
        nodes=["刚柔度\n$\\theta$", "兑现力\n$\\kappa_{\\text{State}}$", "三场\n$\\Pi$",
               "行动域\n$A_i$", "选择广度\n$\\text{Width}$"],
        mech=["执行成本↑\n（倒 U 型天花板）", "三场被截断\n与折算",
              "几何取交集\n最紧边界决胜", "$\\text{Width}=\\mu_{\\text{Lebesgue}}(A_i)$\n测度度量"],
        loop="自噬回环：信任缺失 → 规制收紧 → 兑现力下降",
        warn="机制特征：$\\text{Width}$ 对 $\\kappa_{\\text{State}}$ 非单调——$\\kappa_{\\text{State}}$ 高时恐惧场边界紧闭，$\\text{Width}$ 反而受限",
    ),
    "en": dict(
        t="Figure 6.2.1  The forward causal chain: $\\theta\\to\\kappa_{\\text{State}}\\to\\Pi\\to A_i\\to \\text{Width}$",
        nodes=["Rigidity\n$\\theta$", "Capacity\n$\\kappa_{\\text{State}}$", "Three fields\n$\\Pi$",
               "Action domain\n$A_i$", "Width\n$\\text{Width}$"],
        mech=["Enforcement cost ↑\n(inverted-U ceiling)", "Fields truncated\nand discounted",
              "Geometric intersection\ntightest boundary binds", "$\\text{Width}=\\mu_{\\text{Lebesgue}}(A_i)$\nLebesgue measure"],
        loop="Autophagy loop: distrust → tighter regulation → weaker capacity",
        warn="Note: $\\text{Width}$ is non-monotone in $\\kappa_{\\text{State}}$ — high $\\kappa_{\\text{State}}$ locks fear tighter, restricting $\\text{Width}$",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(13.2, 4.4), dpi=200)
    ax.set_xlim(0, 13.2); ax.set_ylim(0, 4.4); ax.axis("off")
    xs = [1.5, 4.2, 6.9, 9.6, 12.1]
    cols = [P["cost"], P["actual"], P["resp"], P["inc"], P["good"]]
    for x, name, c in zip(xs, d["nodes"], cols):
        ax.add_patch(FancyBboxPatch((x - 0.85, 1.85), 1.7, 1.25,
                     boxstyle="round,pad=0.08,rounding_size=0.12",
                     facecolor=c, edgecolor="white", lw=1.6, alpha=0.92))
        ax.text(x, 2.47, name, ha="center", va="center", color="white",
                fontsize=11.5, fontweight="bold")
    for i in range(4):
        ax.add_patch(FancyArrowPatch((xs[i] + 0.88, 2.47), (xs[i + 1] - 0.88, 2.47),
                     arrowstyle="-|>", mutation_scale=18, color=P["text"], lw=2.0))
        ax.text((xs[i] + xs[i + 1]) / 2, 3.32, d["mech"][i], ha="center",
                fontsize=9.5, color="#7A828C")
    ax.add_patch(FancyArrowPatch((4.2, 1.82), (1.5, 1.82),
                 arrowstyle="-|>", mutation_scale=16, color=P["gap"], lw=2.2,
                 connectionstyle="arc3,rad=-0.34"))
    ax.text(2.85, 1.14, d["loop"], ha="center", fontsize=10, color=P["gap"])
    ax.add_patch(FancyBboxPatch((0.5, 0.35), 12.2, 0.62,
                 boxstyle="round,pad=0.05,rounding_size=0.1",
                 facecolor="#FBE9E7", edgecolor=P["gap"], lw=1.2))
    ax.text(6.6, 0.66, d["warn"], ha="center", va="center", fontsize=10.2,
            color=P["dead"])
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    footer(fig, lang); save(fig, lang, "fig6_2_1_forward_chain")

for lg in ("zh", "en"):
    draw(lg)
