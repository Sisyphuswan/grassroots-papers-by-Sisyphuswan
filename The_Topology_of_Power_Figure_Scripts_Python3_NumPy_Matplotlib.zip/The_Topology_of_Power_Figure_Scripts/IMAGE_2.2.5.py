# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 2.2.5 —— 筛选—处置两环节（中英双语）

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 2.2.5  筛选—处置：Status 决定靶向对象，Inflex 决定情境权重",
        note="两个算子作用于不同环节，故在数学上天然解耦",
        n0="主体全集 Subjects\n潜在对象池", n1="靶向子集 Subjects_target\n被选中的对象",
        n2="处遇结果 [0,1]\n按情境调整 / 一律同一",
        m1="映射一 · Map_Status\n对身份特征敏感？", m2="映射二 · Map_Inflex\n对客观情境敏感？",
        tag="若把两者强行合并为一个维度，'运动式治理'这类现象将无法解释",
    ),
    "en": dict(
        t="Figure 2.2.5  Screening then treating: Status picks the target, Inflex rules out circumstances",
        note="Two operators act at different stages, so they decouple mathematically",
        n0="Subjects universe\nAll potential subjects", n1="Target subset Subjects_target\nThe unlucky ones",
        n2="Treatment [0,1]\nCase-by-case / one-size",
        m1="Map 1 · Map_Status\nSensitive to identity?", m2="Map 2 · Map_Inflex\nSensitive to circumstances?",
        tag="Merging the two into one dimension makes campaign-style governance inexplicable",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(13.2, 5.6), dpi=200)
    ax.set_xlim(0, 13.2); ax.set_ylim(0, 5.6); ax.axis("off")
    nodes = [(0.6, 2.4, d["n0"], P["omega"], P["text"]),
             (5.0, 2.4, d["n1"], P["actual"], "white"),
             (9.4, 2.4, d["n2"], P["fear"], "white")]
    for x, y, s, fc, tc in nodes:
        ax.add_patch(FancyBboxPatch((x, y), 3.1, 1.35,
                     boxstyle="round,pad=0.08,rounding_size=0.12",
                     facecolor=fc, edgecolor=P["grid"], lw=1.4, alpha=0.92))
        ax.text(x + 1.55, y + 0.68, s, ha="center", va="center",
                fontsize=10.2, color=tc)
    for i, lab in enumerate((d["m1"], d["m2"])):
        x0 = nodes[i][0] + 3.15
        ax.add_patch(FancyArrowPatch((x0, 3.075), (x0 + 1.2, 3.075),
                     arrowstyle="-|>", mutation_scale=16, color=P["text"], lw=1.8))
        ax.text(x0 + 0.6, 4.35, lab, ha="center", fontsize=9.6, color="#7A828C")
    ax.add_patch(FancyBboxPatch((0.6, 0.5), 11.9, 0.85,
                 boxstyle="round,pad=0.06,rounding_size=0.10",
                 facecolor="#FBE9E7", edgecolor=P["gap"], lw=1.2))
    ax.text(6.55, 0.92, d["tag"], ha="center", va="center", fontsize=10.2,
            color=P["dead"])
    fig.text(0.5, 0.962, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.918, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig2_2_5_screen_treat")

for lg in ("zh", "en"):
    draw(lg)
