# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 2.4.1 —— 时间锚点（中英双语）

from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

L = {
    "zh": dict(
        t="图 2.4.1  两个时间锚点：Inflex 与 Elastic 正交",
        note="执行时情境是否计入，事后发现偏差能否撤回——两个独立问题",
        n=["政策颁布 / 指令出台", "事中执行那一刻  t0", "后果显现 / 发生偏差  t1"],
        b1="Inflex  裁量压缩度\n机械套用，还是留缓冲？",
        b2="Elastic  回撤弹性\n发现误判后，能否撤回纠偏？",
        x="时间因果箭头",
    ),
    "en": dict(
        t="Figure 2.4.1  Two time anchors: Inflex and Elastic are orthogonal",
        note="Does circumstance still count at the cut, and can the cut be undone — two questions",
        n=["Policy issued", "At enforcement  t0", "Consequences appear  t1"],
        b1="Inflex — discretion compressed\nBlanket rule, or room to buffer?",
        b2="Elastic — reversibility\nOnce the error shows, can it be undone?",
        x="Time",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(13.2, 5.4), dpi=200)
    ax.set_xlim(0, 13.2); ax.set_ylim(0, 5.4); ax.axis("off")
    xs = [1.9, 6.6, 11.3]
    ax.add_patch(FancyArrowPatch((0.8, 1.5), (12.6, 1.5),
                 arrowstyle="-|>", mutation_scale=18, color=P["text"], lw=1.8))
    ax.text(12.6, 1.05, d["x"], ha="right", fontsize=10, color="#7A828C")
    for x, n in zip(xs, d["n"]):
        ax.plot([x], [1.5], marker="o", ms=9, color=P["text"])
        ax.text(x, 0.80, n, ha="center", va="top", fontsize=9.8)
    for x, txt, col in ((xs[1], d["b1"], P["cost"]), (xs[2], d["b2"], P["inc"])):
        ax.add_patch(FancyBboxPatch((x - 2.1, 2.6), 4.2, 1.5,
                     boxstyle="round,pad=0.08,rounding_size=0.12",
                     facecolor=col, edgecolor="white", lw=1.6, alpha=0.30))
        ax.text(x, 3.35, txt, ha="center", va="center", fontsize=10.2)
        ax.add_patch(FancyArrowPatch((x, 2.58), (x, 1.62),
                     arrowstyle="-|>", mutation_scale=13, color=col, lw=1.6))
    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.912, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig2_4_1_time_anchors")

for lg in ("zh", "en"):
    draw(lg)
