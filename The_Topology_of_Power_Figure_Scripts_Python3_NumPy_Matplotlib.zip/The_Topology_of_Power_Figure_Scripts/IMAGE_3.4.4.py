# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 3.4.4 —— 相对自主度 η_i 的四区间相态图谱

from matplotlib.patches import Rectangle

L = {
    "zh": dict(
        t="图 3.4.4  相对自主度 η_i 的四区间相态图谱",
        note="同一个比值，四种命运：奉旨办事，逐事协商，半独立，反向要挟",
        y="相对自主度  η_i",
        r4="逆向割据区　η_i > 2.0",
        r4s="代理人蜕为事实上的割据势力，反向以断绝效忠要挟中央输饷",
        r3="半独立区　1.0 < η_i ≤ 2.0",
        r3s="实体网络超过中央水位：账外资金、私人执法力量、政策被选择性肢解",
        r2="网络自持区　0.5 < η_i ≤ 1.0",
        r2s="网络与中央大体相当，靠士绅宗族纽带维持最低限度的双轨治理",
        r1="合规执行区　0 ≤ η_i ≤ 0.5",
        r1s="契约授权占支配地位，中央指令能够实现高精度的物理兑现",
        tk1="0.5", tk2="1.0", tk3="2.0",
    ),
    "en": dict(
        t="Figure 3.4.4  Relative autonomy η_i: four regimes of political dynamics",
        note="One ratio, four fates: obeying orders, bargaining, semi-independence, outgrowing the centre",
        y="Relative autonomy  η_i",
        r4="Secession　η_i > 2.0",
        r4s="The agent turns warlord, extorting subsidies by threatening defection",
        r3="Semi-independent　1.0 < η_i ≤ 2.0",
        r3s="Node network exceeds the centre: off-book funds, private enforcers, gutted policies",
        r2="Network-sustained　0.5 < η_i ≤ 1.0",
        r2s="Network matches the centre; dual-track governance brokered with local gentry",
        r1="Compliant execution　0 ≤ η_i ≤ 0.5",
        r1s="Contractual authorisation dominates; central orders are physically delivered",
        tk1="0.5", tk2="1.0", tk3="2.0",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(11.2, 8.2), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.855, bottom=0.03, left=0.05, right=0.97)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")
    bands = [(7.36, P["gap"],    d["r4"], d["r4s"]),
             (5.42, P["cost"],   d["r3"], d["r3s"]),
             (3.48, P["inc"],    d["r2"], d["r2s"]),
             (1.54, P["actual"], d["r1"], d["r1s"])]
    for y, col, lab, sub in bands:
        ax.add_patch(Rectangle((1.22, y), 8.40, 1.74,
                     facecolor=col, alpha=0.14, edgecolor=col, lw=1.8))
        ax.text(5.42, y + 1.19, lab, ha="center", va="center",
                fontsize=11.8, fontweight="bold", color=col)
        ax.text(5.42, y + 0.55, sub, ha="center", va="center",
                fontsize=9.2, color=P["text"])
    ax.plot([1.22, 1.22], [0.88, 9.22], color=P["text"], lw=2.0)
    for gy, tk in ((3.37, d["tk1"]), (5.31, d["tk2"]), (7.25, d["tk3"])):
        ax.plot([1.22, 9.62], [gy, gy], color=P["grid"], lw=1.0, ls=(0, (3, 3)))
        ax.text(1.04, gy, tk, ha="right", va="center", fontsize=9.6, color=P["dead"])
    ax.text(0.24, 5.05, d["y"], ha="center", va="center", rotation=90,
            fontsize=11.5, color=P["text"])
    fig.text(0.5, 0.962, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.926, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig3_4_4_eta_regimes")

for lg in ("zh", "en"):
    draw(lg)
