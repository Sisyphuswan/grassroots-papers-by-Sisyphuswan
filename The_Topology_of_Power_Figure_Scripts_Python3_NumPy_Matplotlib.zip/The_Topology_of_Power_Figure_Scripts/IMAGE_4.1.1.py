# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 4.1.1 —— 三场探照灯：实态场为源，θ / κ 调制 → 三场 → 许可侧取交 → A_i

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 4.1.1  三场探照灯：宏观实态场如何落到个体身上",
        note="θ 决定光圈形状与边界锐利度，κ 决定边界能否落到该坐标",
        s1="实态场  Π_actual", s2="调制：θ 定形 ／ κ 定落点",
        b1="激励场  Π_Incentive", d1="存续资源准入 · 即期与跨期两种兑现",
        b2="恐惧场  Π_Fear", d2="免于绝对制裁的生存安全区",
        b3="责任场  Π_Responsibility", d3="不可退出的角色依附 · 科层／岗位／亲缘",
        op="核心算子：许可侧严格取交  ∩",
        ai="个体可行行动域  A_i", ai2="三盏灯交汇的那块光斑 —— 真正走得通的那部分",
    ),
    "en": dict(
        t="Figure 4.1.1  Three spotlights: how the actual field lands on the individual",
        note="θ sets the beam shape and the sharpness of its edge; κ decides whether that edge can land at this coordinate",
        s1="Actual field  Π_actual", s2="modulation: θ shapes / κ engages",
        b1="Incentive field  Π_Incentive", d1="subsistence admission: immediate & deferred realization",
        b2="Fear field  Π_Fear", d2="safety zone exempt from sanction",
        b3="Responsibility field  Π_Responsibility", d3="non-exit role bond: office, post, kin",
        op="Core operator: strict intersection on the permissive side  ∩",
        ai="Individual action domain  A_i", ai2="the overlap of the three beams — the passable part",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fs_t = 12.0 if lang == "zh" else 9.6   # 英文串更长，三场方框内单独降字号
    fs_s = 9.4 if lang == "zh" else 8.3

    def box(x, y, w, h, col, title, sub=None, fs=12.0, fs2=9.4, alpha=0.14):
        ax.add_patch(FancyBboxPatch((x, y), w, h,
                     boxstyle="round,pad=0.08,rounding_size=0.12",
                     facecolor=col, alpha=alpha, edgecolor=col, lw=1.9))
        if sub:
            ax.text(x + w / 2, y + h * 0.68, title, ha="center", va="center",
                    fontsize=fs, fontweight="bold", color=col)
            ax.text(x + w / 2, y + h * 0.27, sub, ha="center", va="center",
                    fontsize=fs2, color=P["text"])
        else:
            ax.text(x + w / 2, y + h / 2, title, ha="center", va="center",
                    fontsize=fs, fontweight="bold", color=col)

    def arrow(p, q):
        ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=20,
                     color=P["text"], lw=1.9))

    fig, ax = plt.subplots(figsize=(10.6, 7.4), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.87, bottom=0.03, left=0.02, right=0.98)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")

    box(0.55, 8.55, 4.20, 0.95, P["actual"], d["s1"], fs=12.0, alpha=0.12)
    box(5.25, 8.55, 4.20, 0.95, P["actual"], d["s2"], fs=12.0, alpha=0.12)
    arrow((5.00, 8.45), (5.00, 7.72))

    box(0.40, 5.60, 3.00, 1.95, P["inc"],  d["b1"], d["d1"], fs=fs_t, fs2=fs_s)
    box(3.50, 5.60, 3.00, 1.95, P["fear"], d["b2"], d["d2"], fs=fs_t, fs2=fs_s)
    box(6.60, 5.60, 3.00, 1.95, P["resp"], d["b3"], d["d3"], fs=fs_t, fs2=fs_s)
    for x0 in (1.90, 5.00, 8.10):
        arrow((x0, 5.50), (5.00, 4.64))

    ax.text(5.00, 4.32, d["op"], ha="center", va="center", fontsize=10.2,
            color="#5C6773", bbox=dict(boxstyle="round,pad=0.35",
            facecolor=P["light_bg"], edgecolor=P["grid"], lw=1.0))
    arrow((5.00, 3.94), (5.00, 3.30))

    box(2.45, 1.55, 5.10, 1.70, P["inc"], d["ai"], d["ai2"],
        fs=13.0, fs2=9.6, alpha=0.26)

    fig.text(0.5, 0.962, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.926, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig4_1_1_three_spotlights")


for lg in ("zh", "en"):
    draw(lg)
