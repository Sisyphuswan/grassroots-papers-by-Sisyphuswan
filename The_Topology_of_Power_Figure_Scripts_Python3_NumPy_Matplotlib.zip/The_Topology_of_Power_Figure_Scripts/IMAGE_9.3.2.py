# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 9.3.2 —— 国家幻觉与 TFE 两期沙盘算术（中英双语）

import numpy as np

L = {
    "zh": dict(
        t="图 9.3.2  国家幻觉算术：真实增产与名义减税下的物理破百抽取",
        note="第 t 期真实增产 12.5% 且名义税率下调 10 个百分点，仍因虚报倍率 2.22 倍跌破 125 存续底线，并在 t+1 期触发 133.3% 抽血",
        pa="A 栏：TFE 沙盘三期产出、征购与留存对照",
        pb="B 栏：名义减税 vs 真实物理抽取率破百剪刀差",
        periods=["基期 (t=0)", "第 t 期\n(真增产+减税)", "第 t+1 期\n(劳力抽空崩塌)"],
        rep="中央汇报产出  $\\mathrm{Report}_{\\mathrm{central}}$",
        real="真实物理产出  $\\mathrm{Output}_{\\mathrm{real}}$",
        targ="刚性征购目标  $\\mathrm{ExtractionTarget}$",
        ret="农户物理留存",
        floor="生理与种子最低门槛  $\\mathrm{Gain}_{\\min}=125$",
        nom="名义抽取率  $\\mathrm{Tax}_{\\mathrm{nominal}}$",
        act="真实物理抽取率  $\\mathrm{Tax}_{\\mathrm{actual}}$",
        cliff="100% 物理红线（动用口粮与种子存量）",
        y1="粮食当量（单位）", y2="抽取率（%）",
    ),
    "en": dict(
        t="Figure 9.3.2  State Hallucination Arithmetic: Over-100% Extraction Under Real Growth & Tax Cuts",
        note="At t, +12.5% real output growth and a 10 percentage-point nominal tax cut still breach the 125 floor via 2.22x over-reporting, triggering 133.3% extraction at t+1",
        pa="Panel A: Three-period output, target, and retention",
        pb="Panel B: Nominal tax cut vs. actual extraction breach",
        periods=["Baseline (t=0)", "Period t\n(Growth + Tax Cut)", "Period t+1\n(Labor Drain Collapse)"],
        rep="Reported output  $\\mathrm{Report}_{\\mathrm{central}}$",
        real="Real output  $\\mathrm{Output}_{\\mathrm{real}}$",
        targ="Extraction target  $\\mathrm{ExtractionTarget}$",
        ret="Farmer retained residual",
        floor="Survival & seed floor  $\\mathrm{Gain}_{\\min}=125$",
        nom="Nominal tax rate  $\\mathrm{Tax}_{\\mathrm{nominal}}$",
        act="Actual physical rate  $\\mathrm{Tax}_{\\mathrm{actual}}$",
        cliff="100% physical cliff (stock & seed confiscation)",
        y1="Grain units", y2="Extraction rate (%)",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.6, 6.1), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.80, bottom=0.16, wspace=0.22)

    x = np.arange(3)
    w = 0.20
    rep = [400, 1000, 1000]
    real = [400, 450, 300]
    targ = [200, 400, 400]
    ret = [200, 50, -100]

    ax1.bar(x - 1.5*w, rep, w, facecolor="none", edgecolor=P["claimed"], ls="--", lw=1.8, label=d["rep"])
    ax1.bar(x - 0.5*w, real, w, color=P["actual"], label=d["real"])
    ax1.bar(x + 0.5*w, targ, w, color=P["cost"], label=d["targ"])
    ret_colors = [P["good"], P["gap"], P["dead"]]
    ax1.bar(x + 1.5*w, ret, w, color=ret_colors, label=d["ret"])
    ax1.axhline(125, color=P["fear"], ls=":", lw=2.0, label=d["floor"])
    ax1.axhline(0, color=P["text"], lw=0.8)
    for xi, val in zip(x + 1.5*w, ret):
        ax1.text(xi, val + (22 if val >= 0 else -58), f"{val}", ha="center", fontsize=8.8, fontweight="bold")
    ax1.set_xticks(x); ax1.set_xticklabels(d["periods"], fontsize=9.2)
    ax1.set_ylim(-180, 1120); ax1.set_ylabel(d["y1"], fontsize=10.5)
    ax1.set_title(d["pa"], fontsize=11.3, fontweight="bold")
    ax1.legend(loc="upper left", frameon=False, fontsize=8.2)
    plain_axes(ax1); ax1.grid(axis="y", color=P["grid"], lw=0.6)

    nom = [50.0, 40.0, 40.0]
    act = [50.0, 88.9, 133.3]
    ax2.axhspan(100, 155, facecolor=P["dead"], alpha=0.14, label=d["cliff"])
    ax2.axhline(100, color=P["fear"], ls="--", lw=1.8)
    ax2.plot(x, nom, color=P["claimed"], ls="--", marker="s", ms=7, lw=2.2, label=d["nom"])
    ax2.plot(x, act, color=P["dead"], marker="o", ms=8, lw=2.8, label=d["act"])
    for xi, nv, av in zip(x, nom, act):
        ax2.text(xi, nv - 10, f"{nv:.0f}%", ha="center", fontsize=8.8, color=P["claimed"], fontweight="bold")
        ax2.text(xi, av + 6, f"{av:.1f}%", ha="center", fontsize=9.2, color=P["dead"], fontweight="bold")
    ax2.set_xticks(x); ax2.set_xticklabels(d["periods"], fontsize=9.2)
    ax2.set_ylim(0, 155); ax2.set_ylabel(d["y2"], fontsize=10.5)
    ax2.set_title(d["pb"], fontsize=11.3, fontweight="bold")
    ax2.legend(loc="upper left", frameon=False, fontsize=8.6)
    plain_axes(ax2); ax2.grid(axis="y", color=P["grid"], lw=0.6)

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.2, fontweight="bold")
    fig.text(0.5, 0.905, d["note"], ha="center", fontsize=9.1, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig9_3_2_state_hallucination")

for lg in ("zh", "en"):
    draw(lg)
