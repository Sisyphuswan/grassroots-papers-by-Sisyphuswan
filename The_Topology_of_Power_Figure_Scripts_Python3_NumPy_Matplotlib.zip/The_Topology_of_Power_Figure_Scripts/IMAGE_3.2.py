# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 3.2 —— 三层拓扑折叠：宣称层 → 承载层 → 实态层

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 3.2  三层拓扑折叠：宣称、承载与实态",
        note="权力落地要过两道门槛：先按威慑效率比截断，再按承载能力折算",
        b1="宣称层  Π_claimed", s1="法律文本 / 宣传口号 / 禁令目录",
        b2="承载层  κ_State", s2="中央实际具备的暴力与资源",
        b3="实态层  Π_actual", s3="作用于个体的实际约束与保障",
        a1="受制于财政、物流、执行者忠诚度\n→ 实际水位低于天花板",
        a2="按威慑效率比截断，再按 κ 折算（算子 ⊙）",
    ),
    "en": dict(
        t="Figure 3.2  Three-layer topological folding: claimed, capacity, actual",
        note="Power passes two gates: truncated by the deterrence-efficiency ratio, then discounted by capacity",
        b1="Claimed  Π_claimed", s1="Statutes / slogans / banned lists",
        b2="Capacity  κ_State", s2="Violence and resources actually held",
        b3="Actual  Π_actual", s3="Constraints and protections actually binding the individual",
        a1="Constrained by fiscal reach, logistics, loyalty\n→ actual water level falls below the ceiling",
        a2="Truncated by the deterrence-efficiency ratio, then discounted by κ (operator ⊙)",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(10.6, 7.0), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.86, bottom=0.03, left=0.02, right=0.98)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")
    boxes = [(7.40, P["claimed"], d["b1"], d["s1"]),
             (4.30, P["actual"],  d["b2"], d["s2"]),
             (1.20, P["inc"],     d["b3"], d["s3"])]
    for y, col, title, sub in boxes:
        ax.add_patch(FancyBboxPatch((0.70, y), 8.60, 1.45,
                     boxstyle="round,pad=0.10,rounding_size=0.14",
                     facecolor=col, alpha=0.14, edgecolor=col, lw=2.0))
        ax.text(5.00, y + 1.00, title, ha="center", va="center",
                fontsize=12.5, fontweight="bold", color=col)
        ax.text(5.00, y + 0.44, sub, ha="center", va="center",
                fontsize=9.6, color=P["text"])
    for y0, lab in ((7.30, d["a1"]), (4.20, d["a2"])):
        ax.add_patch(FancyArrowPatch((2.30, y0), (2.30, y0 - 1.30),
                     arrowstyle="-|>", mutation_scale=22, color=P["text"], lw=1.9))
        ax.text(2.62, y0 - 0.65, lab, ha="left", va="center",
                fontsize=9.4, color="#5C6773")
    fig.text(0.5, 0.960, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.922, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig3_2_three_layers")

for lg in ("zh", "en"):
    draw(lg)
