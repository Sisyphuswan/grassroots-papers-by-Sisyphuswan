# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 6.5.3 —— 弹簧过冲 Stress(t)（中英双语）

import numpy as np, matplotlib.pyplot as plt

L = {
    "zh": dict(t="图 6.5.3  弹簧过冲：应力累积 $\\text{Stress}$ 与承载线 $\\text{Hold}\\,\\kappa_{\\text{State}}$（含耦合 ODE 与 $\\text{Sep}^{-1}=40$）",
               x="时间 $t$", y1="瞬时速率", y2="存量水位 / 承载线",
               g="应力产生 $\\text{StressInflow}(\\theta)$", r="泄压 $\\text{Release}(\\theta,\\text{Stress})$（含饱和项）",
               lam="累积应力 $\\text{Stress}$", carry="承载线 $\\text{Hold}\\,\\kappa_{\\text{State}}$",
               cross="越过承载 → $\\kappa_{\\text{State}}$ 侵蚀激活",
               note="按附 6.C.4 耦合微分方程积分（$\\text{Sep}^{-1}=40$）：未越线前 $\\kappa_{\\text{State}}$ 维持稳态，越线后自噬侵蚀立即启动。"),
    "en": dict(t="Figure 6.5.3  Spring overshoot: coupled $\\text{Stress}$ overshoot and carrying line $\\text{Hold}\\,\\kappa_{\\text{State}}$",
               x="Time $t$", y1="Instantaneous rate", y2="Stock / carrying line",
               g="Stress inflow $\\text{StressInflow}(\\theta)$", r="Release $\\text{Release}(\\theta,\\text{Stress})$ (saturated)",
               lam="Accumulated stress $\\text{Stress}(t)$", carry="Carrying line $\\text{Hold}\\,\\kappa_{\\text{State}}(t)$",
               cross="Past carrying line → $\\kappa_{\\text{State}}$ starts eroding",
               note="Integrated from 6.C.4 coupled ODEs ($\\text{Sep}^{-1}=40$): $\\kappa_{\\text{State}}$ holds steady before threshold crossing, then erodes once overloaded."),
}

def draw(lang):
    set_font(lang); d = L[lang]
    t = np.linspace(0, 40, 1200)
    dt = float(t[1] - t[0])
    sep_inv, hold, erode = 40.0, 0.95, 0.022
    theta = 0.72 - 0.29 / (1.0 + np.exp(-0.35 * (t - 12.0)))
    G = 0.020 + 0.090 * (1.0 - theta)
    lam = np.zeros_like(t)
    kap = np.zeros_like(t)
    lam[0], kap[0] = 0.36, 0.72
    for n in range(len(t) - 1):
        R_n = 0.055 * theta[n] + 0.045 * (1.0 - np.exp(-lam[n] / 3.0))
        ds = sep_inv * (G[n] - R_n)
        if lam[n] <= 0.0 and ds < 0.0:
            ds = 0.0
        k_ceil = float(np.exp(-((theta[n] - 0.55) / 0.32) ** 2))
        repair = 0.025 * theta[n] * max(0.0, k_ceil - kap[n])
        erosion = erode * max(0.0, lam[n] - hold * kap[n]) * (1.0 - theta[n]) * kap[n]
        lam[n + 1] = max(0.0, lam[n] + ds * dt)
        kap[n + 1] = float(np.clip(kap[n] + (repair - erosion) * dt, 0.0, k_ceil))
    R = 0.055 * theta + 0.045 * (1.0 - np.exp(-lam / 3.0))
    carry = hold * kap
    i = int(np.argmax(lam > carry))

    fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(11.0, 7.2), dpi=200,
                                   gridspec_kw={"height_ratios": [1.0, 1.35], "hspace": 0.14})
    fig.subplots_adjust(top=0.84, bottom=0.11, left=0.10, right=0.97)
    ax1.plot(t, G, color=P["cost"], lw=2.6, label=d["g"])
    ax1.plot(t, R, color=P["actual"], lw=2.6, ls="--", label=d["r"])
    ax1.axvline(t[i], color=P["dead"], lw=1.6, ls=":")
    ax1.legend(frameon=False, fontsize=9.8, loc="upper left", ncol=2)
    ax1.set_ylabel(d["y1"], fontsize=11); ax1.set_ylim(0.02, 0.105)
    plain_axes(ax1); ax1.grid(axis="y", color=P["grid"], lw=0.6)

    ax2.plot(t, lam, color=P["gap"], lw=3.0, label=d["lam"])
    ax2.plot(t, carry, color=P["good"], lw=2.6, label=d["carry"])
    ax2.axvline(t[i], color=P["dead"], lw=1.6, ls=":")
    ax2.fill_between(t, carry, lam, where=(lam > carry), color=P["dead"], alpha=0.16)
    ax2.annotate(d["cross"], xy=(t[i], carry[i]), xytext=(t[i] + 3.0, 0.85 * lam.max()),
                 fontsize=10.2, color=P["dead"], fontweight="bold",
                 arrowprops=dict(arrowstyle="->", color=P["dead"], lw=1.4))
    ax2.set_xlim(0, 40); ax2.set_ylim(0, lam.max() * 1.12)
    ax2.set_xlabel(d["x"], fontsize=11.5); ax2.set_ylabel(d["y2"], fontsize=11)
    ax2.legend(frameon=False, fontsize=10, loc="upper left")
    plain_axes(ax2); ax2.grid(axis="y", color=P["grid"], lw=0.6)

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.0, fontweight="bold")
    fig.text(0.5, 0.912, d["note"], ha="center", fontsize=9.2, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig6_5_3_spring_overshoot")

for lg in ("zh", "en"):
    draw(lg)
