# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 4.3.5 —— 两阶段决策：先交集划定 A_i，再在 A_i 内部偏好加权

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 4.3.5  决策的两个阶段：先定生死边界，再谈偏好排序",
        note="阶段一是具有否决权的集合运算；阶段二才轮到效用函数进场",
        s0="社会行动全域  Ω",
        g1="阶段一　拓扑交集（受三场交集否决）",
        s1="个体可行行动域  A_i",
        c1="单点态  {a}", c1d="结构锁死，只剩服从",
        c2=r"空集态  $\emptyset$", c2d="约束错位，孤注一掷或反叛",
        g2="阶段二　效用权衡（仅在 A_i 内含多个非劣选项时激活）",
        s2="在 A_i 内部求最优：最终行为  a*",
    ),
    "en": dict(
        t="Figure 4.3.5  Two stages of decision: first the life-and-death boundary, then preference",
        note="Stage 1 is a set operation with veto power; only stage 2 lets the utility function in",
        s0="Social action universe  Ω",
        g1="Stage 1 — topological intersection (rigidly vetoed by the three-field intersection)",
        s1="Individual action domain  A_i",
        c1="Single-point state  {a}", c1d="structure locked, obey only",
        c2="Empty state  ∅", c2d="constraints misaligned, revolt or break",
        g2="Stage 2 — utility trade-off (only if A_i holds several non-dominated options)",
        s2="Optimize inside A_i: final behaviour  a*",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]

    def box(x, y, w, h, col, title, sub=None, fs=12.0, fs2=9.4, alpha=0.14):
        ax.add_patch(FancyBboxPatch((x, y), w, h,
                     boxstyle="round,pad=0.08,rounding_size=0.12",
                     facecolor=col, alpha=alpha, edgecolor=col, lw=1.9))
        if sub:
            ax.text(x + w / 2, y + h * 0.66, title, ha="center", va="center",
                    fontsize=fs, fontweight="bold", color=col)
            ax.text(x + w / 2, y + h * 0.26, sub, ha="center", va="center",
                    fontsize=fs2, color=P["text"])
        else:
            ax.text(x + w / 2, y + h / 2, title, ha="center", va="center",
                    fontsize=fs, fontweight="bold", color=col)

    def arrow(p, q):
        ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=19,
                     color=P["text"], lw=1.9))

    fig, ax = plt.subplots(figsize=(10.4, 8.0), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.89, bottom=0.02, left=0.02, right=0.98)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")

    box(1.20, 8.95, 3.40, 0.85, P["actual"], d["s0"], fs=12.0, alpha=0.12)
    arrow((2.90, 8.85), (2.90, 8.25))
    box(0.55, 7.20, 8.90, 1.05, P["fear"], d["g1"], fs=11.6, alpha=0.11)
    arrow((2.90, 7.10), (2.90, 6.50))
    box(1.20, 5.60, 3.40, 0.90, P["inc"], d["s1"], fs=12.2, alpha=0.24)

    ax.add_patch(FancyArrowPatch((4.60, 6.28), (5.40, 6.28), arrowstyle="-|>",
                 mutation_scale=18, color=P["text"], lw=1.7))
    ax.add_patch(FancyArrowPatch((4.60, 5.82), (5.40, 5.82), arrowstyle="-|>",
                 mutation_scale=18, color=P["text"], lw=1.7))
    ax.text(5.55, 6.28, "%s — %s" % (d["c1"], d["c1d"]), ha="left", va="center",
            fontsize=9.0, color=P["dead"])
    ax.text(5.55, 5.82, "%s — %s" % (d["c2"], d["c2d"]), ha="left", va="center",
            fontsize=9.0, color=P["dead"])

    arrow((2.90, 5.60), (2.90, 5.00))
    box(0.55, 3.95, 8.90, 1.05, P["inc"], d["g2"], fs=11.6, alpha=0.11)
    arrow((2.90, 3.85), (2.90, 3.25))
    box(1.20, 2.20, 3.40, 1.05, P["good"], d["s2"], fs=12.0, alpha=0.22)

    ax.text(5.00, 1.20, d["note"], ha="center", va="center",
            fontsize=9.3, color="#7A828C", style="italic")

    fig.text(0.5, 0.965, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    footer(fig, lang); save(fig, lang, "fig4_3_5_two_stage")


for lg in ("zh", "en"):
    draw(lg)
