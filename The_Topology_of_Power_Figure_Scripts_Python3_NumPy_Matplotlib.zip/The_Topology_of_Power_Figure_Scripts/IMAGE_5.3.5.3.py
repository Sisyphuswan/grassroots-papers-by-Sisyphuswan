# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.3.5.3 —— 破局的拓扑几何学：两端同时移动边界，生路才会重新出现

from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

L = {
    "zh": dict(
        t="图 5.3.5.3  破局的拓扑几何学：两端同时移动场强边界",
        note="只动一端是零和拉扯；两端同时移动，安全守法才会重新落回可行域",
        a1="平台端：拆解算法惩治断崖", a1d="降低违约的毁灭性\n（Inflex ↓、Elastic ↑）",
        a2="交管端：提高违章查处兑现力", a2d="落实惩戒的确定性\n（κ_Traffic → 1）",
        b1="向外推开合规缓冲空间", b2="向内焊死危险侥幸通道",
        c="使「遵章守纪且维持生计」\n重新成为 A_i 内部真实可见的生路",
    ),
    "en": dict(
        t="Figure 5.3.5.3  The topology of breaking out: move both boundaries at once",
        note="Moving one end alone is a zero-sum tug; move both and lawful safety returns to the domain",
        a1="Platform side: dismantle the algorithmic cliff", a1d="lower the destructiveness of default\n(Inflex down, Elastic up)",
        a2="Traffic-enforcement side: raise the certainty of sanctions", a2d="make punishment actually land\n(κ_Traffic → 1)",
        b1="push the lawful buffer outward", b2="weld shut the dangerous gamble inward",
        c="so that «law-abiding and still surviving»\nbecomes a visible road inside A_i again",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]

    def box(x, y, w, h, col, title, sub=None, fs=11.6, fs2=9.2, alpha=0.14):
        ax.add_patch(FancyBboxPatch((x, y), w, h,
                     boxstyle="round,pad=0.08,rounding_size=0.12",
                     facecolor=col, alpha=alpha, edgecolor=col, lw=1.9))
        if sub:
            ax.text(x + w / 2, y + h * 0.68, title, ha="center", va="center",
                    fontsize=fs, fontweight="bold", color=col)
            ax.text(x + w / 2, y + h * 0.28, sub, ha="center", va="center",
                    fontsize=fs2, color=P["text"])
        else:
            ax.text(x + w / 2, y + h / 2, title, ha="center", va="center",
                    fontsize=fs, fontweight="bold", color=col)

    def arrow(p, q, col=None):
        ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=20,
                     color=(col or P["text"]), lw=1.9))

    fig, ax = plt.subplots(figsize=(10.4, 7.2), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.88, bottom=0.03, left=0.02, right=0.98)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")

    box(0.55, 8.25, 4.20, 1.35, P["actual"], d["a1"], d["a1d"])
    box(5.25, 8.25, 4.20, 1.35, P["actual"], d["a2"], d["a2d"])
    arrow((2.65, 8.15), (2.65, 7.80))
    arrow((7.35, 8.15), (7.35, 7.80))

    box(0.55, 6.20, 4.20, 1.55, P["inc"], d["b1"])
    box(5.25, 6.20, 4.20, 1.55, P["fear"], d["b2"])

    arrow((2.65, 6.10), (4.40, 5.42))
    arrow((7.35, 6.10), (5.60, 5.42))

    box(1.05, 3.55, 7.90, 1.80, P["good"], d["c"], fs=12.2, alpha=0.24)

    ax.text(5.00, 2.55, d["note"], ha="center", va="center",
            fontsize=9.4, color="#7A828C", style="italic")

    fig.text(0.5, 0.965, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    footer(fig, lang); save(fig, lang, "fig5_3_5_3_breakthrough")


for lg in ("zh", "en"):
    draw(lg)
