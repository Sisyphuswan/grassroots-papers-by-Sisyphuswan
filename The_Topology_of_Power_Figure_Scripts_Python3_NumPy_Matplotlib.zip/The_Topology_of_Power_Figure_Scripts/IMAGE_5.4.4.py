# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.4.4 —— 从库兰式偏好伪装到单点态的表忠逼迫

from matplotlib.patches import FancyBboxPatch, Rectangle

L = {
    "zh": dict(
        t="图 5.4.4  偏好伪装的物理边界：当「保持沉默」也被逐出可行域",
        note="库兰模型停在第二层；而单点态连消极伪装的自由度也一并剥夺",
        s1="第一阶 · 库兰式伪装区（Width 充裕）：权衡声誉得失，主动选择掩饰",
        s2="第二阶 · 刚性静默区（Width 收窄）：恐惧场封死异见，退守沉默自保",
        s3="第三阶 · 强控制单点态（dim A_i = 0）：沉默即违逆，唯有缴纳投名状",
        z1="公开异见", z2="保持沉默", z3="敷衍迎合", z4="亢奋表忠 / 投名状",
        cut1="恐惧场截断（禁绝异见）",
        cut2="恐惧场 + 责任场联合截断（沉默与敷衍均定性为不忠）",
        pt="唯一存活点  a_conform",
    ),
    "en": dict(
        t="Figure 5.4.4  The boundary of preference falsification: when silence itself is banned",
        note="Kuran's model stops at stage 2; the singleton state strips away even passive falsification",
        s1="Stage 1 · Kuranian falsification (ample Width): trade off reputation, choose to mask",
        s2="Stage 2 · Rigid silence (narrow Width): dissent banned, retreat into silence",
        s3="Stage 3 · Strong-control singleton (dim A_i = 0): silence is treason; only active pledge remains",
        z1="Open dissent", z2="Silence", z3="Passive compliance", z4="Active pledge",
        cut1="Cut by fear field (dissent banned)",
        cut2="Cut by fear & responsibility fields (silence and perfunctory acts punished)",
        pt="Sole admissible point  a_conform",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(11.0, 6.8), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.86, bottom=0.04, left=0.03, right=0.97)
    ax.set_xlim(0, 11); ax.set_ylim(0, 10); ax.axis("off")

    xs = [0.6, 3.0, 5.4, 7.8]; w = 2.2
    for x, kz in zip(xs, ("z1", "z2", "z3", "z4")):
        ax.text(x + w / 2, 9.45, d[kz], ha="center", va="center",
                fontsize=10.2, fontweight="bold", color=P["text"])

    ax.text(0.6, 8.75, d["s1"], ha="left", va="center", fontsize=10.5,
            fontweight="bold", color=P["inc"])
    ax.add_patch(FancyBboxPatch((0.6, 7.25), 9.4, 1.10,
                 boxstyle="round,pad=0.04,rounding_size=0.10",
                 facecolor=P["inc"], alpha=0.22, edgecolor=P["inc"], lw=2.0))

    ax.text(0.6, 6.15, d["s2"], ha="left", va="center", fontsize=10.5,
            fontweight="bold", color=P["actual"])
    ax.add_patch(Rectangle((0.6, 4.65), 2.3, 1.10, facecolor=P["fear"],
                           alpha=0.14, edgecolor=P["fear"], lw=1.4, ls="--"))
    ax.text(1.75, 5.20, d["cut1"], ha="center", va="center",
            fontsize=8.8, color=P["dead"])
    ax.add_patch(FancyBboxPatch((3.0, 4.65), 7.0, 1.10,
                 boxstyle="round,pad=0.04,rounding_size=0.10",
                 facecolor=P["inc"], alpha=0.22, edgecolor=P["inc"], lw=2.0))

    ax.text(0.6, 3.55, d["s3"], ha="left", va="center", fontsize=10.5,
            fontweight="bold", color=P["dead"])
    ax.add_patch(Rectangle((0.6, 2.05), 7.1, 1.10, facecolor=P["fear"],
                           alpha=0.14, edgecolor=P["fear"], lw=1.4, ls="--"))
    ax.text(4.15, 2.60, d["cut2"], ha="center", va="center",
            fontsize=9.2, color=P["dead"])
    ax.plot([9.2], [2.60], marker="o", ms=13, color=P["dead"], zorder=5)
    ax.text(9.2, 1.45, d["pt"], ha="center", va="center",
            fontsize=10.0, fontweight="bold", color=P["dead"])

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.915, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_4_4_kuran_boundary")


for lg in ("zh", "en"):
    draw(lg)
