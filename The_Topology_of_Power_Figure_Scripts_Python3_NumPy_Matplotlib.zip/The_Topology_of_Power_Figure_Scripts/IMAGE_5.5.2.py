# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.5.2 —— 前景理论价值函数在空集态下的非对称坍缩

import numpy as np
from matplotlib.patches import FancyArrowPatch

L = {
    "zh": dict(
        t="图 5.5.2  前景理论价值函数在空集态下的非对称坍缩",
        note="收益侧厌恶风险、损失侧寻求风险；Type-S 主体在空集态下脱离零生存点并倾向高方差冒险",
        yl="主观价值  V(Δx)", xl="客观结果  Δx",
        g="收益区间：风险厌恶（见好就收）",
        l="损失区间：风险寻求（反射效应）",
        p1="恪守合规（空集态）：生还概率 Pr = 0",
        p1b="（确定性毁灭，被 Small > 0 一阶严格随机占优）",
        p2="被迫逃往高方差的极端冒险",
        p2b="「举大计」：生还率 Small > 0",
    ),
    "en": dict(
        t="Figure 5.5.2  Asymmetric collapse of the prospect-theory value function when A_i = ∅",
        note="Risk-averse over gains, risk-seeking over losses; when A_i = ∅, Type-S agents flee zero survival toward high-variance gambles",
        yl="Subjective value  V(Δx)", xl="Objective outcome  Δx",
        g="Gains: risk-averse (lock in early)",
        l="Losses: risk-seeking (reflection effect)",
        p1="Stay compliant: A_i = ∅, survival probability Pr = 0",
        p1b="(certain destruction, strictly dominated by Small > 0)",
        p2="Forced into a high-variance gamble",
        p2b="«raise the standard of rebellion»: survival rate Small > 0",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(10.4, 6.8), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.85, bottom=0.12, left=0.09, right=0.98)

    x = np.linspace(-3.0, 3.0, 900)
    V = np.where(x >= 0, np.abs(x) ** 0.62, -1.6 * np.abs(x) ** 0.85)
    ax.axhline(0, color="#B9C0C8", lw=1.0)
    ax.axvline(0, color="#B9C0C8", lw=1.0)
    ax.plot(x, V, color=P["text"], lw=2.5, zorder=3)

    ax.set_xlim(-3.4, 3.4); ax.set_ylim(-5.0, 3.2)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_xlabel(d["xl"], fontsize=10.5)
    ax.set_ylabel(d["yl"], fontsize=10.5)

    ax.text(3.25, 2.72, d["g"], ha="right", va="center", fontsize=9.6,
            color=P["inc"], fontweight="bold")
    ax.text(-3.25, 2.72, d["l"], ha="left", va="center", fontsize=9.6,
            color=P["fear"], fontweight="bold")

    ax.plot([-2.90], [-1.6 * 2.90 ** 0.85], "o", color=P["dead"], ms=9, zorder=5)
    ax.plot([-2.90, -2.90], [0, -1.6 * 2.90 ** 0.85], ls=":", lw=1.4,
            color=P["dead"], zorder=2)
    ax.text(-3.30, -4.20, d["p1"], ha="left", va="center", fontsize=9.2,
            color=P["dead"], fontweight="bold")
    ax.text(-3.30, -4.62, d["p1b"], ha="left", va="center", fontsize=8.8,
            color=P["dead"])

    ax.add_patch(FancyArrowPatch((-0.95, -3.10), (-0.95, 0.35),
                 arrowstyle="<|-|>", mutation_scale=15, color=P["cost"],
                 lw=1.9, zorder=4))
    ax.text(-0.72, -1.35, d["p2"], ha="left", va="center", fontsize=9.3,
            color="#A9620F", fontweight="bold")
    ax.text(-0.72, -1.78, d["p2b"], ha="left", va="center", fontsize=8.9,
            color="#A9620F")

    ax.add_patch(FancyArrowPatch((-2.72, -3.95), (-1.35, -2.30),
                 arrowstyle="-|>", mutation_scale=18, color=P["dead"], lw=1.9,
                 connectionstyle="arc3,rad=0.22", zorder=6))

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.0, fontweight="bold")
    fig.text(0.5, 0.918, d["note"], ha="center", fontsize=9.4, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_5_2_prospect")


for lg in ("zh", "en"):
    draw(lg)
