# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 8.6.1 —— 安全走廊双向坍缩与可行人事集归零（中英双语）

import numpy as np

L = {
    "zh": dict(
        t="图 8.6.1  安全走廊双向坍缩与可行人事集归零",
        note="清洗升级挤压能力天花板、危机蔓延抬高履职底线；两线交叉后，能臣触发清洗、庸官导致溃败",
        xt="清洗升级指数  $\\mathrm{Escal} \\in [1, +\\infty)$",
        y1="相对网络强度  $\\mathrm{RelativeNetworkRatio}_i$",
        y2="安全走廊宽度  $\\mathrm{CorridorWidth}$",
        pa="A 栏：安全走廊的双向挤压与交叉", pb="B 栏：走廊宽度穿越零轴",
        cap="能力容忍天花板  $\\mathrm{ToleranceCeiling}$",
        flr="履职底线能力  $\\mathrm{FunctionalFloor}$",
        corr="安全走廊（$\\mathrm{CorridorWidth} > 0$）",
        emp="人事可行集归零（$\\mathrm{FeasiblePersonnelSet} = \\varnothing$）",
        crit="走廊坍缩临界点  $\\mathrm{CollapseRatio}$\n对应升级阈值  $\\mathrm{Escal}^* = %.2f$",
        zero_lbl="走廊跌破零轴（$\\mathrm{CorridorWidth} < 0$）\n宏观空集态锁定",
    ),
    "en": dict(
        t="Figure 8.6.1  Bidirectional Collapse of the Personnel Safe Corridor",
        note="Rising purge escalation lowers ToleranceCeiling while crisis raises FunctionalFloor, closing the feasible personnel set",
        xt="Purge escalation index  $\\mathrm{Escal} \\in [1, +\\infty)$",
        y1="Relative network strength  $\\mathrm{RelativeNetworkRatio}_i$",
        y2="Safe corridor width  $\\mathrm{CorridorWidth}$",
        pa="Panel A: Bidirectional squeeze of the safe corridor", pb="Panel B: CorridorWidth crossing zero",
        cap="Tolerance ceiling  $\\mathrm{ToleranceCeiling}$",
        flr="Minimum functional floor  $\\mathrm{FunctionalFloor}$",
        corr="Safe corridor ($\\mathrm{CorridorWidth} > 0$)",
        emp="Empty personnel set ($\\mathrm{FeasiblePersonnelSet} = \\varnothing$)",
        crit="Collapse point  $\\mathrm{CollapseRatio}$\nat threshold  $\\mathrm{Escal}^* = %.2f$",
        zero_lbl="Corridor below zero ($\\mathrm{CorridorWidth} < 0$)\nMacro empty-set trap",
    ),
}

def draw(lang):
    set_font(lang); d = L[lang]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.4, 6.0), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.80, bottom=0.14, wspace=0.22)

    esc = np.linspace(1.0, 2.5, 500)
    s = (esc - 1.0) / 1.5
    ceil = 0.95 - 0.56 * (s ** 1.15)
    flr = 0.25 + 0.62 * (s ** 1.22)
    width = ceil - flr
    idx = int(np.argmin(np.abs(width)))
    e_star = float(esc[idx])
    y_cross = float(ceil[idx])

    ax1.plot(esc, ceil, color=P["fear"], lw=2.8, label=d["cap"])
    ax1.plot(esc, flr, color=P["actual"], lw=2.8, label=d["flr"])
    ax1.fill_between(esc[:idx + 1], flr[:idx + 1], ceil[:idx + 1],
                     color=P["good"], alpha=0.22, label=d["corr"])
    ax1.fill_between(esc[idx:], ceil[idx:], flr[idx:],
                     facecolor="#FBE9E7", edgecolor=P["gap"], hatch="///", alpha=0.32, label=d["emp"])
    ax1.plot([e_star, e_star], [0.0, 0.88], color=P["dead"], ls="--", lw=1.6)
    ax1.plot([e_star], [y_cross], marker="X", ms=11, color=P["dead"], zorder=5)
    ax1.annotate(d["crit"] % e_star, xy=(e_star, y_cross), xytext=(1.05, 0.08),
                 fontsize=9.2, fontweight="bold", color=P["dead"],
                 arrowprops=dict(arrowstyle="->", color=P["dead"], lw=1.4),
                 bbox=dict(boxstyle="round,pad=0.3", fc="#FFF5F5", ec=P["dead"]))
    ax1.set_xlim(1.0, 2.5); ax1.set_ylim(0.0, 1.22)
    ax1.set_xlabel(d["xt"], fontsize=10.5); ax1.set_ylabel(d["y1"], fontsize=10.5)
    ax1.set_title(d["pa"], fontsize=11.5, fontweight="bold")
    ax1.legend(loc="upper right", bbox_to_anchor=(1.00, 1.00), frameon=True, facecolor="white", edgecolor="none", framealpha=0.92, fontsize=8.4)
    plain_axes(ax1); ax1.grid(axis="y", color=P["grid"], lw=0.6)

    ax2.plot(esc, width, color=P["text"], lw=2.8)
    ax2.axhline(0.0, color=P["text"], lw=1.2)
    ax2.fill_between(esc, 0, width, where=(width > 0), color=P["good"], alpha=0.22)
    ax2.fill_between(esc, 0, width, where=(width <= 0), color=P["dead"], alpha=0.20)
    ax2.axvline(e_star, color=P["dead"], ls="--", lw=1.6)
    ax2.plot([e_star], [0.0], marker="X", ms=11, color=P["dead"], zorder=5)
    ax2.annotate(d["zero_lbl"], xy=(2.28, width[430]), xytext=(1.42, -0.34),
                 fontsize=9.4, fontweight="bold", color=P["dead"],
                 arrowprops=dict(arrowstyle="->", color=P["dead"], lw=1.4),
                 bbox=dict(boxstyle="round,pad=0.3", fc="#FFF5F5", ec=P["dead"]))
    ax2.set_xlim(1.0, 2.5); ax2.set_ylim(-0.55, 0.80)
    ax2.set_xlabel(d["xt"], fontsize=10.5); ax2.set_ylabel(d["y2"], fontsize=10.5)
    ax2.set_title(d["pb"], fontsize=11.5, fontweight="bold")
    plain_axes(ax2); ax2.grid(axis="y", color=P["grid"], lw=0.6)

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.908, d["note"], ha="center", fontsize=9.4, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig8_6_1_corridor_collapse")

for lg in ("zh", "en"):
    draw(lg)
