# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.3.5.1 —— 司马迁案的微观拓扑场：三场各自判定 → A_i 收敛为单点

from matplotlib.patches import FancyBboxPatch, Rectangle

L = {
    "zh": dict(
        t="图 5.3.5.1  司马迁面对汉武帝朝堂的微观拓扑场",
        note="三场各自封死一条路，可行域被压成唯一极点",
        rows=[
            ("激励场  Π_Incentive", P["inc"], [
                "出钱五十万赎死：司马家贫无余财，朝中公卿旧友无一人相助。",
                "该通道直接失效 —— 收益够不上存续底线。"]),
            ("恐惧场  Π_Fear（许可侧）", P["fear"], [
                "引决自裁：物理肉体毁灭，且身负谤主叛国之罪。",
                "世俗名声上「死节」或有清誉，但在责任场面前被直接否决。"]),
            ("责任场  Π_Responsibility（绝对否决）", P["resp"], [
                "太史公世家之责未竟：上计黄帝、下至于汉武，",
                "「究天人之际，通古今之变，成一家之言」的《史记》草创未就。",
                "死节 = 史记湮灭 = 背叛父亲临终托付与千秋史魂。"]),
        ],
        c="A_i = { 隐忍苟活，蒙受奇耻大辱，接受腐刑，完成《史记》 }",
        c2="单点态（唯一收敛点）：Width = 0，只剩这一条路",
    ),
    "en": dict(
        t="Figure 5.3.5.1  Sima Qian's micro-topological field at the Han court",
        note="Each field seals off one road; the domain collapses to a single point",
        rows=[
            ("Incentive field  Π_Incentive", P["inc"], [
                "Pay 500,000 to commute the death penalty: the family had nothing,",
                "and no friend at court would help. This channel simply fails."]),
            ("Fear field  Π_Fear (permissive side)", P["fear"], [
                "Suicide: the body is destroyed and the stigma of treason remains.",
                "Honour in the eyes of the world is vetoed by the responsibility field."]),
            ("Responsibility field  Π_Responsibility (absolute chokehold)", P["resp"], [
                "The Grand Historian's family duty is unfinished: from the Yellow Emperor",
                "down to Emperor Wu, the Records of the Grand Historian is not yet written.",
                "Dying = annihilating the Records = betraying his father's deathbed charge."]),
        ],
        c="A_i = { endure disgrace, accept castration, finish the Records }",
        c2="Single-point state: Width = 0 — only one road left",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(10.6, 8.6), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.90, bottom=0.02, left=0.02, right=0.98)
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")

    ax.add_patch(FancyBboxPatch((0.35, 0.40), 9.30, 9.00,
                 boxstyle="round,pad=0.06,rounding_size=0.14",
                 facecolor=P["light_bg"], edgecolor="#C7CDD6", lw=1.6))

    ys = (7.05, 4.80, 2.55)
    for (title, col, lines), y in zip(d["rows"], ys):
        h = 2.10
        ax.add_patch(FancyBboxPatch((0.70, y), 8.60, h,
                     boxstyle="round,pad=0.06,rounding_size=0.10",
                     facecolor="white", edgecolor="#DDE1E7", lw=1.2))
        ax.add_patch(Rectangle((0.70, y), 0.15, h, facecolor=col,
                     edgecolor="none"))
        ax.text(1.10, y + h - 0.45, title, ha="left", va="center",
                fontsize=11.4, fontweight="bold", color=col)
        for k, ln in enumerate(lines):
            ax.text(1.10, y + h - 1.00 - 0.38 * k, ln, ha="left", va="center",
                    fontsize=9.3, color=P["text"])

    ax.add_patch(FancyBboxPatch((0.70, 0.70), 8.60, 1.60,
                 boxstyle="round,pad=0.06,rounding_size=0.10",
                 facecolor=P["dead"], alpha=0.16, edgecolor=P["dead"], lw=2.0))
    ax.text(1.10, 1.85, d["c"], ha="left", va="center", fontsize=10.4,
            fontweight="bold", color=P["dead"])
    ax.text(1.10, 1.20, d["c2"], ha="left", va="center", fontsize=9.4,
            color=P["text"])

    fig.text(0.5, 0.968, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.938, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_3_5_1_sima_qian")


for lg in ("zh", "en"):
    draw(lg)
