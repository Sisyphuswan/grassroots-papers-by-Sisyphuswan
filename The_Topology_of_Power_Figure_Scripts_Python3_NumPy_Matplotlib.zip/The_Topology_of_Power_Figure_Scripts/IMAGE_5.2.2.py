# -*- coding: utf-8 -*-
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# =============================================================================
# Standalone Styling & Output Helpers (Color Contract — The Topology of Power)
# =============================================================================
P = {
    "omega":    "#EDEFF2",   # Global possibility universe (background)
    "claimed":  "#9AA7B4",   # Claimed layer (dashed)
    "actual":   "#1F5C99",   # Actual layer (solid / filled)
    "gap":      "#C0392B",   # Realization gap (hatched)
    "fear":     "#C0392B",   # Fear / irreversible sanction field
    "inc":      "#2E8B57",   # Incentive field / feasible action domain
    "resp":     "#7D5BA6",   # Responsibility / liability field
    "cost":     "#E08A27",   # Cost / dissipation curves
    "dead":     "#8E2420",   # Deadlock / null-set pathology
    "good":     "#3C8D6B",   # Resilient / optimal corridor
    "text":     "#2B2B2B",
    "grid":     "#D8DCE3",
    "light_bg": "#F7F8FA",
}

DPI = 200
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_font(lang):
    """Switch font family by language ('zh' or 'en')."""
    if lang == "zh":
        plt.rcParams["font.sans-serif"] = [
            "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
            "Source Han Sans SC", "Arial Unicode MS",
        ]
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial", "Helvetica"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 10.5
    plt.rcParams["axes.edgecolor"] = P["grid"]
    plt.rcParams["axes.labelcolor"] = P["text"]
    plt.rcParams["text.color"] = P["text"]
    plt.rcParams["xtick.color"] = P["text"]
    plt.rcParams["ytick.color"] = P["text"]


def footer(fig, lang):
    """Bottom-right stylized illustration disclaimer."""
    txt = ("构造性示意 · 非经验拟合" if lang == "zh"
           else "Stylized illustration — not an empirical fit")
    fig.text(0.985, 0.012, txt, ha="right", va="bottom",
             fontsize=8.2, color="#9AA7B4", style="italic")


def plain_axes(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_facecolor("white")


def save(fig, lang, name):
    out_dir = os.path.join(_SCRIPT_DIR, "figures", lang)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{name}_{lang}.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  ->", path)


# IMAGE 5.2.2 —— 同一个 Width→0 的四种来源

from matplotlib.patches import FancyBboxPatch

L = {
    "zh": dict(
        t="图 5.2.2  同一个 $\\text{Width} \\to 0$：四种性质相反的来源",
        note="测度读数相同，伦理评价分属两个极端",
        root="同一个狭窄的微观选择广度  $\\text{Width} \\to 0$",
        b1="外力强制暴力", d1="（被特务监视）",
        b2="生理资源匮乏", d2="（贫无立锥之地）",
        b3="神圣契约连带", d3="（守护病榻至亲）",
        b4="交通协调规则", d4="（红灯必须停步）",
        f1="恐惧场绝对压制", f2="激励场生存线过高",
        f3="责任场双向挤压", f4="避免公地悲剧的自律",
    ),
    "en": dict(
        t="Figure 5.2.2  One reading, $\\text{Width} \\to 0$: four sources with opposite natures",
        note="The same measure reading, yet opposite ethical verdicts",
        root="One narrow micro-domain  $\\text{Width} \\to 0$",
        b1="Coercive state violence", d1="(under surveillance)",
        b2="Material destitution", d2="(not a penny to one's name)",
        b3="Sacred contractual bond", d3="(nursing a dying parent)",
        b4="Traffic coordination rule", d4="(the light is red)",
        f1="fear field absolute suppression", f2="incentive survival floor too high",
        f3="responsibility field double bind", f4="self-restraint against a commons tragedy",
    ),
}


def draw(lang):
    set_font(lang); d = L[lang]
    fig, ax = plt.subplots(figsize=(11.4, 3.9), dpi=200)
    fig.patch.set_facecolor("white")
    fig.subplots_adjust(top=0.82, bottom=0.06, left=0.03, right=0.97)
    ax.set_xlim(0, 12); ax.set_ylim(4.15, 9.62); ax.axis("off")

    ax.add_patch(FancyBboxPatch((3.30, 8.05), 5.40, 1.35,
                 boxstyle="round,pad=0.05,rounding_size=0.14",
                 facecolor="#EDEFF2", edgecolor="#9AA7B4", lw=2.0))
    ax.text(6.00, 8.72, d["root"], ha="center", va="center",
            fontsize=12.5, fontweight="bold", color=P["text"])

    cols = [(P["fear"], "b1", "d1", "f1"), (P["inc"], "b2", "d2", "f2"),
            (P["resp"], "b3", "d3", "f3"), ("#5C6773", "b4", "d4", "f4")]
    x0, w, gap = 0.42, 2.72, 0.20
    for i, (col, kb, kd, kf) in enumerate(cols):
        x = x0 + i * (w + gap)
        ax.annotate("", xy=(x + w / 2, 6.55), xytext=(6.00, 8.00),
                    arrowprops=dict(arrowstyle="->", color=col, lw=2.0,
                                    connectionstyle="arc3,rad=0.0"))
        ax.add_patch(FancyBboxPatch((x, 4.35), w, 2.20,
                     boxstyle="round,pad=0.05,rounding_size=0.14",
                     facecolor=col, alpha=0.15, edgecolor=col, lw=2.2))
        ax.text(x + w / 2, 6.03, d[kb], ha="center", va="center",
                fontsize=12.0, fontweight="bold", color=col)
        ax.text(x + w / 2, 5.42, d[kd], ha="center", va="center",
                fontsize=9.6, color=P["text"])
        ax.text(x + w / 2, 4.90, d[kf], ha="center", va="center",
                fontsize=9.0, color="#7A828C", style="italic")

    fig.text(0.5, 0.955, d["t"], ha="center", fontsize=13.5, fontweight="bold")
    fig.text(0.5, 0.918, d["note"], ha="center", fontsize=9.5, color="#7A828C")
    footer(fig, lang); save(fig, lang, "fig5_2_2_w_sources")


for lg in ("zh", "en"):
    draw(lg)
